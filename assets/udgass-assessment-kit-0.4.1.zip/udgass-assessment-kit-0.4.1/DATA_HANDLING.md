# Data handling

## What Udgass needs

A date, a product identifier and a quantity. Nothing else.

## What happens to your file

- It is read on your machine. It is never uploaded or modified. The single-file commands read it in memory; the assessment and the engine copy only the mapped columns into a local database (for the assessment, in a temporary folder deleted when the run ends).
- Reports and JSON outputs contain product identifiers, weekly totals derived from your file and the file's SHA-256 hash. Treat them with the same care as the source.
- The run log (`udgass-audit.jsonl`) stores: Udgass version, command, settings, input file name and SHA-256, output file names and hashes, and a timestamp. It does not store any row of your data.
- Decision ledgers store whatever you put in them. Do not put personal data in them.

## Personal data guard

By default, loading refuses a file that has extra columns whose names look personal (email, phone, name, address, card, and similar) or whose values look like email addresses or phone numbers in the first 300 rows. This is a **best-effort check, not a guarantee**: it will miss personal data in free-text fields and will sometimes flag harmless columns. The safe approach is to export only the three columns needed. `--allow-extra-columns` turns the guard off.

## Browser tool on the website

The "Try it" tool on the website processes the file in the visitor's browser and does not upload it. The early-access form is separate: it sends what the visitor types to a Google Sheet.

## Retention and deletion

Udgass keeps nothing beyond the files you create. Deleting them is up to you. There is no hosted storage, so there is no deletion process to promise or operate.

## Engine (v0.4)

- Stored: only mapped columns of committed imports, in canonical form, with the file name, file hash and row numbers for traceability. Unmapped columns are never stored; personal-looking ones are flagged in the preview.
- Staged uploads: kept next to the database until commit (then deleted) or for at most 24 hours if never committed (`expire_previews`).
- Retention: records are kept until the organisation is purged. Corrections keep the earlier version by design.
- Deletion: `POST /v1/admin/purge` deletes every row of the organisation in one transaction; a purge record with counts only is kept. Backups you take are outside Udgass and keep data until they rotate out.
- Backups: copy the database file while the server is stopped, or use `sqlite3 udgass.db ".backup backup.db"` while it runs. Restore by replacing the file. Not automated.
- Export: `udgass admin export-org OUT_DIR --db ... --key ...` writes every table as JSON lines (no key hashes).
- External processing: none. No data is sent to any model provider or service.
