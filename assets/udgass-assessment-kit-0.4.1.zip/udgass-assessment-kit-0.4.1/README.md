# Udgass engine (v0.4, early development)

A decision intelligence engine for demand and inventory, built around organisational memory: what was known, what was
estimated, what was decided, what was done and what happened. Standard-library Python 3.9+, no dependencies, runs on a
machine you control. **All results in this repository come from synthetic data. Nothing has been run on a company's real data yet.**

## Demand assessment (start here with a company)

    python3 -m udgass assess --sales sales.csv --out assessment.html

Runs on the company's own computer, uploads nothing, deletes its working database when done, and writes a report:
data quality, what the data can answer, accuracy against simple methods (and the company's own forecasts with
`--incumbent`), where estimates fail, and an advisory reading on whether a pilot is justified. `--anonymise` writes a
shareable copy. Handles comma, semicolon, tab and pipe files, ambiguous dates (asks), decimal commas (`--decimal-comma`),
returns (`--returns net`), totals rows, and refuses monthly data and spreadsheets with a clear reason. See ASSESSMENT.md.

## Run it

    python3 -m udgass demo-workflow                  # whole loop on SYNTHETIC data, about 6 seconds
    python3 -m udgass serve --db udgass-demo.db      # API and web app on http://127.0.0.1:8765, sign in with the printed key

For your own data:

    python3 -m udgass admin create-org "Acme Planning" --db acme.db     # prints an admin key once
    python3 -m udgass serve --db acme.db

Then in the web app: Data and imports, Patterns, Forecasts, Backtest, Scenarios, Decision records, Outcomes. Every screen
reads the API documented in API.md; nothing is computed in the browser.

Tests: `python3 -m unittest discover -s tests` (97 tests). Browser end-to-end (needs Playwright): `python3 tests/browser_e2e.py`.

The v0.3 single-file commands (`check`, `backtest`, `detect`, `evaluate`, `compare-forecast`, `record`) still work as before.

## The loop, and what is real today

| Step | Status |
|---|---|
| Business data | Built: CSV import for sales, stock snapshots, purchase orders, events. Mapping, preview, explicit commit, rejected rows with reasons, idempotent re-import, corrections that keep the old version. No live connectors. |
| Historical context | Built: every record carries event time and knowledge time. "What was known at T" is a query. Data fingerprints identify exactly which records an analysis saw. |
| Pattern detection | Built: demand changes, growth changes, censored demand (stock-outs), export gaps, vendor lead-time changes, excess stock, demand profiles. Each with evidence, method, limits, uncertainty; never a cause. |
| Predictive estimation | Built: 6 methods chosen per series by past accuracy, prediction intervals from past errors, versioned immutable forecast runs, rebuildable from what was known. |
| Model evaluation | Built: rolling-origin backtest vs three baselines, by horizon, category, demand class, location; validation and test halves; promotion only on evidence, with rollback. |
| Scenario evaluation | Built: inventory simulation with a preserved baseline and variants (demand, late vendor, stock error, cost), common random numbers, costs, constraints, optimisation under stated assumptions. |
| Decision record | Built: append-only, hash-chained; recommendation, decision, approval, action, outcome kept distinct; evidence snapshotted at opening. |
| Realised outcome | Built: later imports; forecasts evaluated once complete; decisions evaluated against stated objectives. |
| Performance evaluation | Built: live error vs baseline, coverage, bias, by period, horizon, category; drift and data-quality checks. |
| Improved future decisions | Partly: evidence-gated policy promotion. No automatic learning, by design. |

## Measured on synthetic data (answer key known)

- Whole loop: about 35,000 rows imported, 85 purchase-order corrections recorded with history kept, 6 seconds end to end.
- Backtest, test half: active policy WAPE 10.1% vs 11.6% (mean of last four weeks), 15.0% (same week last year), 18.2% (last week). 79% of actuals inside the 80% range. Intermittent spare parts are poorly forecast by every method (WAPE above 100%) and the reports say so.
- Live forecasts checked later: WAPE 13.5% vs baseline 15.0%, coverage 79%.
- Patterns: finds every planted change (vendor V2 lead time 16 to 28 days, an export gap, a trend break, a level drop).
- Scale, one core: 545,000 daily rows (500 series, 3 years): preview 8 s, commit 20 s, forecast run 4 s, backtest 18 s, patterns 4 s, database 218 MB.

These numbers prove the code does what it says on data with a known answer. They say nothing about accuracy on a real business.

## Documents

ARCHITECTURE.md (design and decisions), DATA_MODEL.md, API.md, SECURITY.md, DATA_HANDLING.md, THREAT_MODEL.md,
ENTERPRISE_READINESS.md (what is missing), PILOT_GUIDE.md, ENGINEERING_LOG.md.
