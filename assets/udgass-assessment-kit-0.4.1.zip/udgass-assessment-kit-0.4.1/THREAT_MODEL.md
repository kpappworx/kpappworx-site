# Threat model (v0.3, one author, not independently reviewed)

| Risk | Current position |
|---|---|
| Data leaves the machine | No network code. Checked by a test. Does not cover the machine's other software. |
| Personal data enters by mistake | Guard refuses suspicious columns by default. Best-effort, can miss free text. |
| Input file altered | Read-only. Checked by a test. |
| Results altered after the fact | Run log is hash-chained and `record verify` detects edits. Does not stop deletion of the whole log. |
| Software acts on a business system | No write path exists. Advisory only. |
| A wrong estimate drives a bad decision | Main real-world risk. Mitigated by backtests on your own data, honest ranges, a flat baseline for comparison, a thin-evidence label and a human decision. Not eliminated. |
| False confidence from synthetic results | Every figure we publish is labelled with the data it was measured on. Measured numbers so far come from invented data only. |
| Malicious input file | Parsed with the standard `csv` module and plain arithmetic. No code is evaluated. No fuzzing has been done. |
| Supply chain | No dependencies. Python itself and the host are out of scope. |

| Another organisation reads data (v0.4) | Organisation taken from the key only; every query filtered; tested for reads and writes. One database file holds all organisations, so a server-level compromise exposes all of them. |
| Stolen API key | Revocation, rate limits, audit log. No IP allow-listing, no expiry, no MFA. |
| Interception on a network | TLS required off loopback. Plain HTTP on loopback only. |
| Cross-site scripting in the web app | Strict CSP (self only), text-only rendering of server data. |
| Tampered records | Triggers block edits; decision chains detect file-level edits (tested). A database administrator can still rewrite the file consistently. |
| Resource exhaustion | Size and row limits, rate limits. Long analyses run in the request thread; no per-tenant quotas. |

Out of scope: hosted multi-tenant deployment, connectors, SSO.
