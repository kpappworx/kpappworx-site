@echo off
setlocal EnableExtensions DisableDelayedExpansion
REM Udgass demand assessment launcher for Windows. Runs locally; makes no network connections.
REM Not yet tested on real Windows. If it fails, use the commands in START-HERE.
cd /d "%~dp0"

set "PY="
py -3 -c "import sys; sys.exit(0 if sys.version_info >= (3, 9) else 1)" >nul 2>nul && set "PY=py -3"
if not defined PY python -c "import sys; sys.exit(0 if sys.version_info >= (3, 9) else 1)" >nul 2>nul && set "PY=python"
if not defined PY (
  echo Python 3.9 or newer was not found. Install it free from https://www.python.org/downloads/
  echo and tick "Add python.exe to PATH" during installation. Then run this again.
  pause
  exit /b 1
)

echo Udgass demand assessment (runs on this computer only)
echo.
set "SALES="
set /p "SALES=Drag your sales CSV file into this window, then press Enter: "
if not defined SALES (
  echo No file given.
  pause
  exit /b 1
)
set "SALES=%SALES:"=%"
if not exist "%SALES%" (
  echo That file was not found. Check the path and try again.
  pause
  exit /b 1
)

if exist "assessment.html" del /q "assessment.html"

echo.
%PY% -m udgass assess --sales "%SALES%" --out assessment.html
set "RC=%errorlevel%"
if "%RC%"=="3" (
  echo.
  echo The file is not ready yet. assessment.html explains what to fix.
  if exist "assessment.html" start "" "assessment.html"
  pause
  exit /b 3
)
if not "%RC%"=="0" (
  echo.
  echo The assessment did not finish. No report was produced. Read the message above.
  pause
  exit /b %RC%
)
if exist "assessment.html" start "" "assessment.html"
echo.
echo Done. The report is assessment.html in this folder.
pause
exit /b 0
