import json, math, os, random, tempfile, unittest
from datetime import date
from udgass import backtest, data, demo, detect, diagnose, forecast, inventory
from udgass.cli import main


def clean(seed, n=156):
    r = random.Random(seed); base = r.uniform(40, 250); amp = base * r.uniform(.05, .2); tr = r.uniform(-.1, .2); ph = r.uniform(0, 6)
    return [max(0, base + tr * i + amp * math.sin(2 * math.pi * (i % 52) / 52 + ph) + r.gauss(0, base * r.uniform(.05, .12))) for i in range(n)]


class FastPath(unittest.TestCase):
    def test_fast_path_equals_direct_calls_for_every_method(self):
        r = random.Random(9)
        for _ in range(8):
            n = r.choice((80, 120, 156))
            y = [max(0, round(r.gauss(60, 15) + 10 * math.sin(i / 8))) if r.random() > .2 else 0 for i in range(n)]
            for m in forecast.METHODS:
                for h in (2, 4):
                    origins = list(range(16, n - h + 1, 7))
                    fast = forecast.forecasts_at(m, y, h, origins)
                    for o in origins:
                        d, f = forecast.METHODS[m](y[:o], h), fast[o]
                        self.assertEqual(d is None, f is None)
                        if d is not None:
                            for a, b in zip(d, f):
                                self.assertAlmostEqual(a, b, places=9)

    def test_parallel_equals_serial(self):
        d = tempfile.mkdtemp(); p = os.path.join(d, "s.csv"); demo.write_rich(p)
        ds = data.load_csv(p)
        self.assertEqual(backtest.run(ds)["rows"], backtest.run(ds, workers=2)["rows"])

    def test_forced_method_is_used_and_leaderboard_lists_auto(self):
        d = tempfile.mkdtemp(); p = os.path.join(d, "s.csv"); demo.write_rich(p)
        ds = data.load_csv(p)
        names = [t["method"] for t in backtest.leaderboard(ds)]
        self.assertIn("auto (selected per product)", names)
        self.assertIn("naive", names)
        rows = backtest.run(ds, methods=["naive"])["rows"]
        self.assertTrue(all(r["method"] == "naive" for r in rows))

    def test_methods_do_not_use_the_future(self):
        y = clean(1)
        for m in forecast.METHODS:
            a = forecast.METHODS[m](y[:100], 4)
            b = forecast.METHODS[m]((y[:100] + [9999.0] * 30)[:100], 4)
            self.assertEqual(a, b)


class Detect(unittest.TestCase):
    def test_finds_known_injected_changes(self):
        d = tempfile.mkdtemp(); p = os.path.join(d, "r.csv"); truth = demo.write_rich(p)
        ds = data.load_csv(p); found = detect.scan_all(ds)
        for t in truth:
            eps = found.get(t["sku"], [])
            self.assertTrue(any(abs(e["index"] - t["week_index"]) <= 3 for e in eps), t)

    def test_measured_false_alarm_rate_and_recall(self):
        seeds = range(2000, 2100)
        fa = sum(len(detect.episodes(detect.scan(clean(s)))) for s in seeds) / len(seeds)
        self.assertLess(fa, 0.8)                       # measured about 0.35 per product per 3 years at the default setting
        hit = 0
        for s in seeds:
            y = clean(s); y[100] *= 1.6
            hit += any(98 <= e["index"] <= 112 for e in detect.episodes(detect.scan(y)))
        self.assertGreater(hit / len(seeds), 0.75)     # measured about 0.87 for a 60% one-week spike

    def test_flags_are_causal(self):
        y = clean(5)
        a = detect.scan(y[:120])
        b = detect.scan(y[:120] + [5000.0] * 36)
        self.assertEqual(a, [x for x in b if x["index"] < 120])

    def test_intermittent_series_not_scanned(self):
        self.assertEqual(detect.scan([0, 0, 5, 0, 0, 0, 9, 0] * 20), [])

    def test_context_never_claims_cause(self):
        ev = [{"sku": "A", "start": date(2024, 3, 4), "end": date(2024, 3, 10), "type": "promotion"}]
        c = diagnose.context("A", date(2024, 3, 4), ev, [10.0, 0.0], 1)
        self.assertIn("not proof of cause", c["reading"])
        self.assertTrue(c["data_notes"])
        c2 = diagnose.context("A", date(2023, 1, 2), ev, [10.0, 10.0], 1)
        self.assertIn("unexplained", c2["reading"])


class Inventory(unittest.TestCase):
    def test_deterministic_demand_matches_hand_calculation(self):
        a = inventory.simulate(100, [0.0], 2, order_up_to=300, start_stock=300, runs=20)
        self.assertEqual(a["fill_rate"], 1.0)
        b = inventory.simulate(100, [0.0], 2, order_up_to=250, start_stock=250, runs=20)
        self.assertLess(b["fill_rate"], 1.0)

    def test_more_stock_never_lowers_service(self):
        errs = [-.2, -.1, 0, .1, .2, .3]
        fr = [inventory.simulate(100, errs, 3, order_up_to=u, start_stock=u, runs=400, seed=3)["fill_rate"] for u in (300, 400, 500, 700)]
        self.assertEqual(fr, sorted(fr))

    def test_seeded_and_longer_lead_is_worse(self):
        errs = [-.2, 0, .2, .4]
        a = inventory.simulate(100, errs, 2, order_up_to=500, start_stock=500, runs=300, seed=7)
        self.assertEqual(a, inventory.simulate(100, errs, 2, order_up_to=500, start_stock=500, runs=300, seed=7))
        b = inventory.simulate(100, errs, 6, order_up_to=500, start_stock=500, runs=300, seed=7)
        self.assertLess(b["fill_rate"], a["fill_rate"])

    def test_cli_evaluate_and_detect_run(self):
        d = tempfile.mkdtemp(); p = os.path.join(d, "r.csv"); demo.write_rich(p, os.path.join(d, "e.csv"))
        op = os.path.join(d, "o.json")
        with open(op, "w") as f:
            json.dump([{"name": "A", "order_up_to": 900}, {"name": "B", "reorder_point": 400, "order_qty": 700}], f)
        self.assertEqual(main(["evaluate", p, op, "--sku", "RICH-A", "--lead-weeks", "3", "--no-audit"]), 0)
        self.assertEqual(main(["detect", p, "--events", os.path.join(d, "e.csv"), "--json", os.path.join(d, "x.json"), "--no-audit"]), 0)
        self.assertEqual(main(["evaluate", p, op, "--sku", "NOPE", "--lead-weeks", "3", "--no-audit"]), 2)


if __name__ == "__main__":
    unittest.main()
