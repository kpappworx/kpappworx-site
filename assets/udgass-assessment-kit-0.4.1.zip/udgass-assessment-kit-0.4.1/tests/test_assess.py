"""Assessment on realistic, messy exports. Each test writes files the way real systems produce them."""
import json, math, os, random, tempfile, unittest
from datetime import date, timedelta
from udgass.engine import assess, ingest, synthetic
from udgass.cli import main


def series(n_weeks=130, skus=8, seed=3, start=date(2023, 1, 2)):
    r = random.Random(seed)
    out = []
    for s in range(skus):
        base = r.uniform(10, 80)
        for d in range(n_weeks * 7):
            day = start + timedelta(days=d)
            q = max(0, round(r.gauss(base * (1 + 0.3 * math.sin(2 * math.pi * d / 364)) / 7, base / 15)))
            if q:
                out.append((day, "MAT-%04d" % (s + 1), "1000", q))
    return out


def write(path, text):
    with open(path, "w", encoding="utf-8-sig") as f:
        f.write(text)
    return path


class Messy(unittest.TestCase):
    def setUp(self):
        self.d = tempfile.mkdtemp()

    def run_assess(self, files, **kw):
        out = os.path.join(self.d, "r.html"); js = os.path.join(self.d, "r.json")
        res = assess.run(files, out, js, say=lambda *_: None, **kw)
        return res, open(out, encoding="utf-8").read(), json.load(open(js))

    def test_sap_style_semicolon_dotted_dates_decimal_comma_totals_and_returns(self):
        rows = ["Buchungsdatum;Material;Werk;Menge;Kunde E-Mail"]
        for day, sku, plant, q in series():
            rows.append("%s;%s;%s;%s;" % (day.strftime("%d.%m.%Y"), sku, plant, ("%d,0" % q) if q < 1000 else "1.%03d,0" % (q - 1000)))
        rows.append(";;;Summe 123.456,0;")            # a totals row
        rows.append("")                               # trailing blank line
        rows.insert(50, "%s;MAT-0001;1000;-3,0;" % date(2023, 2, 1).strftime("%d.%m.%Y"))     # a return
        p = write(os.path.join(self.d, "sap.csv"), "\n".join(rows))
        maps = {"sales": {"date": "Buchungsdatum", "sku": "Material", "location": "Werk", "quantity": "Menge"}}
        with self.assertRaises(assess.NotReady):            # decimal comma not declared: quantities unreadable
            self.run_assess({"sales": p}, mappings=maps)
        res, html, js = self.run_assess({"sales": p}, mappings=maps, options={"decimal_comma": True, "returns": "net"})
        self.assertEqual(res["status"], "complete")
        imp = js["imports"][0]
        self.assertEqual(imp["date_formats"]["date"], "%d.%m.%Y")
        self.assertEqual(imp["rows_rejected"], 1)            # only the totals row
        self.assertIn("backtest", js); self.assertIn(js["verdict"]["level"], ("supports_pilot", "marginal", "no_improvement", "insufficient"))
        self.assertIn("Confidential", html)

    def test_monthly_data_is_refused_with_a_clear_reason(self):
        rows = ["Month,Item,Units"]
        for m in range(36):
            y, mo = 2022 + m // 12, m % 12 + 1
            rows.append("%04d-%02d-01,A,%d" % (y, mo, 100 + m))
        p = write(os.path.join(self.d, "m.csv"), "\n".join(rows))
        with self.assertRaises(assess.NotReady) as cm:
            self.run_assess({"sales": p}, mappings={"sales": {"date": "Month"}})
        self.assertTrue(any("monthly" in i for i in cm.exception.issues))
        self.assertIn("not ready", open(os.path.join(self.d, "r.html")).read())

    def test_ambiguous_columns_and_dates_explained(self):
        p = write(os.path.join(self.d, "a.csv"), "Item,Product,Date,Qty\nA,X,03/04/2024,1\nA,X,05/06/2024,2\n")
        with self.assertRaises(assess.NotReady) as cm:
            self.run_assess({"sales": p})
        joined = " ".join(cm.exception.issues)
        self.assertIn("--map sales:sku", joined)

    def test_short_history_still_assessed_with_shorter_training(self):
        rows = ["date,sku,quantity"] + ["%s,%s,%d" % (d.isoformat(), s, q) for d, s, _, q in series(n_weeks=45, skus=4)]
        p = write(os.path.join(self.d, "s.csv"), "\n".join(rows))
        res, html, js = self.run_assess({"sales": p})
        self.assertEqual(js["backtest"]["params"]["min_train_weeks"], 26)
        self.assertGreater(js["quality"]["series_under_56_weeks"], 0)

    def test_incumbent_forecasts_compared_and_anonymised_report_hides_codes(self):
        d = os.path.join(self.d, "syn"); synthetic.generate(d)
        # an incumbent that is the same-week-last-year total, built only from history (a plausible planner forecast)
        import csv
        from collections import defaultdict
        wk = defaultdict(float)
        with open(os.path.join(d, "sales.csv")) as f:
            for r in csv.DictReader(f):
                day = date.fromisoformat(r["Posting Date"]); mon = day - timedelta(days=day.weekday())
                wk[(r["Material"], r["Plant"], mon)] += float(r["Order Qty"])
        rows = ["sku,location,as_of,forecast"]
        for (s, l, mon) in list(wk):
            if mon >= date(2024, 1, 1):
                f = sum(wk.get((s, l, mon - timedelta(weeks=52) + timedelta(weeks=i)), 0) for i in range(4))
                rows.append("%s,%s,%s,%.1f" % (s, l, mon.isoformat(), f))
        inc = write(os.path.join(self.d, "inc.csv"), "\n".join(rows))
        res, html, js = self.run_assess({"sales": os.path.join(d, "sales.csv")}, incumbent=inc, anonymise=True)
        self.assertGreater(js["incumbent"]["matched_windows"], 100)
        self.assertNotIn("M-1001", html); self.assertNotIn("P-BLR", html); self.assertNotIn("Material", html)
        self.assertIn("P001", html)
        pub = " ".join(js["publishable_summary"])
        self.assertNotIn("M-1", pub); self.assertIn("separate written approval", html); self.assertIn("entirely optional", html)

    def test_spreadsheet_refused_and_cli_exit_codes(self):
        p = os.path.join(self.d, "x.xlsx")
        with open(p, "wb") as f:
            f.write(b"PK\x03\x04junk")
        with self.assertRaises(Exception):
            self.run_assess({"sales": p})
        bad = write(os.path.join(self.d, "b.csv"), "Item,Product,Date,Qty\nA,X,2024-01-01,1\n")
        self.assertEqual(main(["assess", "--sales", bad, "--out", os.path.join(self.d, "o.html")]), 3)

    def test_working_database_is_deleted(self):
        import glob
        before = set(glob.glob(os.path.join(tempfile.gettempdir(), "udgass-assess-*")))
        rows = ["date,sku,quantity"] + ["%s,%s,%d" % (d.isoformat(), s, q) for d, s, _, q in series(n_weeks=60, skus=2)]
        self.run_assess({"sales": write(os.path.join(self.d, "s.csv"), "\n".join(rows))})
        self.assertEqual(set(glob.glob(os.path.join(tempfile.gettempdir(), "udgass-assess-*"))), before)


if __name__ == "__main__":
    unittest.main()
