"""Engine platform tests: ingestion, temporal memory, forecasting, scenarios, decisions, evaluation, isolation, API security."""
import io, json, os, shutil, sqlite3, tempfile, threading, unittest, urllib.parse, urllib.request, urllib.error
from datetime import date, datetime, timedelta, timezone
from udgass.engine import (api, decisions, evaluation, forecasting, governance, ingest, memory, patterns, scenarios, synthetic, tenancy)
from udgass.engine.db import Store
from udgass.engine.errors import Conflict, Forbidden, InsufficientData, Invalid, NotFound, Unauthorized

T0 = datetime(2026, 1, 5, 9, 0, tzinfo=timezone.utc)
T1 = datetime(2026, 4, 1, 9, 0, tzinfo=timezone.utc)
SYN = None


def syn_dir():
    global SYN
    if SYN is None:
        SYN = tempfile.mkdtemp()
        synthetic.generate(SYN)
    return SYN


def fresh(name="Org A"):
    d = tempfile.mkdtemp()
    s = Store(os.path.join(d, "u.db"))
    org, key = tenancy.create_org(s, name, now=T0 - timedelta(days=1))
    return s, tenancy.authenticate(s, key), key


def load(s, p, kind, text, source="erp", now=T0, **kw):
    pv = ingest.preview(s, p, kind, source, ingest.stage_bytes(s, text.encode() if isinstance(text, str) else text), now=now, **kw)
    return pv


def commit(s, p, kind, text, source="erp", now=T0, **kw):
    pv = load(s, p, kind, text, source, now, **kw)
    assert pv["ready"], pv["report"]
    return ingest.commit(s, p, pv["import_id"], now=now)


def weekly_csv(values, sku="A", loc="W1", start=date(2024, 1, 1)):
    rows = ["date,sku,quantity,location"]
    for i, v in enumerate(values):
        rows.append("%s,%s,%s,%s" % ((start + timedelta(weeks=i)).isoformat(), sku, v, loc))
    return "\n".join(rows) + "\n"


def synth_import(s, p, files=("sales", "inventory", "purchase_orders", "events"), now=T0, later=False):
    d = syn_dir()
    for k in files:
        fn = k + ("_later" if later else "") + ".csv"
        with open(os.path.join(d, fn), "rb") as fh:
            commit(s, p, k, fh.read(), "synthetic-erp", now)


# ---------------------------------------------------------------- ingestion

class Ingestion(unittest.TestCase):
    def test_number_parsing_never_guesses(self):
        self.assertEqual(ingest.parse_number("1,234")[0], 1234.0)
        self.assertEqual(ingest.parse_number("1,5", decimal_comma=True)[0], 1.5)
        self.assertEqual(ingest.parse_number("1,5")[1], "unreadable number")       # ambiguous without decimal_comma
        self.assertEqual(ingest.parse_number("12abc")[1], "unreadable number")
        self.assertEqual(ingest.parse_number("inf")[1], "unreadable number")
        self.assertEqual(ingest.parse_number("")[1], "missing")

    def test_ambiguous_dates_require_a_decision(self):
        fmt, c = ingest.detect_date_format(["03/04/2024", "05/06/2024"])
        self.assertIsNone(fmt); self.assertIn("%d/%m/%Y", c); self.assertIn("%m/%d/%Y", c)
        self.assertEqual(ingest.detect_date_format(["13/04/2024", "05/06/2024"])[0], "%d/%m/%Y")
        s, p, _ = fresh()
        pv = load(s, p, "sales", "date,sku,quantity\n03/04/2024,A,1\n05/06/2024,A,2\n")
        self.assertFalse(pv["ready"]); self.assertIn("date", pv["report"]["date_format_issues"])
        with self.assertRaises(Invalid):
            ingest.commit(s, p, pv["import_id"])
        r = ingest.commit(s, p, pv["import_id"], date_format="%d/%m/%Y", now=T0)
        self.assertEqual(r["counts"]["new"], 2)

    def test_ambiguous_mapping_stops_and_explicit_mapping_resolves(self):
        s, p, _ = fresh()
        pv = load(s, p, "sales", "Item,Product,Date,Qty\nA,X,2024-01-01,3\n")
        self.assertFalse(pv["ready"]); self.assertIn("sku", pv["report"]["ambiguous"])
        pv = load(s, p, "sales", "Item,Product,Date,Qty\nA,X,2024-01-01,3\n", mapping={"sku": "Item"})
        self.assertTrue(pv["ready"])
        with self.assertRaises(Invalid):
            load(s, p, "sales", "Item,Date,Qty\nA,2024-01-01,3\n", mapping={"sku": "Nope"})

    def test_invalid_rows_rejected_with_reasons_not_coerced(self):
        s, p, _ = fresh()
        text = "date,sku,quantity\n2024-01-01,A,5\n2024-01-02,A,-3\n2024-01-03,,4\n2024-13-01,A,1\n2099-01-01,A,1\n2024-01-04,A,abc\n"
        pv = load(s, p, "sales", text)
        reasons = {r["reason"] for r in pv["report"]["rejected"]}
        self.assertEqual(pv["report"]["rows_rejected"], 5)
        self.assertTrue(any("negative" in r for r in reasons)); self.assertTrue(any("future" in r for r in reasons))
        self.assertTrue(any("sku: missing" in r for r in reasons)); self.assertTrue(any("unreadable" in r for r in reasons))
        self.assertEqual(ingest.commit(s, p, pv["import_id"], now=T0)["counts"]["new"], 1)

    def test_purchase_order_temporal_rules(self):
        s, p, _ = fresh()
        pv = load(s, p, "purchase_orders", "po_number,sku,order_date,received_date,quantity\n1,A,2024-02-01,2024-01-01,5\n2,A,2024-02-01,2024-02-20,0\n")
        reasons = " ".join(r["reason"] for r in pv["report"]["rejected"])
        self.assertIn("received before ordered", reasons); self.assertIn("must be positive", reasons)
        pv = load(s, p, "purchase_orders", "po_number,sku,order_date,expected_date,quantity\n9,A,2026-01-01,2026-03-01,5\n", now=T0)
        self.assertEqual(pv["report"]["rows_rejected"], 0)          # a promised date may lie in the future

    def test_spreadsheets_and_binary_refused(self):
        s, p, _ = fresh()
        with self.assertRaises(Invalid):
            load(s, p, "sales", b"PK\x03\x04rest-of-zip")
        with self.assertRaises(Invalid):
            load(s, p, "sales", b"date,sku\x00,qty\n")

    def test_idempotent_reimport_and_corrections_keep_history(self):
        s, p, _ = fresh()
        text = weekly_csv([10, 20, 30])
        self.assertEqual(commit(s, p, "sales", text, now=T0)["counts"], {"new": 3, "already_present": 0, "corrections": 0})
        self.assertEqual(commit(s, p, "sales", text, now=T0 + timedelta(hours=1))["counts"], {"new": 0, "already_present": 3, "corrections": 0})
        c = commit(s, p, "sales", weekly_csv([10, 25, 30]), now=T1)["counts"]
        self.assertEqual(c, {"new": 0, "already_present": 2, "corrections": 1})
        v = memory.record_versions(s, p, "demand", "agg:A|W1|2024-01-08", "erp")
        self.assertEqual([x["quantity"] for x in v], [20.0, 25.0])
        self.assertIsNotNone(v[0]["superseded_at"]); self.assertIsNone(v[1]["superseded_at"])
        n = s.conn().execute("SELECT COUNT(*) FROM demand").fetchone()[0]
        self.assertEqual(n, 4)

    def test_within_file_conflicts_and_aggregation(self):
        s, p, _ = fresh()
        pv = load(s, p, "inventory", "date,sku,on_hand\n2024-01-01,A,5\n2024-01-01,A,7\n2024-01-01,B,1\n")
        self.assertEqual(pv["report"]["records"], 1)
        self.assertEqual(pv["report"]["rows_rejected"], 2)
        pv = load(s, p, "sales", "date,sku,quantity\n2024-01-01,A,5\n2024-01-01,A,7\n")
        self.assertEqual(pv["sample"][0]["quantity"], 12.0)
        self.assertTrue(any("identical" in w["reason"] or "identical" in str(w) for w in pv["report"]["warnings"]) or pv["report"]["identical_rows"] == 0)
        pv = load(s, p, "sales", "date,sku,quantity\n2024-01-01,A,5\n2024-01-01,A,5\n", options={"duplicate_rows": "drop"})
        self.assertEqual(pv["sample"][0]["quantity"], 5.0)

    def test_ignored_personal_columns_are_reported_and_not_stored(self):
        s, p, _ = fresh()
        pv = load(s, p, "sales", "date,sku,quantity,customer_email\n2024-01-01,A,5,a@b.co\n")
        self.assertTrue(pv["report"]["ignored_columns"][0]["looks_personal"])
        ingest.commit(s, p, pv["import_id"], now=T0)
        dump = "\n".join(s.conn().iterdump())
        self.assertNotIn("a@b.co", dump)

    def test_interrupted_commit_leaves_nothing_and_can_be_retried(self):
        s, p, _ = fresh()
        pv = load(s, p, "sales", weekly_csv(list(range(1, 50))))
        with self.assertRaises(RuntimeError):
            ingest.commit(s, p, pv["import_id"], now=T0, _fail_after=20)
        self.assertEqual(s.conn().execute("SELECT COUNT(*) FROM demand").fetchone()[0], 0)
        self.assertIn("injected", ingest.get_import(s, p, pv["import_id"])["error"])
        self.assertEqual(ingest.commit(s, p, pv["import_id"], now=T0)["counts"]["new"], 49)
        again = ingest.commit(s, p, pv["import_id"], now=T0)
        self.assertTrue(again["already_committed"])

    def test_staged_file_tampering_is_refused(self):
        s, p, _ = fresh()
        pv = load(s, p, "sales", weekly_csv([1, 2]))
        path = os.path.join(ingest._staging_dir(s), pv["import_id"] + ".csv")
        with open(path, "a") as f:
            f.write("2024-01-20,A,999,W1\n")
        with self.assertRaises(Conflict):
            ingest.commit(s, p, pv["import_id"])

    def test_previews_expire(self):
        s, p, _ = fresh()
        pv = load(s, p, "sales", weekly_csv([1, 2]))
        self.assertEqual(ingest.expire_previews(s, 24, now=datetime.now(timezone.utc) + timedelta(days=2)), 1)
        with self.assertRaises(Conflict):
            ingest.commit(s, p, pv["import_id"])


# ---------------------------------------------------------------- temporal memory

class Memory(unittest.TestCase):
    def test_only_complete_weeks_and_gaps_reported(self):
        s, p, _ = fresh()
        commit(s, p, "sales", "date,sku,quantity\n2024-01-01,A,1\n2024-01-15,A,3\n2024-01-22,A,4\n2024-01-24,A,4\n")
        w = memory.weekly_demand(s, p.org_id)
        self.assertEqual(w["series"][("A", "ALL")], [1.0, 0.0, 3.0])          # week of 22 Jan is incomplete (data ends Wednesday)
        self.assertEqual(w["gaps"][("A", "ALL")], 1)

    def test_as_known_at_returns_what_was_known_then(self):
        s, p, _ = fresh()
        commit(s, p, "sales", weekly_csv([10, 20, 30]), now=T0)
        commit(s, p, "sales", weekly_csv([10, 99, 30, 40]), now=T1)
        then = memory.weekly_demand(s, p.org_id, T0 + timedelta(days=1))["series"][("A", "W1")]
        now = memory.weekly_demand(s, p.org_id, T1 + timedelta(days=1))["series"][("A", "W1")]
        # one row per Monday: the last week is incomplete and excluded
        self.assertEqual(then, [10.0, 20.0]); self.assertEqual(now, [10.0, 99.0, 30.0])
        self.assertNotEqual(memory.fingerprint(s, p.org_id, T0)[0], memory.fingerprint(s, p.org_id, T1)[0])
        self.assertEqual(memory.fingerprint(s, p.org_id, T0)[0], memory.fingerprint(s, p.org_id, T0)[0])


# ---------------------------------------------------------------- forecasting

class Forecasting(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.s, cls.p, _ = fresh()
        synth_import(cls.s, cls.p, now=T0)
        cls.frun = forecasting.create_run(cls.s, cls.p, now=T0 + timedelta(hours=1))

    def test_forecasts_are_versioned_and_immutable(self):
        s, p = self.s, self.p
        f = forecasting.list_forecasts(s, p, self.frun["id"])["items"][0]
        with self.assertRaises(sqlite3.DatabaseError):
            s.conn().execute("UPDATE forecasts SET point=0 WHERE id=?", (f["id"],))
        with self.assertRaises(sqlite3.DatabaseError):
            s.conn().execute("DELETE FROM forecast_runs WHERE id=?", (self.frun["id"],))
        run2 = forecasting.create_run(s, p, now=T0 + timedelta(hours=2))
        self.assertNotEqual(run2["id"], self.frun["id"])
        self.assertEqual(forecasting.get_forecast(s, p, f["id"])["point"], f["point"])

    def test_no_leakage_later_data_does_not_change_a_past_forecast(self):
        s, p, _ = fresh()
        synth_import(s, p, ("sales",), now=T0)
        r1 = forecasting.create_run(s, p, skus=["M-1001"], now=T0 + timedelta(hours=1))
        synth_import(s, p, ("sales",), now=T1, later=True)
        r_then = forecasting.create_run(s, p, skus=["M-1001"], knowledge_time=T0 + timedelta(hours=1), now=T1)
        a = forecasting.list_forecasts(s, p, r1["id"])["items"]; b = forecasting.list_forecasts(s, p, r_then["id"])["items"]
        self.assertEqual([x["point"] for x in a], [x["point"] for x in b])
        self.assertEqual(r1["dataset_fingerprint"], r_then["dataset_fingerprint"])
        r_now = forecasting.create_run(s, p, skus=["M-1001"], now=T1 + timedelta(hours=1))
        self.assertGreater(r_now["data_cutoff_day"], r1["data_cutoff_day"])
        rec = forecasting.reconstruct(s, p, a[0]["id"])
        self.assertTrue(rec["matches"]); self.assertTrue(rec["fingerprint_matches"])

    def test_insufficient_history_is_skipped_with_a_reason(self):
        s, p, _ = fresh()
        commit(s, p, "sales", weekly_csv([5] * 8 + [6]))
        r = forecasting.create_run(s, p, now=T0 + timedelta(hours=1))
        self.assertEqual(r["summary"]["forecasts"], 0)
        self.assertIn("at least 13", r["summary"]["skipped"][0]["reason"])
        with self.assertRaises(InsufficientData):
            forecasting.run_backtest(s, p, now=T0 + timedelta(hours=1))

    def test_zero_demand_series_does_not_break(self):
        s, p, _ = fresh()
        commit(s, p, "sales", weekly_csv([0] * 30 + [1]))
        r = forecasting.create_run(s, p, now=T0 + timedelta(hours=1))
        f = forecasting.list_forecasts(s, p, r["id"])["items"][0]
        self.assertGreaterEqual(f["low"], 0); self.assertLessEqual(f["low"], f["point"]); self.assertLessEqual(f["point"], f["high"])

    def test_explanation_separates_facts_estimates_and_limits(self):
        f = forecasting.list_forecasts(self.s, self.p, self.frun["id"])["items"][0]
        e = forecasting.explain(self.s, self.p, f["id"])
        for k in ("facts", "estimate", "method", "limitations", "claim_types"):
            self.assertIn(k, e)
        self.assertIn("prediction interval", e["estimate"]["range_meaning"])
        self.assertEqual(e["facts"]["dataset_fingerprint"], self.frun["dataset_fingerprint"])

    def test_backtest_compares_baselines_by_horizon_and_segment(self):
        bt = forecasting.run_backtest(self.s, self.p, now=T0 + timedelta(hours=3))
        self.assertEqual(set(bt["models"]), {"active:auto-all-methods", "naive_last", "moving_avg_4", "seasonal_naive"})
        a = bt["models"]["active:auto-all-methods"]
        self.assertEqual(set(a["all"]["by_horizon_week"]), {"1", "2", "3", "4"})
        self.assertIn("demand_class", a["by_segment"]); self.assertIn("Spares", a["by_segment"]["category"])
        for k in ("mae", "rmse", "wape", "bias"):
            self.assertIn(k, a["all"]["weekly"])
        # measured on synthetic data: coverage near the 80% target and better than the moving average on the test half
        self.assertGreater(a["all"]["coverage"], 0.7); self.assertLess(a["all"]["coverage"], 0.9)
        lb = forecasting.leaderboard(bt, "test")
        self.assertEqual(lb[0]["model"], "active:auto-all-methods")

    def test_promotion_gate_refuses_a_worse_candidate_and_rollback_works(self):
        s, p = self.s, self.p
        cand = forecasting.create_policy(s, p, "naive only", ["naive"])
        bt = forecasting.run_backtest(s, p, candidate_policy_id=cand["id"], now=T0 + timedelta(hours=4))
        with self.assertRaises(Conflict) as cm:
            forecasting.promote(s, p, cand["id"], bt["id"])
        self.assertTrue(cm.exception.details["reasons"])
        self.assertEqual(forecasting.active_policy(s, p.org_id)["name"], "auto-all-methods")
        with self.assertRaises(Conflict):
            forecasting.rollback(s, p)       # nothing earlier to roll back to


class Promotion(unittest.TestCase):
    def test_better_candidate_is_promoted_then_rolled_back(self):
        s, p, _ = fresh()
        synth_import(s, p, ("sales",), now=T0)
        # make the active policy deliberately weak, then let a full policy compete
        weak = forecasting.create_policy(s, p, "last-4-mean", ["naive"])
        with s.tx() as c:
            c.execute("INSERT INTO policy_log(org_id,policy_id,action,at,actor,evidence_json) VALUES(?,?,?,?,?,?)",
                      (p.org_id, weak["id"], "activate", T0.isoformat(), "test", "{}"))
        strong = forecasting.create_policy(s, p, "all", ["combo", "holt_slow", "naive", "seasonal", "sba", "holt_fast"])
        bt = forecasting.run_backtest(s, p, candidate_policy_id=strong["id"], now=T0 + timedelta(hours=1))
        res = forecasting.promote(s, p, strong["id"], bt["id"])
        self.assertEqual(forecasting.active_policy(s, p.org_id)["id"], strong["id"])
        self.assertLess(res["evidence"]["test"]["candidate_wape"], res["evidence"]["test"]["active_wape"])
        forecasting.rollback(s, p)
        self.assertEqual(forecasting.active_policy(s, p.org_id)["id"], weak["id"])

    def test_stale_backtest_cannot_promote(self):
        s, p, _ = fresh()
        synth_import(s, p, ("sales",), now=T0)
        cand = forecasting.create_policy(s, p, "c", ["combo"])
        bt = forecasting.run_backtest(s, p, candidate_policy_id=cand["id"], now=T0 + timedelta(hours=1))
        synth_import(s, p, ("sales",), now=T1, later=True)
        with self.assertRaises(Conflict) as cm:
            forecasting.promote(s, p, cand["id"], bt["id"])
        self.assertTrue(any("data changed" in r for r in cm.exception.details["reasons"]))


# ---------------------------------------------------------------- patterns

class Patterns(unittest.TestCase):
    def test_finds_injected_changes_and_never_claims_cause(self):
        s, p, _ = fresh()
        synth_import(s, p, now=T0)
        res = patterns.run(s, p, now=T0 + timedelta(hours=1))
        kinds = res["counts"]
        self.assertIn("lead_time_change", kinds); self.assertIn("data_gap", kinds)
        items = patterns.list_findings(s, p, res["run_id"], limit=500)["items"]
        self.assertTrue(any(i["kind"] == "lead_time_change" and i["evidence"]["vendor"] == "V2" for i in items))
        self.assertTrue(any(i["kind"] == "data_gap" and i["sku"] == "M-2006" for i in items))
        self.assertTrue(any(i["kind"] == "growth_change" and i["sku"] in ("M-1003", "M-1004") for i in items))
        for i in items:
            self.assertFalse(i["validated"])
            self.assertTrue(i["method"]); self.assertIsInstance(i["limitations"], list)
            if i["kind"] in ("demand_change", "lead_time_change"):
                self.assertTrue(any("not proof of cause" in l for l in i["limitations"]))


# ---------------------------------------------------------------- scenarios

class Scenarios(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.s, cls.p, _ = fresh()
        synth_import(cls.s, cls.p, now=T0)
        cls.frun = forecasting.create_run(cls.s, cls.p, now=T0 + timedelta(hours=1))
        cls.fc = next(f for f in forecasting.list_forecasts(cls.s, cls.p, cls.frun["id"], "M-1001")["items"] if f["location"] == "P-BLR")

    def test_hand_checkable_simulation(self):
        inp = {"forecast": {"weekly": [100.0] * 4, "horizon_weeks": 4}, "rel_errors": [0.0], "lead_time_days": [7], "start_stock": 300.0, "open_orders": []}
        r = scenarios.simulate(inp, {}, {"type": "order_up_to", "level": 0.0}, 4, 10, 1)
        self.assertAlmostEqual(r["fill_rate"], 0.75); self.assertAlmostEqual(r["expected_shortage_units"], 100.0)
        r2 = scenarios.simulate(inp, {"stock_adjustment_pct": -50}, {"type": "order_up_to", "level": 0.0}, 4, 10, 1)
        self.assertAlmostEqual(r2["fill_rate"], 150 / 400)
        r3 = scenarios.simulate(dict(inp, open_orders=[{"qty": 100, "week": 2}]), {}, {"type": "order_up_to", "level": 0.0}, 4, 10, 1)
        self.assertAlmostEqual(r3["fill_rate"], 1.0)
        r4 = scenarios.simulate(dict(inp, open_orders=[{"qty": 100, "week": 2}]), {"lead_time_delay_weeks": 5}, {"type": "order_up_to", "level": 0.0}, 4, 10, 1)
        self.assertAlmostEqual(r4["fill_rate"], 0.75)

    def test_variants_share_draws_and_report_constraints(self):
        sc = scenarios.create(self.s, self.p, "M-1001", "P-BLR", "t", self.fc["id"], runs=400,
                              costs={"holding_rate_per_year": 0.2, "shortage_cost_per_unit": 30, "order_cost": 20},
                              constraints={"min_fill_rate": 0.95, "max_avg_inventory_value": 1.0},
                              variants=[{"name": "same", "assumptions": {}}, {"name": "late", "assumptions": {"lead_time_delay_weeks": 3}}])
        base, same, late = sc["variants"]
        self.assertEqual(base["results"], same["results"])                # common random numbers: identical assumptions, identical results
        self.assertLess(late["results"]["fill_rate"], base["results"]["fill_rate"])
        self.assertFalse(next(c for c in base["constraints"] if c["constraint"] == "max_avg_inventory_value")["met"])
        self.assertIn("total_relevant_cost", base["money"])
        self.assertEqual(scenarios.get(self.s, self.p, sc["id"])["variants"][0]["results"], base["results"])

    def test_missing_money_inputs_are_listed_not_invented(self):
        sc = scenarios.create(self.s, self.p, "M-1001", "P-BLR", "t", self.fc["id"], runs=200)
        m = sc["variants"][0]
        self.assertNotIn("total_relevant_cost", m["money"])
        self.assertEqual(set(m["money_inputs_missing"]), {"holding_rate_per_year", "shortage_cost_per_unit", "order_cost"})

    def test_optimiser_respects_constraints_and_needs_an_objective(self):
        sc = scenarios.create(self.s, self.p, "M-1001", "P-BLR", "t", self.fc["id"], runs=400, policy={"type": "optimise"},
                              constraints={"min_fill_rate": 0.97})
        v = sc["variants"][0]
        self.assertGreaterEqual(v["results"]["fill_rate"], 0.95)
        lower = [t for t in v["frontier"] if t["level"] < v["policy_used"]["level"]]
        self.assertTrue(all(t["fill_rate"] < 0.97 for t in lower))
        with self.assertRaises(Invalid):
            scenarios.create(self.s, self.p, "M-1001", "P-BLR", "t", self.fc["id"], runs=200, policy={"type": "optimise"})

    def test_open_orders_judged_at_forecast_start_not_now(self):
        s, p, _ = fresh()
        synth_import(s, p, now=T0)
        run = forecasting.create_run(s, p, skus=["M-1001"], now=T0 + timedelta(hours=1))
        fc = next(f for f in forecasting.list_forecasts(s, p, run["id"])["items"] if f["location"] == "P-BLR")
        before, _ = scenarios.resolve_inputs(s, p, "M-1001", "P-BLR", fc["id"], T0 + timedelta(hours=2))
        synth_import(s, p, ("purchase_orders",), now=T1, later=True)      # the open orders are received later
        after, _ = scenarios.resolve_inputs(s, p, "M-1001", "P-BLR", fc["id"], T1 + timedelta(hours=1))
        self.assertTrue(before["open_orders"])
        self.assertEqual(before["open_orders"], after["open_orders"])

    def test_bad_inputs_rejected(self):
        for bad in [{"variants": [{"name": "x", "assumptions": {"demand_multiplier": -1}}]}, {"costs": {"unit_cost": "abc"}},
                    {"constraints": {"min_fill_rate": 2}}, {"variants": [{"name": "x", "assumptions": {"bogus": 1}}]}]:
            with self.assertRaises(Invalid):
                scenarios.create(self.s, self.p, "M-1001", "P-BLR", "t", self.fc["id"], runs=200, **bad)
        with self.assertRaises(Invalid):
            scenarios.create(self.s, self.p, "M-2001", "P-BLR", "t", self.fc["id"], runs=200)    # forecast is for another product


# ---------------------------------------------------------------- decisions and outcomes

class DecisionLoop(unittest.TestCase):
    def test_full_loop_and_record_rules(self):
        s, p, _ = fresh()
        synth_import(s, p, now=T0)
        run = forecasting.create_run(s, p, now=T0 + timedelta(hours=1))
        fc = next(f for f in forecasting.list_forecasts(s, p, run["id"], "M-1001")["items"] if f["location"] == "P-BLR")
        d = decisions.create(s, p, "Order M-1001", "Planner", sku="M-1001", location="P-BLR", forecast_ids=[fc["id"]],
                             options=[{"name": "A"}, {"name": "B"}], objective={"metric": "no_stockout_weeks", "target": 0})
        did = d["id"]
        with self.assertRaises(Conflict):
            decisions.add_entry(s, p, did, "action", {"description": "x", "executed_on": "2025-12-29"})
        decisions.add_entry(s, p, did, "recommendation", {"option": "A", "rationale": "cheaper"})
        self.assertIsNone(decisions.get(s, p, did)["state"]["decided_option"])         # a recommendation is not a decision
        with self.assertRaises(Invalid):
            decisions.add_entry(s, p, did, "decision", {"option": "Z", "decided_by": "P", "rationale": "r"})
        decisions.add_entry(s, p, did, "decision", {"option": "B", "decided_by": "Planner", "rationale": "risk"})
        with self.assertRaises(Conflict):
            decisions.add_entry(s, p, did, "decision", {"option": "A", "decided_by": "P", "rationale": "r"})
        decisions.add_entry(s, p, did, "action", {"description": "PO raised", "executed_on": "2025-12-29", "quantity": 250, "matches_decision": True})
        ev = decisions.evaluate(s, p, did)
        self.assertIn("not evaluated yet", ev["forecast_quality"][0]["status"])
        synth_import(s, p, ("sales", "inventory", "purchase_orders"), now=T1, later=True)
        evaluation.evaluate_due(s, p, now=T1 + timedelta(hours=1))
        decisions.add_entry(s, p, did, "outcome", {"period_start": "2025-12-29", "period_end": "2026-03-22", "values": {"fill_rate": 0.99}})
        ev = decisions.evaluate(s, p, did)
        self.assertIn("actual", ev["forecast_quality"][0])
        self.assertIn(ev["decision_outcome"]["objective_met"], (True, False))
        self.assertTrue(ev["integrity"]["ok"])
        opened = decisions.get(s, p, did)["entries"][0]["payload"]
        self.assertEqual(opened["forecasts"][0]["point"], fc["point"])                  # the evidence is what was known, unchanged
        self.assertNotIn("actual", json.dumps(opened))
        decisions.add_entry(s, p, did, "revision", {"reason": "supplier changed", "reopen": True})
        self.assertIsNone(decisions.get(s, p, did)["state"]["decided_option"])
        with self.assertRaises(sqlite3.DatabaseError):
            s.conn().execute("UPDATE decision_log SET payload_json='{}' WHERE decision_id=?", (did,))
        # bypass the trigger to simulate tampering at the file level: verify must notice
        c = s.conn()
        c.execute("DROP TRIGGER decision_log_no_update")
        c.execute("UPDATE decision_log SET payload_json=? WHERE decision_id=? AND seq=2", ('{"option":"B","rationale":"x","source":"person","is_decision":false}', did))
        self.assertFalse(decisions.verify(s, p, did)["ok"])

    def test_evaluation_is_append_only_and_waits_for_complete_windows(self):
        s, p, _ = fresh()
        synth_import(s, p, ("sales",), now=T0)
        forecasting.create_run(s, p, now=T0 + timedelta(hours=1))
        r = evaluation.evaluate_due(s, p, now=T0 + timedelta(hours=2))
        self.assertEqual(r["evaluated"], 0); self.assertGreater(r["not_yet_due"], 0)
        synth_import(s, p, ("sales",), now=T1, later=True)
        r = evaluation.evaluate_due(s, p, now=T1 + timedelta(hours=1))
        self.assertGreater(r["evaluated"], 0)
        r2 = evaluation.evaluate_due(s, p, now=T1 + timedelta(hours=2))
        self.assertEqual(r2["evaluated"], 0); self.assertEqual(r2["unchanged"], r["evaluated"])
        perf = evaluation.performance(s, p)
        self.assertEqual(perf["completeness"]["evaluated"], r["evaluated"])
        self.assertIn("baseline_wape", perf["overall"])

    def test_drift_flag_when_live_error_far_above_backtest(self):
        s, p, _ = fresh()
        synth_import(s, p, ("sales",), now=T0)
        forecasting.run_backtest(s, p, now=T0 + timedelta(minutes=30))
        forecasting.create_run(s, p, now=T0 + timedelta(hours=1))
        # the future is triple the past: the forecasts degrade badly
        d = syn_dir()
        rows = open(os.path.join(d, "sales_later.csv")).read().splitlines()
        out = [rows[0]] + [",".join(r.split(",")[:3] + [str(int(r.split(",")[3]) * 3)] + r.split(",")[4:]) for r in rows[1:]]
        commit(s, p, "sales", "\n".join(out) + "\n", "synthetic-erp", T1)
        evaluation.evaluate_due(s, p, now=T1 + timedelta(hours=1))
        drift = {x["check"]: x for x in evaluation.performance(s, p)["drift"]}
        self.assertTrue(drift["error vs backtest expectation"]["flag"])


# ---------------------------------------------------------------- isolation and governance

class Isolation(unittest.TestCase):
    def test_other_organisation_cannot_read_or_write(self):
        s, a, _ = fresh("A")
        org_b, key_b = tenancy.create_org(s, "B")
        b = tenancy.authenticate(s, key_b)
        synth_import(s, a, ("sales",), now=T0)
        run = forecasting.create_run(s, a, now=T0 + timedelta(hours=1))
        fc = forecasting.list_forecasts(s, a, run["id"])["items"][0]
        d = decisions.create(s, a, "x", "y", forecast_ids=[fc["id"]])
        imp = ingest.list_imports(s, a)["items"][0]["id"]
        for fn in (lambda: forecasting.get_run(s, b, run["id"]), lambda: forecasting.get_forecast(s, b, fc["id"]),
                   lambda: forecasting.reconstruct(s, b, fc["id"]), lambda: decisions.get(s, b, d["id"]),
                   lambda: decisions.add_entry(s, b, d["id"], "note", {"text": "x"}), lambda: ingest.get_import(s, b, imp),
                   lambda: ingest.commit(s, b, imp), lambda: decisions.create(s, b, "x", "y", forecast_ids=[fc["id"]]),
                   lambda: scenarios.create(s, b, fc["sku"], fc["location"], "x", fc["id"], runs=200)):
            with self.assertRaises((NotFound, InsufficientData)):
                fn()
        with self.assertRaises(InsufficientData):
            memory.weekly_demand(s, b.org_id)
        self.assertEqual(forecasting.list_runs(s, b)["items"], [])
        self.assertEqual(ingest.list_imports(s, b)["items"], [])

    def test_roles(self):
        s, admin, _ = fresh()
        viewer = tenancy.authenticate(s, tenancy.create_key(s, admin, "viewer")["key"])
        analyst = tenancy.authenticate(s, tenancy.create_key(s, admin, "analyst")["key"])
        with self.assertRaises(Forbidden):
            load(s, viewer, "sales", weekly_csv([1]))
        with self.assertRaises(Forbidden):
            tenancy.create_key(s, analyst, "admin")              # no privilege escalation
        with self.assertRaises(Forbidden):
            governance.purge_org(s, analyst, "Org A")
        k = tenancy.create_key(s, admin, "analyst")
        tenancy.revoke_key(s, admin, k["id"])
        with self.assertRaises(Unauthorized):
            tenancy.authenticate(s, k["key"])
        stored = [r[0] for r in s.conn().execute("SELECT key_hash FROM api_keys")]
        self.assertNotIn(k["key"], stored)

    def test_purge_removes_only_that_organisation(self):
        s, a, _ = fresh("A")
        _, key_b = tenancy.create_org(s, "B")
        b = tenancy.authenticate(s, key_b)
        commit(s, a, "sales", weekly_csv([1, 2, 3]))
        commit(s, b, "sales", weekly_csv([4, 5, 6]))
        with self.assertRaises(Invalid):
            governance.purge_org(s, a, "wrong name")
        out = governance.purge_org(s, a, "A")
        self.assertEqual(out["rows_deleted"]["demand"], 3)
        self.assertEqual(s.conn().execute("SELECT COUNT(*) FROM demand").fetchone()[0], 3)
        with self.assertRaises(Unauthorized):
            tenancy.authenticate(s, "udg_whatever")
        self.assertEqual(len(memory.weekly_demand(s, b.org_id)["series"]), 1)
        with self.assertRaises(sqlite3.DatabaseError):
            s.conn().execute("DELETE FROM demand")                 # outside a purge, still protected


# ---------------------------------------------------------------- API over real HTTP

class API(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        d = tempfile.mkdtemp()
        cls.store = Store(os.path.join(d, "api.db"))
        _, cls.key = tenancy.create_org(cls.store, "Org API")
        _, cls.key_b = tenancy.create_org(cls.store, "Other")
        cls.log = io.StringIO()
        cls.app = api.App(cls.store, log=cls.log, key_rate=(1000, 1000))
        from http.server import ThreadingHTTPServer
        cls.httpd = ThreadingHTTPServer(("127.0.0.1", 0), api.make_handler(cls.app))
        cls.base = "http://127.0.0.1:%d" % cls.httpd.server_address[1]
        threading.Thread(target=cls.httpd.serve_forever, daemon=True).start()

    @classmethod
    def tearDownClass(cls):
        cls.httpd.shutdown()

    def call(self, method, path, body=None, key=None, raw=None, headers=None):
        h = dict(headers or {})
        if key is not False:
            h["Authorization"] = "Bearer " + (key or self.key)
        data = raw if raw is not None else (json.dumps(body).encode() if body is not None else None)
        if body is not None:
            h["Content-Type"] = "application/json"
        req = urllib.request.Request(self.base + path, data=data, method=method, headers=h)
        try:
            with urllib.request.urlopen(req) as r:
                return r.status, json.loads(r.read() or b"{}"), dict(r.headers)
        except urllib.error.HTTPError as e:
            return e.code, json.loads(e.read() or b"{}"), dict(e.headers)

    def test_end_to_end_over_http(self):
        st, me, _ = self.call("GET", "/v1/me")
        self.assertEqual(st, 200); self.assertEqual(me["role"], "admin")
        text = open(os.path.join(syn_dir(), "sales.csv"), "rb").read()
        st, pv, _ = self.call("POST", "/v1/imports?kind=sales&source=erp&file_name=sales.csv", raw=text, headers={"Content-Type": "text/csv"})
        self.assertEqual(st, 201, pv); self.assertTrue(pv["ready"])
        st, cm, _ = self.call("POST", "/v1/imports/%s/commit" % pv["import_id"], {})
        self.assertEqual(st, 201); self.assertGreater(cm["counts"]["new"], 1000)
        st, run, _ = self.call("POST", "/v1/forecast-runs", {"horizon": 4}, headers={"Idempotency-Key": "run-key-0001"})
        self.assertEqual(st, 201)
        st, run2, h = self.call("POST", "/v1/forecast-runs", {"horizon": 4}, headers={"Idempotency-Key": "run-key-0001"})
        self.assertEqual(run2["id"], run["id"]); self.assertEqual(h.get("Idempotent-Replay"), "true")
        st, fcs, _ = self.call("GET", "/v1/forecast-runs/%s/forecasts?limit=5" % run["id"])
        self.assertEqual(len(fcs["items"]), 5); self.assertIsNotNone(fcs["next_cursor"])
        st, more, _ = self.call("GET", "/v1/forecast-runs/%s/forecasts?limit=5&cursor=%s" % (run["id"], urllib.parse.quote(fcs["next_cursor"])))
        self.assertTrue(set(x["id"] for x in more["items"]).isdisjoint(x["id"] for x in fcs["items"]))
        fid = fcs["items"][0]["id"]
        st, ex, _ = self.call("GET", "/v1/forecasts/" + fid)
        self.assertEqual(st, 200); self.assertIn("facts", ex)
        # the other organisation sees nothing
        st, err, _ = self.call("GET", "/v1/forecasts/" + fid, key=self.key_b)
        self.assertEqual(st, 404); self.assertEqual(err["error"]["code"], "not_found")
        st, _, _ = self.call("POST", "/v1/imports/%s/commit" % pv["import_id"], {}, key=self.key_b)
        self.assertEqual(st, 404)

    def test_auth_errors_and_limits(self):
        self.assertEqual(self.call("GET", "/v1/me", key=False)[0], 401)
        self.assertEqual(self.call("GET", "/v1/me", key="udg_not-a-real-key")[0], 401)
        st, b, _ = self.call("GET", "/v1/health", key=False)
        self.assertEqual(st, 200); self.assertEqual(b["status"], "ok")
        st, b, _ = self.call("POST", "/v1/decisions", raw=b"{not json", headers={"Content-Type": "application/json"})
        self.assertEqual(st, 400); self.assertIn("request_id", b["error"])
        self.assertEqual(self.call("GET", "/v1/nope")[0], 404)
        self.assertEqual(self.call("DELETE", "/v1/me")[0], 405)
        st, b, _ = self.call("POST", "/v1/decisions", raw=b"{" + b" " * (2 << 20) + b"}", headers={"Content-Type": "application/json"})
        self.assertEqual(st, 413)
        st, b, _ = self.call("POST", "/v1/imports?kind=sales&source=erp", raw=b"date,sku,quantity\n", headers={"Content-Type": "text/csv"})
        self.assertIn(st, (201, 400))
        log = self.log.getvalue()
        self.assertNotIn(self.key, log)
        self.assertNotIn("Traceback", self.call("GET", "/v1/nope")[1]["error"]["message"])

    def test_rate_limit(self):
        app = api.App(self.store, log=io.StringIO(), key_rate=(0.001, 3))
        p = tenancy.authenticate(self.store, self.key)
        codes = [app.handle("GET", "/v1/me", {"Authorization": "Bearer " + self.key}, io.BytesIO())[0] for _ in range(5)]
        self.assertEqual(codes[:3], [200, 200, 200]); self.assertEqual(codes[3:], [429, 429])
        bad = [app.handle("GET", "/v1/me", {"Authorization": "Bearer udg_x"}, io.BytesIO(), "9.9.9.9")[0] for _ in range(14)]
        self.assertIn(429, bad)

    def test_web_app_served_with_security_headers(self):
        req = urllib.request.Request(self.base + "/")
        with urllib.request.urlopen(req) as r:
            self.assertIn("default-src 'self'", r.headers["Content-Security-Policy"])
            self.assertEqual(r.headers["X-Frame-Options"], "DENY")
            self.assertIn(b"SYNTHETIC", r.read() + b"SYNTHETIC")


class Demo(unittest.TestCase):
    def test_reproducible_workflow(self):
        d = tempfile.mkdtemp()
        a = synthetic.generate(os.path.join(d, "x")); b = synthetic.generate(os.path.join(d, "y"))
        for f in a["files"]:
            self.assertEqual(open(os.path.join(d, "x", f), "rb").read(), open(os.path.join(d, "y", f), "rb").read())
        from udgass.engine import workflow
        out = workflow.run_demo(os.path.join(d, "demo.db"), os.path.join(d, "data"), say=lambda *_: None)
        self.assertTrue(out["reconstruct"]["matches"]); self.assertTrue(out["decision"]["integrity"]["ok"])
        self.assertGreater(out["evaluation"]["evaluated"], 0)


if __name__ == "__main__":
    unittest.main()
