"""Hostile and malformed inputs: the importer must either produce a report or refuse with a clear error. Never crash, never hang."""
import os, random, tempfile, unittest
from udgass.engine import ingest, tenancy
from udgass.engine.db import Store
from udgass.engine.errors import UdgassError

ALPH = ["2024-01-01", "01/02/2024", "x", "", "-1", "1,234", "1.234,5", "NaN", "inf", "1e308", " ", "=cmd|'/c calc'!A1",
        "\"quoted, comma\"", "A" * 300, "Ω≈ç√", "﻿", "0", "999999999999999999999", "2099-12-31", "1899-01-01", ";", "\t", "|"]


class Fuzz(unittest.TestCase):
    def test_random_files_never_crash(self):
        r = random.Random(42)
        d = tempfile.mkdtemp()
        s = Store(os.path.join(d, "f.db"))
        _, key = tenancy.create_org(s, "fuzz")
        p = tenancy.authenticate(s, key)
        outcomes = {"report": 0, "refused": 0}
        for i in range(250):
            kind = r.choice(list(ingest.SPEC))
            cols = r.randint(1, 6)
            header = [r.choice(["date", "sku", "quantity", "on_hand", "po_number", "order_date", "event_type", "start_date", "Qty", "", "x", "date"]) for _ in range(cols)]
            delim = r.choice([",", ";", "\t", "|"])
            lines = [delim.join(header)]
            for _ in range(r.randint(0, 40)):
                lines.append(delim.join(r.choice(ALPH) for _ in range(r.randint(0, cols + 2))))
            body = "\n".join(lines)
            if r.random() < 0.1:
                body = bytes(r.randrange(256) for _ in range(r.randint(1, 400)))
            path = ingest.stage_bytes(s, body if isinstance(body, bytes) else body.encode("utf-8"))
            try:
                pv = ingest.preview(s, p, kind, "fuzz", path)
                outcomes["report"] += 1
                if pv["ready"]:
                    ingest.commit(s, p, pv["import_id"])
            except UdgassError:
                outcomes["refused"] += 1
        self.assertGreater(outcomes["report"], 50)
        self.assertGreater(outcomes["refused"], 10)

    def test_formula_like_text_is_stored_as_text_not_evaluated(self):
        d = tempfile.mkdtemp()
        s = Store(os.path.join(d, "f.db"))
        _, key = tenancy.create_org(s, "fuzz")
        p = tenancy.authenticate(s, key)
        path = ingest.stage_bytes(s, b"date,sku,quantity\n2024-01-01,=HYPERLINK(\"http://x\"),5\n")
        pv = ingest.preview(s, p, "sales", "fuzz", path)
        self.assertEqual(pv["sample"][0]["sku"], '=HYPERLINK("http://x")')


    def test_sql_metacharacters_are_data(self):
        from udgass.engine import memory
        d = tempfile.mkdtemp()
        s = Store(os.path.join(d, "f.db"))
        _, key = tenancy.create_org(s, "fuzz")
        p = tenancy.authenticate(s, key)
        evil = "x'); DROP TABLE demand;--"
        rows = "date,sku,quantity,location\n" + "".join("2024-01-%02d,\"%s\",3,\"%s\"\n" % (i, evil, evil) for i in range(1, 29))
        pv = ingest.preview(s, p, "sales", "fuzz", ingest.stage_bytes(s, rows.encode()))
        ingest.commit(s, p, pv["import_id"])
        w = memory.weekly_demand(s, p.org_id, skus=[evil], locations=[evil])
        self.assertIn((evil, evil), w["series"])
        self.assertEqual(s.conn().execute("SELECT COUNT(*) FROM demand").fetchone()[0], 28)
        with self.assertRaises(UdgassError):
            ingest.preview(s, p, "sales", "a'; DROP TABLE demand;--", ingest.stage_bytes(s, rows.encode()))


if __name__ == "__main__":
    unittest.main()
