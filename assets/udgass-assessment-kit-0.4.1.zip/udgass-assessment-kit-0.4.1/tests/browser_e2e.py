"""Real-browser end-to-end check of the web app (optional: needs `pip install playwright` and a Chromium).
Run: python3 tests/browser_e2e.py   It builds a SYNTHETIC demo database, serves it on a free local port and drives the UI:
import (with a rejected row and an ignored personal column), forecast run, explanation and rebuild, backtest, scenarios,
decision record, evaluation. Fails on any page error or error box."""
import asyncio, os, sys, tempfile, threading
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from http.server import ThreadingHTTPServer
from udgass.engine import api, workflow
from udgass.engine.db import Store


async def drive(base, key, tmp):
    from playwright.async_api import async_playwright
    async with async_playwright() as p:
        b = await p.chromium.launch()
        pg = await (await b.new_context(viewport={"width": 1280, "height": 900})).new_page()
        errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto(base); await pg.fill("#key", key); await pg.click("button[type=submit]"); await pg.wait_for_selector(".kpi")
        f = os.path.join(tmp, "messy.csv")
        open(f, "w").write("Posting Date,Material,Plant,Order Qty,Customer Email\n2026-03-23,M-1001,P-BLR,5,a@b.com\n2026-03-24,M-1001,P-BLR,-2,\n")
        await pg.click('#nav button:has-text("Data and imports")'); await pg.set_input_files("#file", f)
        await pg.click('button:has-text("Check file")'); await pg.wait_for_selector("text=negative quantity")
        await pg.click('button:has-text("Commit import")'); await pg.wait_for_selector("text=Committed:")
        await pg.click('#nav button:has-text("Forecasts")'); await pg.click('button:has-text("Create forecast run")')
        await pg.wait_for_selector("text=Forecasts in this run"); await pg.locator('h2:has-text("Forecasts in this run") + div tbody tr').first.click()
        await pg.click('button:has-text("Rebuild from what was known then")'); await pg.wait_for_selector("text=rebuilt exactly")
        await pg.click('#nav button:has-text("Backtest")'); await pg.click('button:has-text("Run backtest")'); await pg.wait_for_selector("text=Later half of the history", timeout=90000)
        await pg.click('#nav button:has-text("Scenarios")'); await pg.wait_for_timeout(800); await pg.click('button:has-text("Run scenarios")')
        await pg.wait_for_selector("text=Fill rate, 5th", timeout=90000)
        await pg.click('button:has-text("Start a decision record from this")'); await pg.fill('input[placeholder="name of the accountable person"]', "Planner")
        await pg.click('button:has-text("Open decision record")'); await pg.wait_for_selector("text=record intact")
        await pg.click('#nav button:has-text("Outcomes")'); await pg.click('button:has-text("Evaluate forecasts that are due")'); await pg.wait_for_selector("text=evaluated now")
        n_err = await pg.locator(".err").count()
        await b.close()
        assert not errs and n_err == 0, (errs, n_err)


def main():
    tmp = tempfile.mkdtemp()
    out = workflow.run_demo(os.path.join(tmp, "demo.db"), os.path.join(tmp, "data"), say=lambda *_: None)
    httpd = ThreadingHTTPServer(("127.0.0.1", 0), api.make_handler(api.App(Store(os.path.join(tmp, "demo.db")), log=open(os.devnull, "w"))))
    threading.Thread(target=httpd.serve_forever, daemon=True).start()
    asyncio.run(drive("http://127.0.0.1:%d/" % httpd.server_address[1], out["api_key"], tmp))
    httpd.shutdown()
    print("browser end-to-end: OK")


if __name__ == "__main__":
    main()
