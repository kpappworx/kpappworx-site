import json, os, tempfile, unittest
from udgass import audit, backtest, compare, data, demo, privacy, records
from udgass.cli import main


def tmp(name, text):
    d = tempfile.mkdtemp(); p = os.path.join(d, name)
    with open(p, "w") as f:
        f.write(text)
    return p


class Privacy(unittest.TestCase):
    H = "date,sku,quantity,%s\n"

    def scan(self, col, rows):
        return privacy.scan(tmp("a.csv", self.H % col + "\n".join("2024-01-01,A,5," + r for r in rows)), {"date", "sku", "quantity"})

    def test_flags_email_values_phone_values_and_pii_headers(self):
        self.assertTrue(self.scan("note", ["jo@x.com"]))
        self.assertTrue(self.scan("note", ["+91 98765 43210"]))
        self.assertTrue(self.scan("customer_email", ["x"]))

    def test_does_not_flag_ordinary_extra_columns(self):
        self.assertEqual(self.scan("warehouse", ["North 3", "East 1"]), [])
        self.assertEqual(self.scan("ship_date", ["2024-01-03"]), [])
        self.assertEqual(self.scan("price", ["1234567890.50"]), [])

    def test_loader_refuses_then_allows_with_override(self):
        p = tmp("a.csv", self.H % "customer_email" + "2024-01-01,A,5,a@b.co\n")
        with self.assertRaises(ValueError) as cm:
            data.load_csv(p)
        self.assertIn("personal data", str(cm.exception))
        self.assertIn("A", data.load_csv(p, allow_extra_columns=True).series)

    def test_cli_exits_2_on_personal_data(self):
        p = tmp("a.csv", self.H % "email" + "2024-01-01,A,5,a@b.co\n")
        self.assertEqual(main(["backtest", p, "--no-audit"]), 2)


class Audit(unittest.TestCase):
    def test_backtest_writes_verifiable_log_with_input_hash(self):
        d = tempfile.mkdtemp(); p = os.path.join(d, "s.csv"); demo.write_rich(p)
        log = os.path.join(d, "audit.jsonl")
        self.assertEqual(main(["backtest", p, "--out", os.path.join(d, "r.html"), "--audit-log", log]), 0)
        self.assertEqual(records.verify(log), (True, "ok"))
        e = json.loads(open(log).readline())
        self.assertEqual(e["data"]["input"]["sha256"], audit.sha(p))
        self.assertEqual(e["data"]["command"], "backtest")
        self.assertTrue(e["data"]["outputs"])

    def test_tampering_is_detected_and_no_audit_writes_nothing(self):
        d = tempfile.mkdtemp(); p = os.path.join(d, "s.csv"); demo.write_rich(p)
        log = os.path.join(d, "audit.jsonl")
        main(["backtest", p, "--out", os.path.join(d, "r.html"), "--audit-log", log])
        main(["detect", p, "--audit-log", log])
        s = open(log).read().replace('"backtest"', '"forged"', 1)
        open(log, "w").write(s)
        self.assertFalse(records.verify(log)[0])
        log2 = os.path.join(d, "none.jsonl")
        main(["detect", p, "--no-audit", "--audit-log", log2])
        self.assertFalse(os.path.exists(log2))


class Scores(unittest.TestCase):
    def test_interval_score_hand_check(self):
        rows = [{"low": 90, "high": 110, "actual": 100}, {"low": 90, "high": 110, "actual": 120}]
        # widths 20+20; miss of 10 above, penalty 2/0.2*10 = 100; mean 70; mean actual 110
        self.assertAlmostEqual(backtest.interval_score(rows, 0.8), 70 / 110, places=9)

    def test_wider_honest_range_beats_narrow_wrong_one(self):
        a = [{"low": 99, "high": 101, "actual": a} for a in (80, 120, 90, 115)]
        b = [{"low": 70, "high": 130, "actual": a} for a in (80, 120, 90, 115)]
        self.assertLess(backtest.interval_score(b), backtest.interval_score(a))

    def test_group_roll_up(self):
        rows = [dict(sku="A", as_of="2024-01-01", estimate=10, actual=14, baseline=12),
                dict(sku="B", as_of="2024-01-01", estimate=20, actual=16, baseline=18)]
        g = backtest.by_group(rows, {"A": "G", "B": "G"})
        self.assertAlmostEqual(g["groups"][0]["wape"], 0.0)         # errors cancel when added up: +4 and -4
        g2 = backtest.by_group(rows, {"A": "G"})
        self.assertEqual(g2["unmapped_products"], ["B"])


class Compare(unittest.TestCase):
    ROWS = [dict(sku="A", as_of="2024-01-01", estimate=100, actual=110, baseline=90, low=0, high=0),
            dict(sku="A", as_of="2024-01-29", estimate=100, actual=100, baseline=90, low=0, high=0)]

    def test_scores_only_matched_windows_and_prints_limits(self):
        c = compare.compare(self.ROWS, {("A", "2024-01-01"): 130.0})
        self.assertEqual(c["matched_windows"], 1)
        self.assertAlmostEqual(c["wape_udgass"], 10 / 110)
        self.assertAlmostEqual(c["wape_incumbent"], 20 / 110)
        self.assertEqual(c["windows_udgass_closer"], 1)
        self.assertTrue(any("snapshot" in l for l in c["limits"]))

    def test_no_match_is_an_error_not_a_zero(self):
        with self.assertRaises(ValueError):
            compare.compare(self.ROWS, {("Z", "2024-01-01"): 1.0})

    def test_incumbent_dates_snap_to_monday_and_cli_runs(self):
        d = tempfile.mkdtemp(); p = os.path.join(d, "s.csv"); demo.write_rich(p)
        ds = data.load_csv(p)
        rows = backtest.run(ds)["rows"][:3]
        inc = tmp("i.csv", "sku,as_of,forecast\n" + "".join("%s,%s,%s\n" % (r["sku"], r["as_of"], r["estimate"]) for r in rows))
        self.assertEqual(main(["compare-forecast", p, inc, "--no-audit"]), 0)
        bad = tmp("b.csv", "sku,when,forecast\nA,2024-01-01,1\n")
        self.assertEqual(main(["compare-forecast", p, bad, "--no-audit"]), 2)


class Promises(unittest.TestCase):
    def test_input_file_is_never_modified(self):
        d = tempfile.mkdtemp(); p = os.path.join(d, "s.csv"); demo.write_rich(p, os.path.join(d, "e.csv"))
        before = audit.sha(p); mt = os.stat(p).st_mtime_ns
        main(["backtest", p, "--out", os.path.join(d, "r.html"), "--no-audit"])
        main(["detect", p, "--no-audit"])
        self.assertEqual((before, mt), (audit.sha(p), os.stat(p).st_mtime_ns))

    def test_no_network_or_process_modules_are_imported(self):
        import glob, re
        banned = re.compile(r"^\s*(import|from)\s+(socket|urllib|http|requests|ftplib|smtplib|subprocess|ssl|asyncio)\b", re.M)
        root = os.path.join(os.path.dirname(__file__), "..", "udgass")
        files = glob.glob(os.path.join(root, "*.py")) + glob.glob(os.path.join(root, "engine", "*.py"))
        self.assertGreater(len(files), 20)
        for f in files:
            if f.endswith(os.path.join("engine", "api.py")):
                continue        # the local API server is the one module allowed to open a listening socket; it makes no outbound calls
            with open(f) as fh:
                self.assertIsNone(banned.search(fh.read()), f)


class RealWorldFiles(unittest.TestCase):
    def rows(self, sep, datefmt):
        from datetime import date, timedelta
        out = [sep.join(["Order Date", "Item", "Units"])]
        for w in range(70):
            d = date(2023, 1, 2) + timedelta(weeks=w)
            out.append(sep.join([d.strftime(datefmt), "A", "1,234" if w == 0 else str(100 + w)]))
        return "\n".join(out) + "\n"

    def test_semicolon_and_dmy_dates_and_thousands_separator(self):
        p = tmp("x.csv", self.rows(";", "%d/%m/%Y").replace("1,234", '"1,234"'))
        ds = data.load_csv(p, date_format="%d/%m/%Y")
        self.assertEqual(ds.quality["weeks"], 70)
        self.assertEqual(ds.series["A"][0], 1234.0)

    def test_tab_delimited(self):
        ds = data.load_csv(tmp("x.tsv", self.rows("\t", "%Y-%m-%d").replace("1,234", "1234")))
        self.assertEqual(ds.quality["skus"], 1)

    def test_check_command_changes_nothing_and_reports(self):
        p = tmp("x.csv", self.rows(",", "%Y-%m-%d").replace("1,234", "1234"))
        before = audit.sha(p)
        self.assertEqual(main(["check", p]), 0)
        self.assertEqual(audit.sha(p), before)
        short = tmp("s.csv", "date,sku,quantity\n2024-01-01,A,5\n")
        self.assertEqual(main(["check", short]), 0)
        self.assertEqual(main(["check", "/nope.csv"]), 2)


if __name__ == "__main__":
    unittest.main()
