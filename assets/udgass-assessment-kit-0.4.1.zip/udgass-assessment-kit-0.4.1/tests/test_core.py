import csv, json, os, random, tempfile, unittest, math
from datetime import date, timedelta
from udgass import backtest, data, forecast, records, demo, report
from udgass.cli import main


def series(n=120, seed=1):
    r = random.Random(seed)
    return [100 + 10 * math.sin(2 * math.pi * i / 52) + r.gauss(0, 5) for i in range(n)]


class Forecast(unittest.TestCase):
    def test_no_leakage_future_values_cannot_change_an_estimate(self):
        y = series()
        a = forecast.forecast_total(y[:90], 4)
        y2 = y[:90] + [10_000.0] * 30          # wildly different future
        b = forecast.forecast_total(y2[:90], 4)
        self.assertEqual(a, b)

    def test_backtest_uses_only_past(self):
        y = series(130)
        ds1 = data.Dataset({"X": y}, date(2022, 1, 3))
        y_alt = y[:100] + [5000.0] * 30
        ds2 = data.Dataset({"X": y_alt}, date(2022, 1, 3))
        r1 = backtest.run(ds1, 4, 4, 52)["rows"]
        r2 = backtest.run(ds2, 4, 4, 52)["rows"]
        for a, b in zip(r1, r2):
            if a["origin"] + 4 <= 100:           # windows fully before the change must be identical
                self.assertEqual((a["estimate"], a["low"], a["high"]), (b["estimate"], b["low"], b["high"]))

    def test_range_contains_point_and_is_nonnegative(self):
        for s in range(5):
            e = forecast.forecast_total(series(100, s), 4)
            self.assertTrue(0 <= e["low"] <= e["point"] <= e["high"] or e["low"] <= e["high"])
            self.assertGreaterEqual(e["low"], 0)

    def test_short_history_is_marked_thin_with_wide_range(self):
        e = forecast.forecast_total([10.0] * 20, 4)
        self.assertEqual(e["evidence_quality"], "thin")
        self.assertGreater(e["high"] - e["low"], 0.9 * e["point"])

    def test_quantile(self):
        self.assertEqual(forecast.quantile([1, 2, 3, 4, 5], 0.5), 3)
        self.assertEqual(forecast.quantile([5], 0.9), 5)


class Loader(unittest.TestCase):
    def write(self, rows, header=("date", "sku", "quantity")):
        f = tempfile.NamedTemporaryFile("w", suffix=".csv", delete=False, newline="")
        w = csv.writer(f); w.writerow(header); w.writerows(rows); f.close()
        self.addCleanup(os.unlink, f.name)
        return f.name

    def test_weekly_aggregation_missing_weeks_and_quality(self):
        p = self.write([("2024-01-01", "A", 5), ("2024-01-03", "A", 7), ("2024-01-22", "A", 4), ("bad", "A", 1), ("2024-01-08", "A", "x")])
        ds = data.load_csv(p)
        self.assertEqual(ds.series["A"], [12.0, 0.0, 0.0, 4.0])
        self.assertEqual(ds.quality["missing_weeks_filled_with_zero"], 2)
        self.assertEqual(ds.quality["rows_skipped"], {"unreadable date": 1, "unreadable quantity": 1})
        self.assertEqual(len(ds.sha256), 64)

    def test_negative_weeks_clamped_and_disclosed(self):
        ds = data.load_csv(self.write([("2024-01-01", "A", 5), ("2024-01-08", "A", -3)]))
        self.assertEqual(ds.series["A"], [5.0, 0.0]); self.assertEqual(ds.quality["weeks_negative_clamped_to_zero"], 1)

    def test_clear_error_on_missing_columns(self):
        with self.assertRaises(ValueError):
            data.load_csv(self.write([("a", "b")], header=("foo", "bar")))

    def test_source_file_is_not_modified(self):
        p = self.write([("2024-01-01", "A", 5)])
        before = open(p, "rb").read(); data.load_csv(p)
        self.assertEqual(before, open(p, "rb").read())


class Ledger(unittest.TestCase):
    def setUp(self):
        d = tempfile.mkdtemp(); self.p = os.path.join(d, "l.jsonl")
        records.add(self.p, "decision", {"id": "DR-1", "title": "t", "owner": "role", "as_of": "2024-03-03",
                                         "estimate": {"point": 5000, "low": 4200, "high": 6100}})

    def test_chain_verifies_and_detects_tampering(self):
        records.add(self.p, "action", {"decision_id": "DR-1", "text": "ordered"})
        self.assertEqual(records.verify(self.p), (True, "ok"))
        txt = open(self.p).read().replace("ordered", "reordered")
        open(self.p, "w").write(txt)
        self.assertFalse(records.verify(self.p)[0])
        with self.assertRaises(ValueError):
            records.add(self.p, "outcome", {"decision_id": "DR-1", "realised": 1})

    def test_variance_computed_not_stored(self):
        records.add(self.p, "outcome", {"decision_id": "DR-1", "realised": 5450})
        v = records.view(self.p, "DR-1")
        self.assertEqual(v["variance"]["absolute"], 450)
        self.assertAlmostEqual(v["variance"]["percent"], 9.0)
        self.assertTrue(v["variance"]["inside_range"])
        self.assertNotIn("variance", open(self.p).read())

    def test_outside_range_is_recorded_the_same_way(self):
        records.add(self.p, "outcome", {"decision_id": "DR-1", "realised": 7000})
        self.assertFalse(records.view(self.p, "DR-1")["variance"]["inside_range"])

    def test_validation(self):
        with self.assertRaises(ValueError): records.add(self.p, "decision", {"id": "DR-1", "title": "t", "owner": "o", "as_of": "x", "estimate": {"point": 1, "low": 0, "high": 2}})
        with self.assertRaises(ValueError): records.add(self.p, "decision", {"id": "DR-2", "title": "t", "owner": "o", "as_of": "x", "estimate": {"point": 5, "low": 6, "high": 7}})
        with self.assertRaises(ValueError): records.add(self.p, "action", {"decision_id": "nope", "text": "x"})
        records.add(self.p, "outcome", {"decision_id": "DR-1", "realised": 1})
        with self.assertRaises(ValueError): records.add(self.p, "outcome", {"decision_id": "DR-1", "realised": 2})


class EndToEnd(unittest.TestCase):
    def test_cli_backtest_report_is_honest_and_complete(self):
        d = tempfile.mkdtemp(); csvp = os.path.join(d, "s.csv"); out = os.path.join(d, "r.html"); js = os.path.join(d, "r.json")
        demo.write(csvp)
        self.assertEqual(main(["backtest", csvp, "--out", out, "--json", js, "--no-audit"]), 0)
        h = open(out).read()
        for must in ("Largest misses", "SHA-256", "does not show how it will perform on future data", "Weeks filled with zero"):
            self.assertIn(must, h)
        r = json.load(open(js)); s = r["summary"]
        self.assertGreater(s["n_estimates"], 50)
        self.assertTrue(0.55 <= s["coverage"] <= 1.0)

    def test_cli_errors_cleanly(self):
        self.assertEqual(main(["backtest", "/nonexistent.csv", "--no-audit"]), 2)
        d = tempfile.mkdtemp(); p = os.path.join(d, "s.csv"); demo.write(p, weeks=30)
        self.assertEqual(main(["backtest", p, "--out", os.path.join(d, "o.html"), "--no-audit"]), 2)   # not enough history

    def test_deterministic(self):
        d = tempfile.mkdtemp(); p = os.path.join(d, "s.csv"); demo.write(p)
        a = backtest.run(data.load_csv(p))["summary"]; b = backtest.run(data.load_csv(p))["summary"]
        self.assertEqual(a, b)


if __name__ == "__main__":
    unittest.main()
