"""Context for an exception. Reports what COINCIDES with it in data the user supplied. It never claims a cause."""
from __future__ import annotations
import csv
from .data import delimiter
from datetime import date, datetime, timedelta


def load_events(path, date_format="%Y-%m-%d"):
    ev = []
    with open(path, newline="", encoding="utf-8-sig") as f:
        for r in csv.DictReader(f, delimiter=delimiter(path)):
            try:
                a = datetime.strptime(r["start"].strip(), date_format).date()
                b = datetime.strptime((r.get("end") or r["start"]).strip(), date_format).date()
            except (KeyError, ValueError):
                continue
            ev.append({"sku": (r.get("sku") or "").strip(), "start": a, "end": b, "type": (r.get("type") or "event").strip()})
    return ev


def context(sku, week, events, series, index, window_weeks=2):
    """week: date of the exception's week. Returns coinciding events and data-quality notes."""
    lo, hi = week - timedelta(weeks=window_weeks), week + timedelta(weeks=1)
    hits = [e for e in events if (e["sku"] in ("", sku, "*")) and e["start"] <= hi and e["end"] >= lo]
    notes = []
    if series[index] == 0 and index > 0 and series[index - 1] > 0:
        notes.append("Sales were zero this week after a normal week. Check for a stock-out or a missing export: either would make demand look lower than it was.")
    if index + 1 < len(series) and series[index] > 0 and series[index + 1] == 0:
        notes.append("Sales drop to zero the following week.")
    return {"coinciding_events": hits, "data_notes": notes,
            "reading": ("Coincides with %d recorded event(s). That is an association in the data you provided, not proof of cause." % len(hits)) if hits
            else "Nothing in the supplied events coincides with this. The cause is unexplained by the data available."}
