"""Controlled deletion and export of an organisation's data."""
from __future__ import annotations
import json, os
from .db import dumps, ts
from .errors import Invalid
from .tenancy import require

TABLES = ["decision_log", "decisions", "scenarios", "findings", "forecast_evaluations", "forecasts", "forecast_runs", "backtests",
          "policy_log", "policies", "events", "purchase_orders", "inventory", "demand", "products", "locations", "suppliers",
          "imports", "data_sources", "idempotency", "audit_log", "api_keys"]


def purge_org(store, p, confirm_name, actor_note=""):
    """Delete every row belonging to the organisation, in one transaction. Irreversible. A purge record (counts only) is kept."""
    require(p, "admin")
    c = store.conn()
    name = c.execute("SELECT name FROM organizations WHERE id=?", (p.org_id,)).fetchone()[0]
    if confirm_name != name:
        raise Invalid("to purge, pass confirm equal to the organisation name exactly")
    counts = {}
    with store.tx() as c:
        c.execute("INSERT INTO purge_lock VALUES(?)", (p.org_id,))
        for t in TABLES:
            counts[t] = c.execute("DELETE FROM %s WHERE org_id=?" % t, (p.org_id,)).rowcount
        c.execute("DELETE FROM organizations WHERE id=?", (p.org_id,))
        c.execute("DELETE FROM purge_lock WHERE org_id=?", (p.org_id,))
        c.execute("INSERT INTO purges(org_id,at,actor,counts_json) VALUES(?,?,?,?)", (p.org_id, ts(), p.actor, dumps(counts)))
    staging = os.path.join(store.data_dir or "", "udgass-staging")
    return {"purged": p.org_id, "rows_deleted": counts, "note": "Staged files of uncommitted previews expire separately within 24 hours. "
            "Database backups taken before the purge still contain the data until they rotate out."}


def export_org(store, p, out_dir):
    """Write every table's rows for this organisation as JSON lines. Secrets (key hashes) are excluded."""
    require(p, "admin")
    os.makedirs(out_dir, exist_ok=True)
    c = store.conn()
    counts = {}
    for t in TABLES:
        if t in ("api_keys", "idempotency"):
            continue
        n = 0
        with open(os.path.join(out_dir, t + ".jsonl"), "w", encoding="utf-8") as f:
            for r in c.execute("SELECT * FROM %s WHERE org_id=?" % t, (p.org_id,)):
                f.write(json.dumps(dict(r), default=str) + "\n"); n += 1
        counts[t] = n
    return counts
