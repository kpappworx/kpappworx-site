"""Versioned local HTTP API (standard library only).

Security model
- Every /v1 route except /v1/health needs `Authorization: Bearer <key>`. The organisation comes from the key only.
- Roles are enforced in the engine functions themselves, so the API cannot forget a check.
- Binds to 127.0.0.1 by default. Serving on a network address requires TLS, or an explicit unsafe flag.
- Request bodies are size-limited; uploads need Content-Length. JSON bodies are limited to 1 MB.
- Per-key and per-address rate limits. Errors never include stack traces or data rows.
- Structured JSON logs to stderr: request id, route, status, latency, organisation and key ids. No bodies, no keys.
"""
from __future__ import annotations
import json, os, re, ssl, sys, threading, time, traceback, uuid
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse
from .. import __version__
from .errors import Invalid, MethodNotAllowed, NotFound, RateLimited, TooLarge, Unauthorized, UdgassError
from . import audit, decisions, evaluation, forecasting, governance, ingest, memory, patterns, scenarios, tenancy
from .db import dumps, ts

JSON_LIMIT = 1 << 20
WEB = os.path.join(os.path.dirname(__file__), "web")


class Bucket:
    def __init__(self, rate, burst):
        self.rate, self.burst, self.state, self.lock = rate, burst, {}, threading.Lock()

    def take(self, key):
        now = time.monotonic()
        with self.lock:
            tokens, last = self.state.get(key, (self.burst, now))
            tokens = min(self.burst, tokens + (now - last) * self.rate)
            if tokens < 1:
                self.state[key] = (tokens, now)
                return False
            self.state[key] = (tokens - 1, now)
            return True


class Ctx:
    def __init__(self, app, method, path, query, headers, rfile, groups, request_id):
        self.app, self.method, self.path, self.query, self.headers, self.rfile = app, method, path, query, headers, rfile
        self.g, self.request_id, self.p, self._json = groups, request_id, None, None

    def q(self, name, default=None, cast=str):
        v = self.query.get(name, [default])[0]
        if v is None or v == "":
            return default
        try:
            return cast(v)
        except (TypeError, ValueError):
            raise Invalid("query parameter %s is not valid" % name)

    def body(self):
        if self._json is None:
            n = int(self.headers.get("Content-Length") or 0)
            if n > JSON_LIMIT:
                left = min(n, 16 * JSON_LIMIT)     # read (and discard) a moderately oversized body so the client receives the 413 instead of a broken pipe
                while left > 0:
                    chunk = self.rfile.read(min(65536, left))
                    if not chunk:
                        break
                    left -= len(chunk)
                raise TooLarge("JSON body over 1 MB")
            raw = self.rfile.read(n) if n else b"{}"
            try:
                self._json = json.loads(raw.decode("utf-8") or "{}")
            except (UnicodeDecodeError, json.JSONDecodeError):
                raise Invalid("body is not valid JSON")
            if not isinstance(self._json, dict):
                raise Invalid("body must be a JSON object")
        return self._json


def _b(x):
    return x in (True, "true", "1", 1)


class App:
    def __init__(self, store, log=sys.stderr, key_rate=(20, 60), ip_rate=(0.2, 10)):
        self.store, self.log = store, log
        self.key_bucket, self.fail_bucket = Bucket(*key_rate), Bucket(*ip_rate)
        self.metrics, self.mlock = {}, threading.Lock()
        S = self.store
        R = []

        def r(method, pattern, fn, auth=True, idem=False):
            R.append((method, re.compile("^" + pattern + "$"), fn, auth, idem, pattern))

        r("GET", "/v1/health", lambda c: {"status": "ok", "engine_version": __version__, "schema_version": S.version()}, auth=False)
        r("GET", "/v1/me", lambda c: tenancy.org_info(S, c.p))
        r("GET", "/v1/keys", lambda c: {"items": tenancy.list_keys(S, c.p)})
        r("POST", "/v1/keys", lambda c: tenancy.create_key(S, c.p, c.body().get("role"), c.body().get("label", ""), c.request_id))
        r("DELETE", "/v1/keys/([\\w]+)", lambda c: tenancy.revoke_key(S, c.p, c.g[0], c.request_id))
        r("POST", "/v1/imports", self._upload, idem=False)
        r("GET", "/v1/imports", lambda c: ingest.list_imports(S, c.p, c.q("limit", 50, int), c.q("cursor")))
        r("GET", "/v1/imports/([\\w]+)", lambda c: ingest.get_import(S, c.p, c.g[0]))
        r("POST", "/v1/imports/([\\w]+)/commit", lambda c: ingest.commit(S, c.p, c.g[0], c.body().get("mapping"), c.body().get("date_format"),
                                                                        c.body().get("options"), c.request_id), idem=True)
        r("GET", "/v1/products", self._products)
        r("GET", "/v1/history", lambda c: memory.history(S, c.p, c.q("sku"), c.q("location", "ALL"), c.q("as_known_at")))
        r("GET", "/v1/records/(demand|inventory|purchase_orders|events)", lambda c: {"versions": memory.record_versions(S, c.p, c.g[0], c.q("record_key"), c.q("source"))})
        r("POST", "/v1/patterns/runs", lambda c: patterns.run(S, c.p, c.body().get("as_known_at"), c.body().get("sensitivity", "balanced"),
                                                             c.body().get("by_location", True), c.request_id), idem=True)
        r("GET", "/v1/findings", lambda c: patterns.list_findings(S, c.p, c.q("run_id"), c.q("kind"), c.q("limit", 100, int), c.q("offset", 0, int)))
        r("GET", "/v1/policies", lambda c: forecasting.list_policies(S, c.p))
        r("POST", "/v1/policies", lambda c: forecasting.create_policy(S, c.p, c.body().get("name"), c.body().get("methods"), c.request_id))
        r("POST", "/v1/policies/([\\w]+)/promote", lambda c: forecasting.promote(S, c.p, c.g[0], c.body().get("backtest_id"), c.request_id))
        r("POST", "/v1/policies/rollback", lambda c: forecasting.rollback(S, c.p, c.request_id))
        r("POST", "/v1/backtests", lambda c: self._backtest(c), idem=True)
        r("GET", "/v1/backtests/([\\w]+)", lambda c: self._bt_get(c))
        r("POST", "/v1/forecast-runs", lambda c: forecasting.create_run(S, c.p, c.body().get("horizon", 4), c.body().get("level", 0.8),
                                                                       c.body().get("as_known_at"), None, c.body().get("skus"),
                                                                       c.body().get("by_location", True), c.body().get("min_history", forecasting.MIN_HISTORY),
                                                                       c.body().get("note", ""), c.request_id), idem=True)
        r("GET", "/v1/forecast-runs", lambda c: forecasting.list_runs(S, c.p, c.q("limit", 50, int), c.q("cursor")))
        r("GET", "/v1/forecast-runs/([\\w]+)", lambda c: forecasting.get_run(S, c.p, c.g[0]))
        r("GET", "/v1/forecast-runs/([\\w]+)/forecasts", lambda c: forecasting.list_forecasts(S, c.p, c.g[0], c.q("sku"), c.q("limit", 100, int), c.q("cursor")))
        r("GET", "/v1/forecasts/([\\w]+)", lambda c: forecasting.explain(S, c.p, c.g[0]))
        r("GET", "/v1/forecasts/([\\w]+)/reconstruct", lambda c: forecasting.reconstruct(S, c.p, c.g[0]))
        r("POST", "/v1/evaluations", lambda c: evaluation.evaluate_due(S, c.p, c.body().get("as_known_at"), c.request_id), idem=True)
        r("GET", "/v1/performance", lambda c: evaluation.performance(S, c.p))
        r("POST", "/v1/scenarios", self._scenario, idem=True)
        r("GET", "/v1/scenarios", lambda c: scenarios.list_scenarios(S, c.p, c.q("limit", 50, int)))
        r("GET", "/v1/scenarios/([\\w]+)", lambda c: scenarios.get(S, c.p, c.g[0]))
        r("POST", "/v1/decisions", self._decision, idem=True)
        r("GET", "/v1/decisions", lambda c: decisions.list_decisions(S, c.p, c.q("limit", 50, int), c.q("cursor")))
        r("GET", "/v1/decisions/([\\w]+)", lambda c: decisions.get(S, c.p, c.g[0]))
        r("POST", "/v1/decisions/([\\w]+)/entries", lambda c: decisions.add_entry(S, c.p, c.g[0], c.body().get("type"), c.body().get("payload") or {}, c.request_id), idem=True)
        r("GET", "/v1/decisions/([\\w]+)/evaluation", lambda c: decisions.evaluate(S, c.p, c.g[0]))
        r("GET", "/v1/decisions/([\\w]+)/verify", lambda c: decisions.verify(S, c.p, c.g[0]))
        r("GET", "/v1/audit", lambda c: audit.list_entries(S, c.p, c.q("limit", 100, int), c.q("cursor")))
        r("GET", "/v1/metrics", self._metrics_view)
        r("POST", "/v1/admin/purge", lambda c: governance.purge_org(S, c.p, c.body().get("confirm")))
        self.routes = R

    # ----- handlers needing more than one line -----
    def _upload(self, c):
        n = c.headers.get("Content-Length")
        if n is None:
            raise Invalid("Content-Length is required for uploads")
        n = int(n)
        if n > ingest.MAX_BYTES:
            raise TooLarge("file is larger than %d MB" % (ingest.MAX_BYTES // 2**20))
        mapping = c.q("mapping")
        try:
            mapping = json.loads(mapping) if mapping else None
        except json.JSONDecodeError:
            raise Invalid("mapping must be JSON, for example {\"sku\":\"Material\"}")
        tenancy.require(c.p, "analyst")
        path = ingest.stage_stream(self.store, c.rfile, n)
        try:
            return ingest.preview(self.store, c.p, c.q("kind"), c.q("source"), path, c.q("file_name", "upload.csv"), mapping,
                                  c.q("date_format"), {"duplicate_rows": c.q("duplicate_rows", "keep"), "decimal_comma": _b(c.q("decimal_comma"))},
                                  c.request_id)
        finally:
            if os.path.exists(path):
                os.unlink(path)

    def _products(self, c):
        lim = max(1, min(c.q("limit", 100, int), 500))
        q, a = "SELECT sku, category, unit, created_at FROM products WHERE org_id=?", [c.p.org_id]
        if c.q("cursor"):
            q += " AND sku > ?"; a.append(c.q("cursor"))
        items = [dict(r) for r in self.store.conn().execute(q + " ORDER BY sku LIMIT ?", a + [lim])]
        locs = [r[0] for r in self.store.conn().execute("SELECT code FROM locations WHERE org_id=? ORDER BY code", (c.p.org_id,))]
        return {"items": items, "locations": locs, "next_cursor": items[-1]["sku"] if len(items) == lim else None}

    def _backtest(self, c):
        b = c.body()
        return forecasting.run_backtest(self.store, c.p, b.get("horizon", 4), b.get("step", 4), b.get("min_train", 52), b.get("level", 0.8),
                                        b.get("candidate_policy_id"), b.get("as_known_at"), b.get("by_location", True), b.get("skus"), c.request_id)

    def _bt_get(self, c):
        bt = forecasting.get_backtest(self.store, c.p, c.g[0])
        bt["leaderboard_test"] = forecasting.leaderboard(bt, "test")
        bt["leaderboard_all"] = forecasting.leaderboard(bt, "all")
        return bt

    def _scenario(self, c):
        b = c.body()
        return scenarios.create(self.store, c.p, b.get("sku"), b.get("location", "ALL"), b.get("name", "scenario"), b.get("forecast_id"),
                                b.get("weeks", 13), b.get("runs", 1000), b.get("seed", 1), b.get("policy"), b.get("costs"), b.get("constraints"),
                                b.get("variants"), b.get("start_stock"), None, c.request_id)

    def _decision(self, c):
        b = c.body()
        return decisions.create(self.store, c.p, b.get("title"), b.get("owner"), b.get("decision_type", "inventory_replenishment"), b.get("sku"),
                                b.get("location"), b.get("forecast_ids") or [], b.get("scenario_ids") or [], b.get("options") or [],
                                b.get("assumptions"), b.get("constraints"), b.get("objective"), b.get("risk_tolerance"), b.get("evidence_notes", ""), c.request_id)

    def _metrics_view(self, c):
        tenancy.require(c.p, "admin")
        with self.mlock:
            out = {}
            for k, v in self.metrics.items():
                lat = sorted(v["ms"])
                out[k] = {"count": v["n"], "by_status": v["status"], "p50_ms": lat[len(lat) // 2] if lat else None,
                          "p95_ms": lat[int(len(lat) * 0.95)] if lat else None}
        return {"routes": out, "note": "Process-local counters since start, all organisations; no data values."}

    # ----- dispatch -----
    def handle(self, method, raw_path, headers, rfile, client="local"):
        """Returns (status, content_type, body_bytes, extra_headers)."""
        rid = (headers.get("X-Request-Id") or "")[:64]
        rid = rid if re.match(r"^[\w.-]{8,64}$", rid or "") else uuid.uuid4().hex
        t0 = time.monotonic()
        u = urlparse(raw_path)
        route_name, status, org, kid = "unmatched", 500, None, None
        try:
            if method == "GET" and not u.path.startswith("/v1/"):
                status, ctype, body = self._static(u.path)
                route_name = "static"
                return status, ctype, body, {"X-Request-Id": rid}
            for m, rx, fn, auth, idem, pat in self.routes:
                mt = rx.match(u.path)
                if mt and m == method:
                    route_name = "%s %s" % (m, pat)
                    ctx = Ctx(self, method, u.path, parse_qs(u.query), headers, rfile, mt.groups(), rid)
                    if auth:
                        h = headers.get("Authorization") or ""
                        try:
                            ctx.p = tenancy.authenticate(self.store, h[7:].strip() if h.startswith("Bearer ") else "")
                        except Unauthorized:
                            if not self.fail_bucket.take(client):
                                raise RateLimited("too many failed authentication attempts; wait a minute")
                            raise
                        org, kid = ctx.p.org_id, ctx.p.key_id
                        if not self.key_bucket.take(kid):
                            raise RateLimited("rate limit exceeded for this key")
                    ik = headers.get("Idempotency-Key")
                    if idem and ik and ctx.p:
                        if not re.match(r"^[\w.:-]{8,100}$", ik):
                            raise Invalid("Idempotency-Key must be 8 to 100 letters, digits or . _ : -")
                        prev = self.store.conn().execute("SELECT endpoint, response_json, status FROM idempotency WHERE org_id=? AND key=?", (org, ik)).fetchone()
                        if prev:
                            if prev["endpoint"] != route_name + ":" + u.path:
                                raise Invalid("Idempotency-Key was already used for a different request")
                            status = prev["status"]
                            return status, "application/json", prev["response_json"].encode(), {"X-Request-Id": rid, "Idempotent-Replay": "true"}
                    res = fn(ctx)
                    status = 201 if method == "POST" else 200
                    body = dumps(res)
                    if idem and ik and ctx.p:
                        with self.store.tx() as cc:
                            cc.execute("INSERT OR IGNORE INTO idempotency VALUES(?,?,?,?,?,?)", (org, ik, route_name + ":" + u.path, body, status, ts()))
                    return status, "application/json", body.encode(), {"X-Request-Id": rid}
            allowed = [m for m, rx, *_ in self.routes if rx.match(u.path)]
            if allowed:
                raise MethodNotAllowed("method not allowed")
            raise NotFound("no such endpoint")
        except UdgassError as e:
            status = e.status
            body = dumps({"error": {"code": e.code, "message": e.message, "details": e.details, "request_id": rid}})
            return status, "application/json", body.encode(), {"X-Request-Id": rid}
        except Exception:
            status = 500
            self._log({"level": "error", "request_id": rid, "route": route_name, "trace": traceback.format_exc(limit=8)})
            body = dumps({"error": {"code": "internal", "message": "internal error; quote the request id when reporting it", "request_id": rid}})
            return 500, "application/json", body.encode(), {"X-Request-Id": rid}
        finally:
            ms = round((time.monotonic() - t0) * 1000, 1)
            self._log({"level": "info", "request_id": rid, "method": method, "route": route_name, "status": status, "ms": ms, "org": org, "key": kid})
            with self.mlock:
                m = self.metrics.setdefault(route_name, {"n": 0, "status": {}, "ms": []})
                m["n"] += 1; m["status"][str(status)] = m["status"].get(str(status), 0) + 1
                m["ms"].append(ms); m["ms"] = m["ms"][-1000:]

    def _static(self, path):
        name = {"/": "index.html", "/app.js": "app.js", "/app.css": "app.css"}.get(path)
        if not name:
            return 404, "text/plain", b"not found"
        with open(os.path.join(WEB, name), "rb") as f:
            data = f.read()
        ctype = {"html": "text/html; charset=utf-8", "js": "text/javascript; charset=utf-8", "css": "text/css; charset=utf-8"}[name.rsplit(".", 1)[1]]
        return 200, ctype, data

    def _log(self, rec):
        rec["ts"] = ts()
        try:
            self.log.write(json.dumps(rec) + "\n"); self.log.flush()
        except Exception:
            pass


def make_handler(app):
    class H(BaseHTTPRequestHandler):
        server_version = "udgass"
        sys_version = ""
        protocol_version = "HTTP/1.1"

        def _go(self):
            status, ctype, body, extra = app.handle(self.command, self.path, self.headers, self.rfile, self.client_address[0])
            self.send_response(status)
            self.send_header("Content-Type", ctype)
            self.send_header("Content-Length", str(len(body)))
            self.send_header("X-Content-Type-Options", "nosniff")
            self.send_header("Referrer-Policy", "no-referrer")
            self.send_header("Cache-Control", "no-store")
            if ctype.startswith("text/html"):
                self.send_header("Content-Security-Policy", "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; "
                                 "connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'")
                self.send_header("X-Frame-Options", "DENY")
            for k, v in extra.items():
                self.send_header(k, v)
            self.end_headers()
            self.wfile.write(body)

        do_GET = do_POST = do_DELETE = do_PUT = do_PATCH = _go

        def log_message(self, *a):
            pass
    return H


def serve(store, host="127.0.0.1", port=8765, tls_cert=None, tls_key=None, allow_plain_http_on_network=False, ready=None):
    loopback = host in ("127.0.0.1", "localhost", "::1")
    if not loopback and not tls_cert and not allow_plain_http_on_network:
        raise SystemExit("Refusing to serve on %s without TLS. Pass --tls-cert and --tls-key (or, for a closed lab network only, "
                         "--allow-plain-http-on-network)." % host)
    app = App(store)
    httpd = ThreadingHTTPServer((host, port), make_handler(app))
    httpd.daemon_threads = True
    if tls_cert:
        ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        ctx.minimum_version = ssl.TLSVersion.TLSv1_2
        ctx.load_cert_chain(tls_cert, tls_key)
        httpd.socket = ctx.wrap_socket(httpd.socket, server_side=True)
    if ready:
        ready(httpd)
    try:
        httpd.serve_forever()
    finally:
        httpd.server_close()
