"""Demand assessment: one command, run by the company on its own machine, that turns its exports into a report.

    udgass assess --sales sales.csv [--inventory stock.csv] [--purchase-orders po.csv] [--events events.csv]
                  [--incumbent our_forecasts.csv] --out assessment.html

What it does: validates and maps the files (the same pipeline as the engine), measures data quality, replays history
with rolling origins, compares Udgass with three simple baselines (and with the company's own forecasts when given),
lists where estimates fail, states which inventory questions the data can and cannot answer, and gives an ADVISORY view
on whether a pilot is justified. The company decides.

Privacy: everything runs locally in a temporary database that is deleted afterwards. Nothing is sent anywhere. The report
contains the company's product codes and figures unless --anonymise is used. The "publishable summary" holds only relative
metrics (no product names, no volumes). Publishing anything is a separate, optional permission that needs the company's written approval.
"""
from __future__ import annotations
import hashlib, html, json, os, re, shutil, tempfile
from datetime import datetime, timezone
from .. import __version__
from .db import Store
from .errors import InsufficientData, UdgassError
from . import forecasting, ingest, memory, patterns, tenancy

KINDS = [("sales", "sales"), ("inventory", "inventory"), ("purchase_orders", "purchase orders"), ("events", "events")]


class NotReady(Exception):
    def __init__(self, issues):
        super().__init__("; ".join(issues))
        self.issues = issues


def _sha(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for b in iter(lambda: f.read(1 << 20), b""):
            h.update(b)
    return h.hexdigest()


def _imp(store, p, kind, path, mapping, date_format, options):
    pv = ingest.preview(store, p, kind, "customer", path, os.path.basename(path), mapping or None, date_format, options)
    r = pv["report"]
    info = {"kind": kind, "file": os.path.basename(path), "sha256": _sha(path), "ready": pv["ready"], "report": r}
    if not pv["ready"]:
        issues = []
        for f, cands in (r.get("ambiguous") or {}).items():
            issues.append("column for %s is ambiguous (%s); pass --map %s:%s=<column>" % (f, " / ".join(cands), kind, f))
        for f in r.get("missing_required") or []:
            issues.append("no column found for %s; columns are: %s; pass --map %s:%s=<column>" % (f, ", ".join(r["columns"]), kind, f))
        for f, d in (r.get("date_format_issues") or {}).items():
            issues.append("%s: %s%s" % (f, d["message"], (" (candidates %s); pass --date-format" % ", ".join(d["candidates"])) if d["candidates"] else ""))
        if r.get("blocking"):
            issues.append(r["blocking"])
        info["issues"] = issues
        return info
    ingest.commit(store, p, pv["import_id"])
    return info


def run(files, out_html, out_json=None, mappings=None, date_format=None, options=None, incumbent=None, company="",
        horizon=4, anonymise=False, level=0.8, say=print, banner=None):
    """files: {kind: path}. Returns the summary dict. Raises NotReady (after writing a report) if sales cannot be used."""
    if "sales" not in files:
        raise UdgassError("a sales file is required (--sales)")
    tmp = tempfile.mkdtemp(prefix="udgass-assess-")
    try:
        store = Store(os.path.join(tmp, "assess.db"))
        _, key = tenancy.create_org(store, company or "assessment")
        p = tenancy.authenticate(store, key)
        imports = {}
        for kind, _label in KINDS:
            if kind in files:
                say("checking %s ..." % files[kind])
                imports[kind] = _imp(store, p, kind, files[kind], (mappings or {}).get(kind), date_format, options)
        s = imports["sales"]
        if not s["ready"]:
            summary = {"status": "data_not_ready", "issues": s["issues"], "imports": _imp_summary(imports)}
            _write(out_html, out_json, summary, company, anonymise, banner)
            raise NotReady(s["issues"])
        summary = _analyse(store, p, imports, incumbent, horizon, level, say)
        summary["status"] = "complete"
        _write(out_html, out_json, summary, company, anonymise, banner)
        return summary
    finally:
        shutil.rmtree(tmp, ignore_errors=True)            # the working database never outlives the run


def _imp_summary(imports):
    out = []
    for k, v in imports.items():
        r = v["report"]
        out.append({"kind": k, "file": v["file"], "sha256": v["sha256"], "ready": v["ready"], "issues": v.get("issues", []),
                    "rows_read": r.get("rows_read"), "rows_rejected": r.get("rows_rejected"), "records": r.get("records"),
                    "rejected": r.get("rejected", []), "warnings": r.get("warnings", []), "mapping": r.get("mapping"),
                    "date_formats": r.get("date_formats"), "first_day": r.get("first_day"), "last_day": r.get("last_day"),
                    "granularity": r.get("granularity"), "ignored_columns": r.get("ignored_columns", []),
                    "assumption": r.get("assumption")})
    return out


def _analyse(store, p, imports, incumbent, horizon, level, say):
    w = memory.weekly_demand(store, p.org_id)
    lens = sorted(len(v) for v in w["series"].values())
    n_series = len(lens)
    stock = {k: memory.stockout_weeks(store, p.org_id, k[0], k[1]) for k in w["series"]} if "inventory" in imports and imports["inventory"]["ready"] else {}
    quality = {"series": n_series, "products": len({k[0] for k in w["series"]}), "locations": len({k[1] for k in w["series"]}),
               "first_week": min(w["start"].values()).isoformat(), "last_complete_week": w["last_week"].isoformat(),
               "weeks_median": lens[len(lens) // 2] if lens else 0, "weeks_min": lens[0] if lens else 0, "weeks_max": lens[-1] if lens else 0,
               "series_under_26_weeks": sum(1 for x in lens if x < 26), "series_under_56_weeks": sum(1 for x in lens if x < 56),
               "empty_weeks_share": (sum(w["gaps"].values()) / max(sum(lens), 1)),
               "weeks_where_returns_exceeded_sales": sum(w.get("negative_weeks", {}).values()),
               "series_with_stockouts": sum(1 for v in stock.values() if v), "stockout_weeks": sum(len(v) for v in stock.values())}
    # inventory readiness: which questions the data can answer
    pos = memory.purchase_orders(store, p.org_id)
    lts = memory.lead_times_days(pos)
    can = [
        {"question": "How accurate would demand estimates have been, against simple methods?", "answerable": True, "why": "sales history is present"},
        {"question": "Did stock-outs hide demand?", "answerable": bool(stock),
         "why": "stock snapshots present" if stock else "needs stock-on-hand snapshots (--inventory)"},
        {"question": "How long do suppliers really take, and is it changing?", "answerable": len(lts) >= 15,
         "why": "%d receipts with order and receipt dates" % len(lts) if lts else "needs purchase orders with order and receipt dates (--purchase-orders)"},
        {"question": "How much stock would meet a service target, and what does a late supplier do to it?",
         "answerable": bool(stock) and len(lts) >= 15,
         "why": "stock snapshots and lead times present" if (stock and len(lts) >= 15) else "needs both stock snapshots and purchase-order receipts"},
    ]
    # backtest
    mx = lens[-1] if lens else 0
    min_train = 52 if mx >= 52 + horizon + 26 else max(26, mx - horizon - 26)
    say("replaying history (min %d weeks of history before each estimate) ..." % min_train)
    bt = None
    try:
        bt = forecasting.run_backtest(store, p, horizon=horizon, step=max(1, horizon), min_train=min_train, level=level, keep_rows=True)
    except InsufficientData as e:
        quality["backtest_blocked"] = str(e)
    result = {"quality": quality, "questions": can, "imports": _imp_summary(imports), "engine_version": __version__,
              "run_at": datetime.now(timezone.utc).isoformat(timespec="seconds"), "horizon_weeks": horizon, "level": level}
    if bt:
        act = next(k for k in bt["models"] if k.startswith("active:"))
        A = bt["models"][act]
        result["backtest"] = {
            "params": bt["params"], "dataset_fingerprint": bt["dataset_fingerprint"], "origins": bt["origins"],
            "leaderboard_test": forecasting.leaderboard(bt, "test"), "leaderboard_all": forecasting.leaderboard(bt, "all"),
            "by_horizon_week": {h: {"udgass": A["all"]["by_horizon_week"][h]["wape"], "moving_avg_4": bt["models"]["moving_avg_4"]["all"]["by_horizon_week"][h]["wape"]}
                                for h in A["all"]["by_horizon_week"]},
            "by_demand_class": {c: {"udgass": v, "moving_avg_4": bt["models"]["moving_avg_4"]["by_segment"]["demand_class"].get(c)}
                                for c, v in A["by_segment"]["demand_class"].items()},
            "by_category": A["by_segment"]["category"],
            "by_series": bt["by_series_active"], "excluded_series": bt["excluded_series"], "methods_chosen": A.get("methods_chosen"),
            "notes": bt["notes"]}
        if incumbent:
            result["incumbent"] = _incumbent(incumbent, bt["rows_active"])
    res = patterns.run(store, p)
    result["findings"] = {"counts": res["counts"], "top": [{k: f[k] for k in ("kind", "sku", "location", "period_start", "period_end", "observation", "method", "limitations")}
                                                         for f in patterns.list_findings(store, p, res["run_id"], limit=15)["items"] if f["kind"] != "demand_profiles"]}
    result["verdict"] = _verdict(result, level)
    return result


def _incumbent(path, rows):
    import csv
    from datetime import date as _d
    with open(path, newline="", encoding="utf-8-sig") as f:
        head = f.readline()
    delim = max(",;\t|", key=head.count) if any(c in head for c in ",;\t|") else ","
    inc, bad = {}, 0
    with open(path, newline="", encoding="utf-8-sig") as f:
        rd = csv.DictReader(f, delimiter=delim)
        cols = {ingest.norm(c): c for c in (rd.fieldnames or [])}
        need = [c for c in ("sku", "as_of", "forecast") if c not in cols]
        if need:
            return {"error": "incumbent file needs columns sku, as_of, forecast (and optionally location); missing %s" % ", ".join(need)}
        for r in rd:
            try:
                d = None
                for fmt in ingest.DATE_FORMATS:
                    d, err = ingest.parse_day(r[cols["as_of"]], fmt)
                    if not err:
                        break
                if d is None:
                    raise ValueError
                v, err = ingest.parse_number(r[cols["forecast"]])
                if err:
                    raise ValueError
                key = (r[cols["sku"]].strip(), (r[cols["location"]].strip() if "location" in cols else None), memory.monday(d).isoformat())
                inc[key] = inc.get(key, 0.0) + v
            except (ValueError, KeyError, AttributeError):
                bad += 1
    has_loc = any(k[1] for k in inc)
    agg = {}
    for r in rows:
        k = (r["sku"], r["location"] if has_loc else None, r["origin"])
        a = agg.setdefault(k, {"point": 0.0, "actual": 0.0, "baseline": 0.0})
        a["point"] += r["point"]; a["actual"] += r["actual"]; a["baseline"] += r["baseline"] or 0.0
    m = [(agg[k], inc[k]) for k in inc if k in agg]
    if not m:
        return {"error": "no forecast windows matched. as_of must be the first day (or week) of each forecast window, sku codes must match "
                         "the sales file, and the forecast must be the total for the same horizon.", "unreadable_rows": bad}
    A = sum(x["actual"] for x, _ in m)
    w = lambda f: sum(abs(x["actual"] - f(x, i)) for x, i in m) / A if A > 0 else None
    return {"matched_windows": len(m), "unreadable_rows": bad, "wape_incumbent": w(lambda x, i: i), "wape_udgass": w(lambda x, i: x["point"]),
            "wape_moving_avg_4": w(lambda x, i: x["baseline"]),
            "bias_incumbent": (sum(i for _, i in m) - A) / A if A > 0 else None, "bias_udgass": (sum(x["point"] for x, _ in m) - A) / A if A > 0 else None,
            "udgass_closer": sum(abs(x["actual"] - x["point"]) < abs(x["actual"] - i) for x, i in m),
            "incumbent_closer": sum(abs(x["actual"] - x["point"]) > abs(x["actual"] - i) for x, i in m),
            "caution": "Your forecasts must be the ones actually made at the time (saved snapshots), for the same horizon. Re-created forecasts are not comparable."}


def _verdict(r, level):
    """Advisory reading of the evidence. Rules are fixed in advance and printed in the report."""
    bt = r.get("backtest")
    if not bt:
        return {"level": "not_assessable", "headline": "There is not enough history to replay. No view on forecasting value is possible yet.",
                "reasons": [r["quality"].get("backtest_blocked", "")]}
    test = {x["model"]: x for x in bt["leaderboard_test"]}
    act = next(k for k in test if k.startswith("active:"))
    u, b = test[act], test.get("moving_avg_4")
    n, cov = u["windows"], u["coverage"]
    reasons = []
    inc = r.get("incumbent") or {}
    if inc.get("matched_windows", 0) >= 30:
        comp, cname, cw = "your current forecast", "incumbent", inc["wape_incumbent"]
        uw = inc["wape_udgass"]
    else:
        comp, cname, cw, uw = "a simple four-week average", "moving_avg_4", b["wape"], u["wape"]
    imp = (1 - uw / cw) if cw else None
    where = ("on %d windows where your forecasts could be matched" % inc["matched_windows"]) if cname == "incumbent" else "on the later part of the history"
    reasons.append("Compared with %s %s: error %.1f%% vs %.1f%% (%s)." % (
        comp, where, uw * 100, cw * 100, ("%.0f%% lower" % (imp * 100)) if imp and imp > 0 else "not lower"))
    reasons.append("Actuals inside the stated %d%% range: %.0f%% of %d windows." % (round(level * 100), cov * 100, n))
    n = inc["matched_windows"] if cname == "incumbent" else n
    if n < 30:
        lvl, head = "insufficient", "Too few test windows (%d) to judge. Treat any difference as noise." % n
    elif imp is not None and imp >= 0.05 and abs(cov - level) <= 0.1:
        lvl, head = "supports_pilot", "The evidence supports a pilot: estimates were clearly more accurate than %s, with honest ranges." % comp
    elif imp is not None and imp > 0:
        lvl, head = "marginal", "A small improvement over %s. A pilot is worth it only if better ranges, stock-out detection or decision records matter to you." % comp
    else:
        lvl, head = "no_improvement", "No improvement over %s on this data. A pilot is not justified on forecasting accuracy alone." % comp
    if abs(cov - level) > 0.1:
        reasons.append("The ranges were %s than intended, so they should not be relied on as stated." % ("narrower" if cov < level else "wider"))
    q = r["quality"]
    if q.get("series_with_stockouts"):
        reasons.append("%d series had zero-stock weeks: recorded sales understate demand there, for every method." % q["series_with_stockouts"])
    if q["series_under_56_weeks"]:
        reasons.append("%d series have less than 56 weeks of history, so seasonality could not be used for them." % q["series_under_56_weeks"])
    return {"level": lvl, "headline": head, "reasons": reasons, "compared_with": cname,
            "rules": "Supports a pilot: at least 30 test windows, error at least 5% lower than the comparison, and range coverage within 10 points of target. "
                     "Marginal: lower error but less than 5%. No improvement: equal or higher error. Fixed before the data was seen.",
            "advisory": "This is an advisory reading of the evidence. Whether to run a pilot, and any business decision, rests with your company."}


# ---------------------------------------------------------------- report

def _anon(summary):
    """Replace product and location codes with neutral labels, consistently, everywhere in the summary."""
    skus, locs = {}, {}
    def S(x):
        if x is None:
            return x
        return skus.setdefault(x, "P%03d" % (len(skus) + 1))
    def L(x):
        if x in (None, "ALL"):
            return x
        return locs.setdefault(x, "L%02d" % (len(locs) + 1))
    bt = summary.get("backtest")
    if bt:
        for r in bt["by_series"]:
            r["sku"], r["location"] = S(r["sku"]), L(r["location"])
        for r in bt["excluded_series"]:
            r["sku"], r["location"] = S(r["sku"]), L(r["location"])
        bt["by_category"] = {"category %d" % (i + 1): v for i, (k, v) in enumerate(sorted(bt["by_category"].items()))}
    for f in summary.get("findings", {}).get("top", []):
        old_s, old_l = f["sku"], f["location"]
        f["sku"], f["location"] = S(f["sku"]), L(f["location"])
        if old_s:
            f["observation"] = f["observation"].replace(old_s, f["sku"])
    for i in summary.get("imports", []):
        i["file"] = "%s file" % i["kind"]
        i["mapping"] = {k: "(column)" for k in (i.get("mapping") or {})}
        for rj in i.get("rejected", []):
            for ex in rj["examples"]:
                ex.pop("value", None)
        i["ignored_columns"] = [{"column": "(column)", "looks_personal": c["looks_personal"]} for c in i.get("ignored_columns", [])]
    summary["anonymised"] = True
    return summary


def _public(summary):
    """Relative metrics only: no product codes, no volumes, no company name."""
    bt = summary.get("backtest")
    if not bt:
        return None
    t = {x["model"]: x for x in bt["leaderboard_test"]}
    act = next(k for k in t if k.startswith("active:"))
    q = summary["quality"]
    lines = ["Data: about %d product-location series, median %d weeks of history." % (round(q["series"], -1) if q["series"] >= 20 else q["series"], q["weeks_median"]),
             "Replayed %d forecast windows; each estimate used only data available at the time." % t[act]["windows"],
             "Forecast error (WAPE, later part of history): Udgass %.1f%%, four-week average %.1f%%, same week last year %s." % (
                 t[act]["wape"] * 100, t["moving_avg_4"]["wape"] * 100, ("%.1f%%" % (t["seasonal_naive"]["wape"] * 100)) if "seasonal_naive" in t else "n/a"),
             "Actuals inside the stated 80%% range: %.0f%%." % (t[act]["coverage"] * 100)]
    inc = summary.get("incumbent") or {}
    if inc.get("matched_windows"):
        lines.append("Against the company's own forecasts on %d matched windows: Udgass %.1f%% vs %.1f%%." % (inc["matched_windows"], inc["wape_udgass"] * 100, inc["wape_incumbent"] * 100))
    lines.append("Reading: " + summary["verdict"]["headline"])
    return lines


def _write(out_html, out_json, summary, company, anonymise, banner=None):
    if anonymise:
        summary = _anon(json.loads(json.dumps(summary)))
        company = ""
    summary["publishable_summary"] = _public(summary) if summary.get("status") == "complete" else None
    if out_json:
        with open(out_json, "w", encoding="utf-8") as f:
            json.dump(summary, f, indent=2, default=str)
    if banner:
        summary["banner"] = banner
    with open(out_html, "w", encoding="utf-8") as f:
        f.write(render(summary, company))


def _pct(x, d=1):
    return "n/a" if x is None else "%.*f%%" % (d, x * 100)


def _sgn(x):
    return "n/a" if x is None else "%+.1f%%" % (x * 100)


def render(s, company=""):
    e = html.escape
    out = []
    A = out.append
    title = "Demand assessment" + (" · " + company if company else "")
    A("<!doctype html><html lang='en'><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'>")
    A("<title>%s</title><style>%s</style></head><body><main>" % (e(title), CSS))
    if s.get("banner"):
        A("<p class='banner'>%s</p>" % e(s["banner"]))
    if not s.get("banner"):
        A("<p class='conf'>%s</p>" % ("Anonymised copy. Product and location codes replaced." if s.get("anonymised") else
                                      "Confidential: contains the company's product codes and figures. Produced on the company's own machine."))
    A("<h1>%s</h1>" % e(title))
    A("<p class='sub'>Udgass %s · %s · Each estimate below used only data available at its date.</p>" % (e(s.get("engine_version", "")), e(s.get("run_at", "")[:16].replace("T", " ") + " UTC")))
    if s.get("status") == "data_not_ready":
        A("<section class='verdict amber'><h2>The sales file is not ready yet</h2><p>Nothing was analysed. Fix the points below and run the assessment again.</p><ul>")
        for i in s["issues"]:
            A("<li>%s</li>" % e(i))
        A("</ul></section>")
        _imports(A, e, s)
        A(FOOT + "</main></body></html>")
        return _wrap("".join(out))
    v = s["verdict"]
    cls = {"supports_pilot": "ok", "marginal": "amber", "no_improvement": "red", "insufficient": "amber", "not_assessable": "amber"}[v["level"]]
    A("<section class='verdict %s'><p class='k'>Reading of the evidence (advisory)</p><h2>%s</h2><ul>" % (cls, e(v["headline"])))
    for r in v.get("reasons", []):
        A("<li>%s</li>" % e(r))
    A("</ul><p class='small'>%s</p><p class='small'>%s</p></section>" % (e(v.get("rules", "")), e(v.get("advisory", ""))))
    q = s["quality"]
    A("<h2>1. Your data</h2><div class='kpis'>")
    for val, lab in [(q["products"], "products"), (q["locations"], "locations"), (q["series"], "product-location series"),
                     ("%d" % q["weeks_median"], "median weeks of history"), (_pct(q["empty_weeks_share"]), "weeks with no sales rows"),
                     (q["series_with_stockouts"] if s["questions"][1]["answerable"] else "unknown", "series with zero-stock weeks")]:
        A("<div><b>%s</b><span>%s</span></div>" % (e(str(val)), e(lab)))
    A("</div><p class='small'>Complete weeks from %s to the week starting %s. Weeks with no sales rows are treated as zero demand. %s</p>" % (
        e(q["first_week"]), e(q["last_complete_week"]),
        e("%d weeks had returns larger than sales and were set to zero." % q["weeks_where_returns_exceeded_sales"]) if q["weeks_where_returns_exceeded_sales"] else ""))
    _imports(A, e, s)
    A("<h2>2. What this data can answer</h2><table><tr><th>Question</th><th>Answerable</th><th>Why</th></tr>")
    for c in s["questions"]:
        A("<tr><td>%s</td><td>%s</td><td>%s</td></tr>" % (e(c["question"]), "<span class='t ok'>yes</span>" if c["answerable"] else "<span class='t red'>not yet</span>", e(c["why"])))
    A("</table>")
    bt = s.get("backtest")
    if bt:
        A("<h2>3. How accurate would estimates have been?</h2>")
        A("<p>History was replayed at %d dates. At each date, a %d-week total was estimated from earlier weeks only, then compared with what happened. "
          "The first 60%% of dates form the earlier part; the remaining dates form the later part, reported first because it was not used to tune anything. "
          "A window is one product at one location at one date, so a table can count more windows than there are dates.</p>" % (bt["origins"], s["horizon_weeks"]))
        lb = bt["leaderboard_test"]
        mx = max(x["wape"] for x in lb if x["wape"] is not None) or 1
        A("<table><tr><th>Method (later part only)</th><th class='n'>Error (WAPE)</th><th><span class='sr'>Error bar</span></th><th class='n'>Bias</th><th class='n'>Inside range</th><th class='n'>Windows</th></tr>")
        for x in lb:
            name = "Udgass" if x["model"].startswith("active:") else {"moving_avg_4": "Average of last 4 weeks", "seasonal_naive": "Same week last year", "naive_last": "Last week's value"}.get(x["model"], x["model"])
            A("<tr%s><td>%s</td><td class='n'>%s</td><td><span class='bar' style='width:%dpx'></span></td><td class='n'>%s</td><td class='n'>%s</td><td class='n'>%d</td></tr>" % (
                " class='hl'" if name == "Udgass" else "", e(name), _pct(x["wape"]), int(160 * (x["wape"] or 0) / mx), _sgn(x["bias"]),
                _pct(x["coverage"], 0) if x["coverage"] is not None else "no range", x["windows"]))
        A("</table><p class='small'>WAPE: total absolute error divided by total actual demand. Bias above zero means estimates were too high. "
          "The range is a prediction interval built from each method's own past errors; 'inside range' checks whether it was honest.</p>")
        A("<h3>By weeks ahead</h3><p class='small'>Error for each single week, all dates together.</p><table><tr><th>Week ahead</th><th class='n'>Udgass</th><th class='n'>Average of last 4 weeks</th></tr>")
        for h, v2 in bt["by_horizon_week"].items():
            A("<tr><td>%s</td><td class='n'>%s</td><td class='n'>%s</td></tr>" % (e(h), _pct(v2["udgass"]["wape"] if isinstance(v2["udgass"], dict) else v2["udgass"]),
                                                                              _pct(v2["moving_avg_4"]["wape"] if isinstance(v2["moving_avg_4"], dict) else v2["moving_avg_4"])))
        A("</table><h3>By demand pattern</h3><p class='small'>All dates, earlier and later parts together, so window counts are higher than in the table above.</p><table><tr><th>Pattern</th><th class='n'>Windows</th><th class='n'>Udgass</th><th class='n'>Average of last 4 weeks</th></tr>")
        for c, v2 in bt["by_demand_class"].items():
            A("<tr><td>%s</td><td class='n'>%d</td><td class='n'>%s</td><td class='n'>%s</td></tr>" % (e(c.replace("_", " ")), v2["udgass"]["n"], _pct(v2["udgass"]["wape"]),
                                                                                                  _pct((v2["moving_avg_4"] or {}).get("wape"))))
        A("</table><p class='small'>Smooth: steady weekly demand. Erratic: steady but variable. Intermittent and lumpy: many weeks without demand, "
          "where every method struggles and percentages are large.</p>")
        inc = s.get("incumbent")
        if inc:
            A("<h2>4. Against your current forecasts</h2>")
            if inc.get("error"):
                A("<p class='warn'>%s</p>" % e(inc["error"]))
            else:
                A("<table><tr><th>On %d matched windows</th><th class='n'>Error (WAPE)</th><th class='n'>Bias</th></tr>" % inc["matched_windows"])
                A("<tr><td>Your forecasts</td><td class='n'>%s</td><td class='n'>%s</td></tr>" % (_pct(inc["wape_incumbent"]), _sgn(inc["bias_incumbent"])))
                A("<tr class='hl'><td>Udgass</td><td class='n'>%s</td><td class='n'>%s</td></tr>" % (_pct(inc["wape_udgass"]), _sgn(inc["bias_udgass"])))
                A("<tr><td>Average of last 4 weeks</td><td class='n'>%s</td><td class='n'></td></tr></table>" % _pct(inc["wape_moving_avg_4"]))
                A("<p class='small'>Closer to the actual: Udgass in %d windows, yours in %d. %s</p>" % (inc["udgass_closer"], inc["incumbent_closer"], e(inc["caution"])))
        n = 5 if inc else 4
        rows = sorted(bt["by_series"], key=lambda r: -(r["wape"] or 0))
        A("<h2>%d. Where estimates fail</h2><p>Every series, hardest first. Shown on purpose: these are the products where any forecast needs a person's judgement.</p>" % n)
        A("<table><tr><th>Product</th><th>Location</th><th>Pattern</th><th class='n'>Windows</th><th class='n'>Udgass</th><th class='n'>4-week average</th><th class='n'>Bias</th><th class='n'>Inside range</th></tr>")
        for r in rows[:60]:
            A("<tr><td>%s</td><td>%s</td><td>%s</td><td class='n'>%d</td><td class='n'>%s</td><td class='n'>%s</td><td class='n'>%s</td><td class='n'>%s</td></tr>" % (
                e(r["sku"]), e(r["location"]), e(r["demand_class"].replace("_", " ")), r["windows"], _pct(r["wape"]), _pct(r["baseline_wape"]), _sgn(r["bias"]), _pct(r["coverage"], 0)))
        A("</table>%s" % ("<p class='small'>%d more series not shown (see the JSON output).</p>" % (len(rows) - 60) if len(rows) > 60 else ""))
        if bt["excluded_series"]:
            A("<p class='small'>%d series had too little history to replay and are not scored.</p>" % len(bt["excluded_series"]))
        n += 1
    else:
        n = 3
        A("<h2>3. Accuracy</h2><p class='warn'>%s</p>" % e(s["quality"].get("backtest_blocked", "Not enough history to replay.")))
    f = s.get("findings") or {}
    if f.get("top"):
        A("<h2>%d. Patterns worth a look</h2><p class='small'>Observations for review, not conclusions. None of them states a cause.</p><table><tr><th>Kind</th><th>Where</th><th>Observation</th><th>Period</th></tr>" % n)
        for x in f["top"]:
            A("<tr><td>%s</td><td>%s</td><td>%s</td><td>%s</td></tr>" % (e(x["kind"].replace("_", " ")), e(" · ".join(v for v in (x["sku"], x["location"]) if v) or "all"), e(x["observation"]), e((x["period_start"] or "") + (" to " + x["period_end"] if x["period_end"] and x["period_end"] != x["period_start"] else ""))))
        A("</table>")
        n += 1
    A("<h2>%d. Method and limits</h2><ul>" % n)
    for t in ["Estimates come from six standard methods; for each product the one with the lowest error on that product's own earlier history is used, with a preference for an equal-weight combination.",
              "Each estimate used only weeks before its date (rolling origins). No future data enters any estimate.",
              "Prices, promotions, calendar effects and stock-outs are not modelled as inputs.",
              "Weeks with zero stock make recorded sales lower than real demand, for every method alike.",
              "Past accuracy does not guarantee future accuracy."]:
        A("<li>%s</li>" % e(t))
    A("</ul>")
    pub = s.get("publishable_summary")
    if pub:
        A("<section class='pub'><p class='k'>Optional: draft summary, only if you choose to allow publication</p><p class='small'>Relative figures only: no company name, product codes or volumes. "
          "Permission to publish is separate from the assessment and entirely optional; the free assessment does not depend on it. "
          "Udgass will not publish this, or any part of this report, unless your company gives separate written approval of the exact wording.</p><ul>")
        for l in pub:
            A("<li>%s</li>" % e(l))
        A("</ul></section>")
    A("<h2>Reproducibility</h2><table>")
    for i in s.get("imports", []):
        A("<tr><td>%s</td><td class='mono'>%s</td></tr>" % (e(i["file"]), e(i["sha256"])))
    if bt:
        A("<tr><td>Dataset fingerprint</td><td class='mono'>%s</td></tr><tr><td>Settings</td><td class='mono'>%s</td></tr>" % (e(bt["dataset_fingerprint"]), e(json.dumps(bt["params"]))))
    A("</table>" + FOOT + "</main></body></html>")
    return _wrap("".join(out))


def _imports(A, e, s):
    A("<h3>Files checked</h3><table><tr><th>File</th><th class='n'>Rows</th><th class='n'>Rejected</th><th>Dates</th><th>Columns used</th></tr>")
    for i in s.get("imports", []):
        A("<tr><td>%s<br><span class='small'>%s</span></td><td class='n'>%s</td><td class='n'>%s</td><td>%s</td><td class='small'>%s</td></tr>" % (
            e(i["file"]), e(i["kind"].replace("_", " ") + ("" if i["ready"] else " · not used")), e(str(i.get("rows_read") or "")), e(str(i.get("rows_rejected") or 0)),
            e("%s to %s (%s)" % (i.get("first_day") or "?", i.get("last_day") or "?", i.get("granularity") or "?")) if i.get("first_day") else "",
            e(", ".join("%s = %s" % kv for kv in (i.get("mapping") or {}).items()))))
    A("</table>")
    for i in s.get("imports", []):
        if i.get("issues"):
            A("<p class='warn'>%s: %s</p>" % (e(i["file"]), e("; ".join(i["issues"]))))
        if i.get("rejected"):
            A("<p class='small'>%s, rejected rows: %s</p>" % (e(i["file"]), e("; ".join("%s (%d)" % (r["reason"], r["rows"]) for r in i["rejected"]))))
        if any(c["looks_personal"] for c in i.get("ignored_columns", [])):
            A("<p class='small'>%s: some columns look personal. They were ignored and not stored.</p>" % e(i["file"]))
        if i.get("assumption"):
            A("<p class='small'>%s</p>" % e(i["assumption"]))


def _wrap(doc):
    """Make wide tables scroll inside their own focusable, labelled region on narrow screens."""
    import itertools
    n = itertools.count(1)
    doc = re.sub("<table>", lambda m: "<div class='tw' tabindex='0' role='region' aria-label='Table %d'><table>" % next(n), doc)
    return doc.replace("</table>", "</table></div>")


FOOT = ("<footer><p>Produced by Udgass, a product of KPAppWorx Technologies Private Limited. Early-stage software, not certified to any standard. "
        "This report is advisory; every business decision rests with the company. The analysis ran on the company's own machine and its working "
        "data was deleted when the run finished.</p></footer>")

CSS = """
:root{--ink:#0F1A22;--mu:#56636F;--ln:#D9DEE2;--ac:#0A6354;--acl:#E3F3EF;--am:#9A6A12;--aml:#FBF1DD;--rk:#A4442B;--rkl:#FBE6E0}
*{box-sizing:border-box}body{margin:0;background:#fff;color:var(--ink);font:15px/1.55 system-ui,-apple-system,"Segoe UI",Roboto,sans-serif}
main{max-width:980px;margin:0 auto;padding:40px 28px 60px}h1{font:400 2.2rem/1.1 Georgia,serif;margin:6px 0}h2{font:400 1.45rem Georgia,serif;margin:34px 0 10px;border-top:1px solid var(--ln);padding-top:22px}
h3{font-size:1rem;margin:20px 0 8px}.sub,.small{color:var(--mu)}.small{font-size:.85rem}.conf{font:600 .72rem ui-monospace,Menlo,monospace;letter-spacing:.08em;text-transform:uppercase;color:var(--am)}
table{border-collapse:collapse;width:100%;font-size:.88rem;margin:8px 0}th,td{text-align:left;padding:6px 8px;border-bottom:1px solid var(--ln);vertical-align:top}th{color:var(--mu);font-weight:500}
.sr{position:absolute;width:1px;height:1px;overflow:hidden;clip:rect(0 0 0 0)}.tw{overflow-x:auto;position:relative}
.n{text-align:right;font-variant-numeric:tabular-nums}tr.hl td{background:var(--acl);font-weight:600}.bar{display:inline-block;height:9px;background:var(--ac);border-radius:2px;vertical-align:middle}
.verdict{border-radius:6px;padding:16px 20px;margin:20px 0}.verdict h2{border:0;padding:0;margin:4px 0 8px}.verdict.ok{background:var(--acl)}.verdict.amber{background:var(--aml)}.verdict.red{background:var(--rkl)}
.k{font:600 .72rem ui-monospace,Menlo,monospace;letter-spacing:.08em;text-transform:uppercase;color:var(--mu);margin:0}
.kpis{display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:10px}.kpis div{border:1px solid var(--ln);border-radius:6px;padding:10px 12px}.kpis b{display:block;font:400 1.5rem Georgia,serif;color:var(--ac)}.kpis span{color:var(--mu);font-size:.82rem}
.t{font:600 .72rem ui-monospace,Menlo,monospace;text-transform:uppercase;padding:2px 6px;border-radius:3px}.t.ok{background:var(--acl);color:var(--ac)}.t.red{background:var(--rkl);color:var(--rk)}
.warn{background:var(--aml);padding:8px 12px;border-radius:4px}.banner{background:#3a2d12;color:#F6DDA8;font:700 .8rem ui-monospace,Menlo,monospace;letter-spacing:.06em;text-transform:uppercase;padding:10px 14px;border-radius:4px;-webkit-print-color-adjust:exact;print-color-adjust:exact}
.pub{border:1px dashed var(--ac);border-radius:6px;padding:14px 18px;margin:24px 0}.mono{font-family:ui-monospace,Menlo,monospace;font-size:.78rem;word-break:break-all}
footer{margin-top:40px;color:var(--mu);font-size:.8rem;border-top:1px solid var(--ln);padding-top:14px}
@media print{main{padding:0}h2{break-after:avoid}tr{break-inside:avoid}.verdict,.pub{-webkit-print-color-adjust:exact;print-color-adjust:exact}}
"""
