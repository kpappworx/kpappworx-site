"""Versioned forecasts, time-aware backtests and an evidence-gated model policy.

- A forecast run is immutable. It records the knowledge time, the data cutoff, a fingerprint of every demand record
  it could see, the policy and engine version. Re-running later never overwrites it; it creates a new run.
- Backtests replay rolling origins: each estimate uses only weeks before its origin. Every model is compared with
  three baselines on the same windows: last week (naive), mean of the last four weeks, and the same week last year.
- A policy (the set of methods the selector may choose from) changes only through promote(), which requires a stored
  backtest on current data in which the candidate beats the active policy on both the earlier (validation) and the
  later (test) half of the windows. Rollback re-activates the previous policy. Nothing is promoted automatically.
"""
from __future__ import annotations
import json, math
from datetime import date, timedelta
from .. import __version__
from ..forecast import METHODS, forecast_total, naive_weekly, quantile
from .db import dumps, new_id, ts
from .errors import Conflict, InsufficientData, Invalid, NotFound
from .tenancy import require
from .patterns_util import demand_class
from . import audit, memory

MIN_HISTORY = 13
BASELINES = ("naive_last", "moving_avg_4", "seasonal_naive")


# ---------- policies ----------

def ensure_default_policy(c, org, actor, now=None):
    if c.execute("SELECT 1 FROM policies WHERE org_id=?", (org,)).fetchone():
        return
    pid = new_id("pol")
    c.execute("INSERT INTO policies VALUES(?,?,?,?,?,?)", (pid, org, "auto-all-methods", dumps(sorted(METHODS)), ts(now), actor))
    c.execute("INSERT INTO policy_log(org_id,policy_id,action,at,actor,evidence_json) VALUES(?,?,?,?,?,?)",
              (org, pid, "activate", ts(now), actor, dumps({"reason": "default policy at organisation creation"})))


def active_policy(store, org):
    c = store.conn()
    r = c.execute("SELECT policy_id FROM policy_log WHERE org_id=? AND action IN ('activate','promote','rollback') ORDER BY id DESC LIMIT 1", (org,)).fetchone()
    if not r:
        raise NotFound("no active policy")
    return _policy(c, org, r[0])


def _policy(c, org, pid):
    r = c.execute("SELECT * FROM policies WHERE id=? AND org_id=?", (pid, org)).fetchone()
    if not r:
        raise NotFound("no policy %s in this organisation" % pid)
    return {"id": r["id"], "name": r["name"], "methods": json.loads(r["methods_json"]), "created_at": r["created_at"]}


def create_policy(store, p, name, methods, request_id=None):
    require(p, "analyst")
    methods = sorted(set(methods or []))
    if not methods or any(m not in METHODS for m in methods):
        raise Invalid("methods must be a non-empty subset of %s" % ", ".join(sorted(METHODS)))
    pid = new_id("pol")
    with store.tx() as c:
        c.execute("INSERT INTO policies VALUES(?,?,?,?,?,?)", (pid, p.org_id, (name or "candidate")[:80], dumps(methods), ts(), p.actor))
        c.execute("INSERT INTO policy_log(org_id,policy_id,action,at,actor,evidence_json) VALUES(?,?,?,?,?,?)",
                  (p.org_id, pid, "candidate", ts(), p.actor, "{}"))
        audit.record(c, p.org_id, p.actor, "policy.create", "policy", pid, request_id, {"methods": methods})
    return _policy(store.conn(), p.org_id, pid)


def list_policies(store, p):
    c = store.conn()
    act = active_policy(store, p.org_id)["id"]
    out = []
    for r in c.execute("SELECT id FROM policies WHERE org_id=? ORDER BY created_at", (p.org_id,)):
        d = _policy(c, p.org_id, r[0]); d["active"] = d["id"] == act; out.append(d)
    log = [dict(r) for r in c.execute("SELECT policy_id, action, at, actor, evidence_json FROM policy_log WHERE org_id=? ORDER BY id", (p.org_id,))]
    for l in log:
        l["evidence"] = json.loads(l.pop("evidence_json") or "{}")
    return {"policies": out, "log": log}


# ---------- baselines ----------

def baseline_weekly(name, hist, h):
    if not hist:
        return None
    if name == "naive_last":
        return [hist[-1]] * h
    if name == "moving_avg_4":
        return naive_weekly(hist, h)
    if name == "seasonal_naive":
        if len(hist) < 52:
            return None
        return [hist[len(hist) - 52 + (i % 52)] for i in range(h)]
    raise ValueError(name)


# ---------- forecast runs ----------

def create_run(store, p, horizon=4, level=0.8, knowledge_time=None, through=None, skus=None, by_location=True,
               min_history=MIN_HISTORY, note="", request_id=None, now=None):
    require(p, "analyst")
    if not 1 <= int(horizon) <= 26:
        raise Invalid("horizon must be 1 to 26 weeks")
    if not 0.5 <= float(level) < 1:
        raise Invalid("level must be between 0.5 and 0.99")
    horizon, level = int(horizon), float(level)
    kt = memory.kt_str(knowledge_time or now)
    pol = active_policy(store, p.org_id)
    w = memory.weekly_demand(store, p.org_id, kt, through, skus, None, by_location)
    fp, nrec = memory.fingerprint(store, p.org_id, kt, w["last_week"] + timedelta(days=6), skus)
    origin = w["last_week"] + timedelta(weeks=1)
    rid = new_id("run")
    made, skipped = [], []
    for key in sorted(w["series"]):
        y = w["series"][key]
        if len(y) < min_history:
            skipped.append({"sku": key[0], "location": key[1], "reason": "only %d complete weeks of history; at least %d needed" % (len(y), min_history)})
            continue
        est = forecast_total(y, horizon, level, pol["methods"])
        notes = []
        if est["evidence_quality"] == "thin":
            notes.append("Thin evidence: fewer than 8 past errors, so a wide default range (plus or minus 50%) is used.")
        if len(y) < 56:
            notes.append("Less than 56 weeks of history: last year's seasonal shape could not be used.")
        if w["gaps"][key]:
            notes.append("%d weeks had no sales rows and were treated as zero." % w["gaps"][key])
        so = [d for d in memory.stockout_weeks(store, p.org_id, key[0], key[1] if by_location else None, kt) if d <= w["last_week"]]
        if so:
            notes.append("%d past weeks had a zero stock snapshot: sales then may understate demand, which biases this estimate low." % len(so))
        made.append({"id": new_id("fc"), "sku": key[0], "location": key[1], "est": est, "hist": len(y), "notes": notes,
                     "candidates": est["candidates"]})
    summary = {"forecasts": len(made), "skipped": skipped, "records_seen": nrec, "series": len(w["series"])}
    with store.tx() as c:
        c.execute("INSERT INTO forecast_runs VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)",
                  (rid, p.org_id, ts(now), p.actor, __version__, pol["id"], kt, w["cutoff_day"].isoformat(), fp, horizon, level,
                   dumps({"by_location": by_location, "skus": skus, "through": str(through) if through else None, "min_history": min_history,
                          "policy_methods": pol["methods"], "note": note[:300], "last_complete_week": w["last_week"].isoformat()}),
                   dumps(summary)))
        for m in made:
            e = m["est"]
            c.execute("INSERT INTO forecasts VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                      (m["id"], rid, p.org_id, m["sku"], m["location"], origin.isoformat(), origin.isoformat(),
                       (origin + timedelta(days=7 * horizon - 1)).isoformat(), horizon, e["point"], e["low"], e["high"], level,
                       e["method"], e["evidence_n"], e["evidence_quality"], dumps(e["weekly"]), m["hist"],
                       dumps({"notes": m["notes"], "candidates": m["candidates"]})))
        audit.record(c, p.org_id, p.actor, "forecast.run", "forecast_run", rid, request_id, {"forecasts": len(made), "skipped": len(skipped)})
    return get_run(store, p, rid)


def get_run(store, p, run_id):
    r = store.conn().execute("SELECT * FROM forecast_runs WHERE id=? AND org_id=?", (run_id, p.org_id)).fetchone()
    if not r:
        raise NotFound("no forecast run %s in this organisation" % run_id)
    d = dict(r)
    d["params"] = json.loads(d.pop("params_json")); d["summary"] = json.loads(d.pop("summary_json")); d.pop("org_id")
    return d


def list_runs(store, p, limit=50, cursor=None):
    limit = max(1, min(int(limit), 200))
    q, a = "SELECT id FROM forecast_runs WHERE org_id=?", [p.org_id]
    if cursor:
        q += " AND created_at < ?"; a.append(cursor)
    ids = [r[0] for r in store.conn().execute(q + " ORDER BY created_at DESC LIMIT ?", a + [limit])]
    items = [get_run(store, p, i) for i in ids]
    return {"items": items, "next_cursor": items[-1]["created_at"] if len(items) == limit else None}


def _fc_row(r):
    d = dict(r)
    d["weekly"] = json.loads(d.pop("weekly_json")); n = json.loads(d.pop("notes_json"))
    d["notes"] = n["notes"]; d["candidates"] = n["candidates"]; d.pop("org_id")
    return d


def list_forecasts(store, p, run_id, sku=None, limit=100, cursor=None):
    get_run(store, p, run_id)
    limit = max(1, min(int(limit), 500))
    q, a = "SELECT * FROM forecasts WHERE run_id=? AND org_id=?", [run_id, p.org_id]
    if sku:
        q += " AND sku=?"; a.append(sku)
    if cursor:
        parts = cursor.split("\x1f")
        if len(parts) != 3:
            raise Invalid("bad cursor")
        q += " AND (sku, location, id) > (?, ?, ?)"; a += parts
    items = [_fc_row(r) for r in store.conn().execute(q + " ORDER BY sku, location, id LIMIT ?", a + [limit])]
    last = items[-1] if items else None
    return {"items": items, "next_cursor": "\x1f".join([last["sku"], last["location"], last["id"]]) if len(items) == limit else None}


def get_forecast(store, p, forecast_id):
    r = store.conn().execute("SELECT * FROM forecasts WHERE id=? AND org_id=?", (forecast_id, p.org_id)).fetchone()
    if not r:
        raise NotFound("no forecast %s in this organisation" % forecast_id)
    return _fc_row(r)


def explain(store, p, forecast_id):
    """Provenance of one forecast: what data it could see, which method and why, its range, its limits and how it did."""
    f = get_forecast(store, p, forecast_id)
    run = get_run(store, p, f["run_id"])
    evals = [dict(r) for r in store.conn().execute(
        "SELECT evaluated_at, knowledge_time, actual, error, inside, baseline, notes_json FROM forecast_evaluations WHERE org_id=? AND forecast_id=? ORDER BY id",
        (p.org_id, forecast_id))]
    for e in evals:
        e["notes"] = json.loads(e.pop("notes_json"))
    chosen = f["candidates"].get(f["method"], {})
    return {
        "forecast": f,
        "facts": {"history_weeks_used": f["history_weeks"], "knowledge_time": run["knowledge_time"], "data_cutoff_day": run["data_cutoff_day"],
                  "last_complete_week": run["params"]["last_complete_week"], "dataset_fingerprint": run["dataset_fingerprint"],
                  "engine_version": run["engine_version"], "policy_id": run["policy_id"], "policy_methods": run["params"]["policy_methods"]},
        "estimate": {"what": "Total demand for %s at %s from %s to %s" % (f["sku"], f["location"], f["target_start"], f["target_end"]),
                     "point": f["point"], "range": [f["low"], f["high"]],
                     "range_meaning": ("A prediction interval: the range is set so that about %d%% of this method's own past %d-week errors on this "
                                       "series would have fallen inside it. It is not a confidence interval for a parameter, and past errors overlap "
                                       "in time, so real coverage can be lower. Check measured coverage in performance." % (round(f["level"] * 100), f["horizon_weeks"]))},
        "method": {"chosen": f["method"], "why": "lowest error on this series' own earlier windows among the policy's methods (with a preference for the "
                   "equal-weight combination unless another method is at least 10% better)", "chosen_internal_wape": chosen.get("internal_wape"),
                   "all_candidates": f["candidates"]},
        "limitations": f["notes"] + ["Calendar, price, promotion and stock-out effects are not modelled as inputs.",
                                     "Selection evidence covers this series only; it is not proof the method will keep working."],
        "evaluations": evals,
        "claim_types": {"facts": "observed or recorded", "estimate": "statistical estimate", "method": "model selection evidence",
                        "limitations": "known gaps"},
    }


def reconstruct(store, p, forecast_id):
    """Rebuild the forecast from exactly the data known at its knowledge time and check it matches what was stored."""
    f = get_forecast(store, p, forecast_id)
    run = get_run(store, p, f["run_id"])
    kt, through = run["knowledge_time"], date.fromisoformat(run["params"]["last_complete_week"]) + timedelta(days=6)
    by_loc = run["params"]["by_location"]
    w = memory.weekly_demand(store, p.org_id, kt, through, [f["sku"]], [f["location"]] if by_loc else None, by_loc)
    fp, _ = memory.fingerprint(store, p.org_id, kt, through, run["params"]["skus"])
    y = w["series"].get((f["sku"], f["location"]))
    est = forecast_total(y, f["horizon_weeks"], f["level"], run["params"]["policy_methods"]) if y else None
    match = bool(est) and abs(est["point"] - f["point"]) < 1e-9 and abs(est["low"] - f["low"]) < 1e-9 and est["method"] == f["method"]
    return {"forecast_id": forecast_id, "knowledge_time": kt, "fingerprint_then": run["dataset_fingerprint"], "fingerprint_recomputed": fp,
            "fingerprint_matches": fp == run["dataset_fingerprint"], "history_weeks": len(y) if y else 0,
            "recomputed_point": est["point"] if est else None, "stored_point": f["point"], "matches": match}


# ---------- backtests ----------

def _metrics(pairs):
    """pairs: list of (forecast, actual). Point-error metrics; WAPE and bias are relative to total actual."""
    n = len(pairs)
    if not n:
        return None
    a = sum(x for _, x in pairs)
    ae = sum(abs(f - x) for f, x in pairs)
    se = sum((f - x) ** 2 for f, x in pairs)
    return {"n": n, "mae": ae / n, "rmse": math.sqrt(se / n), "wape": ae / a if a > 0 else None,
            "bias": (sum(f for f, _ in pairs) - a) / a if a > 0 else None}


def _interval_score(rows, level):
    alpha = 1 - level
    tot = sum((r[1] - r[0]) + (2 / alpha) * max(r[0] - r[2], 0) + (2 / alpha) * max(r[2] - r[1], 0) for r in rows)
    m = sum(r[2] for r in rows) / len(rows)
    return tot / len(rows) / m if m > 0 else None


def run_backtest(store, p, horizon=4, step=4, min_train=52, level=0.8, candidate_policy_id=None, knowledge_time=None,
                 by_location=True, skus=None, request_id=None, now=None, keep_rows=False):
    require(p, "analyst")
    if not 1 <= int(horizon) <= 26 or not 1 <= int(step) <= 52 or not 13 <= int(min_train) <= 260:
        raise Invalid("horizon 1-26, step 1-52, min_train 13-260")
    horizon, step, min_train, level = int(horizon), int(step), int(min_train), float(level)
    kt = memory.kt_str(knowledge_time or now)
    act = active_policy(store, p.org_id)
    pols = {"active:" + act["name"]: act}
    if candidate_policy_id:
        cand = _policy(store.conn(), p.org_id, candidate_policy_id)
        pols["candidate:" + cand["name"]] = cand
    w = memory.weekly_demand(store, p.org_id, kt, None, skus, None, by_location)
    fp, _ = memory.fingerprint(store, p.org_id, kt, w["last_week"] + timedelta(days=6), skus)
    cats = {r["sku"]: r["category"] or "uncategorised" for r in store.conn().execute("SELECT sku, category FROM products WHERE org_id=?", (p.org_id,))}
    models = list(pols) + list(BASELINES)
    # rows[model] -> list of dicts
    rows = {m: [] for m in models}
    windows = []
    excluded = []
    for key in sorted(w["series"]):
        y = w["series"][key]
        origins = list(range(min_train, len(y) - horizon + 1, step))
        if not origins:
            excluded.append({"sku": key[0], "location": key[1], "weeks": len(y)}); continue
        seg = {"category": cats.get(key[0], "uncategorised"), "demand_class": demand_class(y), "location": key[1]}
        start = w["start"][key]
        for o in origins:
            hist, act_w = y[:o], y[o:o + horizon]
            origin_week = (start + timedelta(weeks=o)).isoformat()
            windows.append(origin_week)
            for name, pol in pols.items():
                e = forecast_total(hist, horizon, level, pol["methods"])
                rows[name].append({"key": key, "seg": seg, "origin": origin_week, "weekly": e["weekly"], "actual": act_w,
                                   "low": e["low"], "high": e["high"], "method": e["method"]})
            for b in BASELINES:
                f = baseline_weekly(b, hist, horizon)
                if f is not None:
                    rows[b].append({"key": key, "seg": seg, "origin": origin_week, "weekly": f, "actual": act_w})
    if not windows:
        raise InsufficientData("no series has %d weeks of history plus a %d-week horizon to test" % (min_train, horizon))
    origins_sorted = sorted(set(windows))
    split = origins_sorted[int(len(origins_sorted) * 0.6)] if len(origins_sorted) >= 2 else origins_sorted[-1]

    def summarise(rs):
        if not rs:
            return None
        weekly = [(f, a) for r in rs for f, a in zip(r["weekly"], r["actual"])]
        totals = [(sum(r["weekly"]), sum(r["actual"])) for r in rs]
        out = {"windows": len(rs), "weekly": _metrics(weekly), "window_total": _metrics(totals),
               "by_horizon_week": {str(h + 1): _metrics([(r["weekly"][h], r["actual"][h]) for r in rs]) for h in range(horizon)}}
        if "low" in rs[0]:
            out["coverage"] = sum(r["low"] <= sum(r["actual"]) <= r["high"] for r in rs) / len(rs)
            out["interval_score"] = _interval_score([(r["low"], r["high"], sum(r["actual"])) for r in rs], level)
            out["mean_relative_width"] = (sum(r["high"] - r["low"] for r in rs) / max(sum(sum(r["weekly"]) for r in rs), 1e-9))
        return out

    results = {}
    for m in models:
        rs = rows[m]
        res = {"all": summarise(rs), "validation": summarise([r for r in rs if r["origin"] < split]),
               "test": summarise([r for r in rs if r["origin"] >= split]), "by_segment": {}}
        for dim in ("category", "demand_class", "location"):
            groups = {}
            for r in rs:
                groups.setdefault(r["seg"][dim], []).append(r)
            res["by_segment"][dim] = {g: summarise(v)["window_total"] for g, v in sorted(groups.items())}
        if m in pols:
            mc = {}
            for r in rs:
                mc[r["method"]] = mc.get(r["method"], 0) + 1
            res["methods_chosen"] = mc
        results[m] = res
    # worst series for the active policy, shown on purpose
    act_name = "active:" + act["name"]
    per = {}
    for r in rows[act_name]:
        per.setdefault(r["key"], []).append((sum(r["weekly"]), sum(r["actual"])))
    worst = sorted(({"sku": k[0], "location": k[1], **_metrics(v)} for k, v in per.items() if _metrics(v)["wape"] is not None),
                   key=lambda d: -d["wape"])[:10]
    base = {(r["key"], r["origin"]): r for r in rows["moving_avg_4"]}
    by_series = []
    for k, v in sorted(per.items()):
        bl = [(sum(base[(k, r["origin"])]["weekly"]), sum(r["actual"])) for r in rows[act_name] if r["key"] == k and (k, r["origin"]) in base]
        m, mb = _metrics(v), _metrics(bl)
        by_series.append({"sku": k[0], "location": k[1], "windows": m["n"], "wape": m["wape"], "bias": m["bias"],
                          "baseline_wape": mb["wape"] if mb else None,
                          "coverage": sum(r["low"] <= sum(r["actual"]) <= r["high"] for r in rows[act_name] if r["key"] == k) / m["n"],
                          "demand_class": next(r["seg"]["demand_class"] for r in rows[act_name] if r["key"] == k),
                          "mean_window_actual": sum(x for _, x in v) / len(v)})
    out = {"params": {"horizon_weeks": horizon, "step_weeks": step, "min_train_weeks": min_train, "level": level,
                      "by_location": by_location, "skus": skus, "validation_test_split_origin": split},
           "models": results, "policies": {k: v["id"] for k, v in pols.items()}, "worst_series_active": worst,
           "excluded_series": excluded, "origins": len(origins_sorted), "by_series_active": by_series,
           "notes": ["Each estimate used only weeks before its origin.",
                     "Origins before %s are the validation half; from %s on, the test half. Promotion needs a win on both." % (split, split),
                     "This backtest uses data as known now, including later corrections, so it can be slightly kinder than a "
                     "true point-in-time replay. Stored forecast runs are the point-in-time record.",
                     "Weeks with stock-outs may understate demand for every model alike."]}
    bid = new_id("bt")
    with store.tx() as c:
        c.execute("INSERT INTO backtests VALUES(?,?,?,?,?,?,?,?,?,?)",
                  (bid, p.org_id, ts(now), p.actor, __version__, kt, w["cutoff_day"].isoformat(), fp, dumps(out["params"]), dumps(out)))
        audit.record(c, p.org_id, p.actor, "backtest.run", "backtest", bid, request_id, {"origins": len(origins_sorted)})
    res = {"id": bid, "knowledge_time": kt, "dataset_fingerprint": fp, **out}
    if keep_rows:
        res["rows_active"] = [{"sku": r["key"][0], "location": r["key"][1], "origin": r["origin"], "point": sum(r["weekly"]),
                               "low": r["low"], "high": r["high"], "actual": sum(r["actual"]), "method": r["method"],
                               "baseline": sum(base[(r["key"], r["origin"])]["weekly"]) if (r["key"], r["origin"]) in base else None}
                              for r in rows[act_name]]
    return res


def get_backtest(store, p, bid):
    r = store.conn().execute("SELECT * FROM backtests WHERE id=? AND org_id=?", (bid, p.org_id)).fetchone()
    if not r:
        raise NotFound("no backtest %s in this organisation" % bid)
    return {"id": r["id"], "created_at": r["created_at"], "knowledge_time": r["knowledge_time"], "dataset_fingerprint": r["dataset_fingerprint"],
            "engine_version": r["engine_version"], **json.loads(r["results_json"])}


def leaderboard(bt, period="test"):
    rows = []
    for m, res in bt["models"].items():
        s = res.get(period)
        if not s:
            continue
        rows.append({"model": m, "wape": s["window_total"]["wape"], "bias": s["window_total"]["bias"], "mae": s["weekly"]["mae"],
                     "rmse": s["weekly"]["rmse"], "coverage": s.get("coverage"), "interval_score": s.get("interval_score"), "windows": s["windows"]})
    return sorted(rows, key=lambda r: (r["wape"] is None, r["wape"]))


# ---------- promotion ----------

PROMOTE_MARGIN = 0.98
MIN_TEST_WINDOWS = 30


def promote(store, p, policy_id, backtest_id, request_id=None):
    require(p, "admin")
    bt = get_backtest(store, p, backtest_id)
    act = active_policy(store, p.org_id)
    cand_name = next((k for k, v in bt["policies"].items() if v == policy_id and k.startswith("candidate:")), None)
    act_name = next((k for k, v in bt["policies"].items() if v == act["id"] and k.startswith("active:")), None)
    reasons = []
    if policy_id == act["id"]:
        reasons.append("this policy is already active")
    if not cand_name:
        reasons.append("the backtest does not include this policy as a candidate")
    if not act_name:
        reasons.append("the backtest was not run against the currently active policy")
    evidence = {"backtest_id": backtest_id}
    if not reasons:
        c_m, a_m = bt["models"][cand_name], bt["models"][act_name]
        for period in ("validation", "test"):
            cw, aw = c_m[period]["window_total"]["wape"], a_m[period]["window_total"]["wape"]
            evidence[period] = {"candidate_wape": cw, "active_wape": aw}
            if cw is None or aw is None or cw > aw * PROMOTE_MARGIN:
                reasons.append("%s period: candidate error %.1f%% is not at least 2%% better than active %.1f%%" % (period, (cw or 0) * 100, (aw or 0) * 100))
        n = c_m["test"]["windows"]
        if n < MIN_TEST_WINDOWS:
            reasons.append("only %d test windows; at least %d needed" % (n, MIN_TEST_WINDOWS))
        lv = bt["params"]["level"]
        cc, ac = c_m["test"].get("coverage"), a_m["test"].get("coverage")
        evidence["coverage"] = {"candidate": cc, "active": ac, "target": lv}
        if cc is not None and ac is not None and abs(cc - lv) > max(0.1, abs(ac - lv)):
            reasons.append("candidate interval coverage %.0f%% is further from the %.0f%% target than allowed" % (cc * 100, lv * 100))
    stale = _fp_now(store, p, bt) != bt["dataset_fingerprint"]
    if stale:
        reasons.append("data changed since this backtest; run it again on current data")
    if reasons:
        with store.tx() as c:
            audit.record(c, p.org_id, p.actor, "policy.promote_refused", "policy", policy_id, request_id, {"reasons": reasons})
        raise Conflict("promotion refused", code="promotion_refused", details={"reasons": reasons, "evidence": evidence})
    with store.tx() as c:
        c.execute("INSERT INTO policy_log(org_id,policy_id,action,at,actor,evidence_json) VALUES(?,?,?,?,?,?)",
                  (p.org_id, policy_id, "promote", ts(), p.actor, dumps({**evidence, "previous_policy": act["id"]})))
        audit.record(c, p.org_id, p.actor, "policy.promote", "policy", policy_id, request_id, evidence)
    return {"promoted": policy_id, "previous": act["id"], "evidence": evidence}


def _fp_now(store, p, bt):
    # the fingerprint the backtest saw covered complete weeks up to its cutoff; compare like with like
    w = memory.weekly_demand(store, p.org_id, None, None, bt["params"]["skus"], None, bt["params"]["by_location"])
    return memory.fingerprint(store, p.org_id, None, w["last_week"] + timedelta(days=6), bt["params"]["skus"])[0]


def rollback(store, p, request_id=None):
    require(p, "admin")
    c = store.conn()
    hist = [r["policy_id"] for r in c.execute("SELECT policy_id FROM policy_log WHERE org_id=? AND action IN ('activate','promote','rollback') ORDER BY id", (p.org_id,))]
    cur = hist[-1]
    prev = next((x for x in reversed(hist[:-1]) if x != cur), None)
    if not prev:
        raise Conflict("there is no earlier policy to roll back to")
    with store.tx() as c:
        c.execute("INSERT INTO policy_log(org_id,policy_id,action,at,actor,evidence_json) VALUES(?,?,?,?,?,?)",
                  (p.org_id, prev, "rollback", ts(), p.actor, dumps({"from": cur})))
        audit.record(c, p.org_id, p.actor, "policy.rollback", "policy", prev, request_id, {"from": cur})
    return {"active": prev, "rolled_back_from": cur}
