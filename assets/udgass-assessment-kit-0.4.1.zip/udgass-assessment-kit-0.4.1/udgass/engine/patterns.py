"""Pattern detection with evidence. A finding is an observation or hypothesis, never a conclusion about cause.

Each finding stores: what was observed, the supporting numbers, the period, the method, assumptions, known limits,
uncertainty where the method gives one, and validated=0 (no person has confirmed it). Findings are ranked by size so a
reviewer sees the material ones first; the total count is always reported so nothing is hidden by the ranking.
Measured detector behaviour on synthetic data (false flags, recall) is in README.md.
"""
from __future__ import annotations
import json, math, random
from datetime import date, timedelta
from ..detect import PRESETS, episodes, scan
from .db import dumps, new_id, ts
from .errors import Invalid
from .tenancy import require
from .patterns_util import demand_class
from . import audit, memory

NOT_CAUSE = "Coinciding events are an association in the recorded data, not proof of cause."


def _median(xs):
    s = sorted(xs); n = len(s)
    return s[n // 2] if n % 2 else (s[n // 2 - 1] + s[n // 2]) / 2


def _boot_median_diff(a, b, n=2000, seed=11):
    rnd = random.Random(seed)
    ds = sorted(_median([rnd.choice(b) for _ in b]) - _median([rnd.choice(a) for _ in a]) for _ in range(n))
    return ds[int(0.05 * n)], ds[int(0.95 * n)]


def run(store, p, knowledge_time=None, sensitivity="balanced", by_location=True, request_id=None, now=None):
    require(p, "analyst")
    if sensitivity not in PRESETS:
        raise Invalid("sensitivity must be one of %s" % ", ".join(PRESETS))
    kt = memory.kt_str(knowledge_time or now)
    w = memory.weekly_demand(store, p.org_id, kt, None, None, None, by_location)
    fp, _ = memory.fingerprint(store, p.org_id, kt, w["last_week"] + timedelta(days=6))
    found = []
    evs = memory.events(store, p.org_id, None, None, kt)
    classes = {}
    for key in sorted(w["series"]):
        sku, loc = key
        y = w["series"][key]
        s0 = w["start"][key]
        wk = lambda i: (s0 + timedelta(weeks=i))
        classes[key] = demand_class(y)
        stock_out = set(memory.stockout_weeks(store, p.org_id, sku, loc if by_location else None, kt))
        # 1. unusual weeks and level shifts
        for ep in episodes(scan(y, **PRESETS[sensitivity])):
            a, b = wk(ep["index"]), wk(ep["end_index"]) + timedelta(days=6)
            co = [e for e in evs if (e["sku"] in (None, sku)) and (e["location"] in (None, loc)) and e["start_day"] <= b.isoformat() and e["end_day"] >= a.isoformat()]
            so = sorted(d.isoformat() for d in stock_out if a <= d <= b)
            impact = sum(abs(y[i] - ep["expected"]) for i in range(ep["index"], ep["end_index"] + 1))
            lim = ["Expected value comes from this series' own history only.", NOT_CAUSE]
            if so:
                lim.append("Stock was recorded at zero in this period: lower sales may reflect supply, not demand.")
            found.append(_f("demand_change", sku, loc, a, b,
                            "%s: %s, observed %.0f vs expected %.0f" % (sku, ep["kind"].replace("_", " "), ep["observed"], ep["expected"]),
                            {"observed": ep["observed"], "expected": ep["expected"], "peak_z": round(ep["peak_z"], 2), "weeks": ep["weeks_affected"],
                             "impact_units": round(impact, 1), "coinciding_events": [dict(type=e["event_type"], start=e["start_day"], end=e["end_day"]) for e in co],
                             "stockout_weeks": so},
                            "robust z-score and CUSUM on weekly demand (%s preset)" % sensitivity,
                            ["expected = trailing median, scaled by last year's shape when a year of history exists"], lim,
                            {"peak_z": round(ep["peak_z"], 2)}, impact))
        # 2. growth change: year-over-year growth in the last 26 weeks vs the 26 weeks before (seasonality cancels out)
        if len(y) >= 104 and classes[key] in ("smooth", "erratic"):
            r = [math.log((y[t] + 1) / (y[t - 52] + 1)) for t in range(len(y) - 52, len(y))]
            r1, r2 = r[:26], r[26:]
            m1, m2 = sum(r1) / 26, sum(r2) / 26
            v1 = sum((x - m1) ** 2 for x in r1) / 25; v2 = sum((x - m2) ** 2 for x in r2) / 25
            se = math.sqrt(v1 / 26 + v2 / 26)
            diff = m2 - m1
            if se > 0 and abs(diff) / se > 3 and abs(diff) > 0.1:
                found.append(_f("growth_change", sku, loc, wk(len(y) - 52), wk(len(y) - 1) + timedelta(days=6),
                                "%s: growth vs last year changed from %+.0f%% to %+.0f%%" % (sku, (math.exp(m1) - 1) * 100, (math.exp(m2) - 1) * 100),
                                {"yoy_growth_earlier_26w": math.exp(m1) - 1, "yoy_growth_recent_26w": math.exp(m2) - 1},
                                "mean weekly log ratio to the same week a year earlier, two consecutive 26-week windows, Welch t-statistic",
                                ["the same calendar week is comparable across years"],
                                ["Weeks are autocorrelated, so the t-statistic overstates certainty.", "Calendar shifts (holidays) are not adjusted."],
                                {"difference_log_ratio": diff, "standard_error": se, "t": diff / se}, abs(diff) * lvl_of(y) * 26))
        # 3. stock-outs that censor sales
        recent_so = [d for d in stock_out if d >= w["last_week"] - timedelta(weeks=25)]
        if recent_so:
            found.append(_f("censored_demand", sku, loc, min(recent_so), w["last_week"] + timedelta(days=6),
                            "%s: stock recorded at zero in %d of the last 26 weeks" % (sku, len(recent_so)),
                            {"weeks": [d.isoformat() for d in sorted(recent_so)]}, "zero on-hand snapshots",
                            ["a zero snapshot means the plant could not sell for at least part of that week"],
                            ["Snapshots are weekly; shorter stock-outs between snapshots are not seen.",
                             "Sales in these weeks understate demand; forecasts built on them are biased low."], None, len(recent_so) * lvl_of(y)))
        # 4. possible missing exports: runs of 2+ empty weeks in a series that is normally never empty
        if classes[key] in ("smooth", "erratic") and w["gaps"][key]:
            runs, i = [], 0
            while i < len(y):
                if y[i] == 0:
                    j = i
                    while j < len(y) and y[j] == 0:
                        j += 1
                    if j - i >= 2:
                        runs.append((i, j - 1))
                    i = j
                else:
                    i += 1
            for a_, b_ in runs:
                if any(wk(k) in stock_out for k in range(a_, b_ + 1)):
                    continue
                found.append(_f("data_gap", sku, loc, wk(a_), wk(b_) + timedelta(days=6),
                                "%s: %d consecutive weeks with no sales rows, while stock was not recorded at zero" % (sku, b_ - a_ + 1),
                                {"weeks": b_ - a_ + 1}, "runs of empty weeks in a series that is usually never empty",
                                ["empty weeks are stored as zero demand"], ["Could be a real pause in demand. Check the export."], None,
                                (b_ - a_ + 1) * lvl_of(y)))
    # 5. vendor lead-time change
    pos = memory.purchase_orders(store, p.org_id, None, None, kt)
    lts = memory.lead_times_days(pos)
    byv = {}
    for l in lts:
        byv.setdefault(l["supplier"] or "unknown", []).append(l)
    end = w["cutoff_day"]
    for v, ls in sorted(byv.items()):
        recent = [l["days"] for l in ls if l["received_day"] > (end - timedelta(weeks=26)).isoformat()]
        before = [l["days"] for l in ls if (end - timedelta(weeks=78)).isoformat() < l["received_day"] <= (end - timedelta(weeks=26)).isoformat()]
        if len(recent) < 15 or len(before) < 15:
            continue
        d = _median(recent) - _median(before)
        lo, hi = _boot_median_diff(before, recent)
        if abs(d) >= 3 and (lo > 0 or hi < 0):
            found.append(_f("lead_time_change", None, None, end - timedelta(weeks=26), end,
                            "Vendor %s: median lead time %g days in the last 26 weeks vs %g days in the 52 weeks before" % (v, _median(recent), _median(before)),
                            {"vendor": v, "recent_median_days": _median(recent), "earlier_median_days": _median(before), "recent_n": len(recent), "earlier_n": len(before)},
                            "difference of medians by receipt date, 90% bootstrap interval (2,000 resamples, fixed seed)", ["receipts are independent"],
                            ["Order size, season and expediting are not controlled for.", NOT_CAUSE],
                            {"difference_days": d, "approx_90pct": [lo, hi]}, abs(d) * 10))

    # 6. excess stock vs the latest forecast
    run_row = store.conn().execute("SELECT id FROM forecast_runs WHERE org_id=? AND knowledge_time<=? ORDER BY created_at DESC LIMIT 1", (p.org_id, kt)).fetchone()
    if run_row:
        for f in store.conn().execute("SELECT sku, location, point, horizon_weeks, target_start FROM forecasts WHERE run_id=?", (run_row[0],)):
            pos_ = memory.inventory_position(store, p.org_id, f["sku"], f["location"], w["cutoff_day"], kt)
            if not pos_:
                continue
            weekly = f["point"] / f["horizon_weeks"]
            cover = pos_[1] / weekly if weekly > 0 else None
            if cover is not None and cover > 13:
                found.append(_f("excess_stock", f["sku"], f["location"], pos_[0], pos_[0],
                                "%s: %.0f on hand covers about %.0f weeks of estimated demand" % (f["sku"], pos_[1], cover),
                                {"on_hand": pos_[1], "snapshot_day": pos_[0].isoformat(), "estimated_weekly_demand": weekly, "forecast_run": run_row[0]},
                                "on-hand divided by the latest forecast's weekly rate", ["threshold 13 weeks of cover"],
                                ["Open orders not included.", "The forecast range is wide for some products; see the forecast.", "For intermittent demand, weeks of cover swings widely."], None, pos_[1] - 13 * weekly))
    # demand profile summary (descriptive)
    counts = {}
    for k, c in classes.items():
        counts[c] = counts.get(c, 0) + 1
    found.append(_f("demand_profiles", None, None, None, None,
                    "Demand profiles: " + ", ".join("%d %s" % (n, c) for c, n in sorted(counts.items())),
                    {"by_series": {"%s|%s" % k: c for k, c in sorted(classes.items())}},
                    "Syntetos-Boylan classification (ADI 1.32, CV-squared 0.49)", ["weekly buckets"],
                    ["Classification describes the past, and changes when the series changes."], None, 0))
    rid = new_id("pat")
    with store.tx() as c:
        for f in found:
            c.execute("INSERT INTO findings VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                      (new_id("fnd"), p.org_id, ts(now), rid, f["kind"], f["sku"], f["location"], f["period_start"], f["period_end"],
                       f["observation"], dumps(f["evidence"]), f["method"], dumps(f["assumptions"]), dumps(f["limitations"]),
                       dumps(f["uncertainty"]) if f["uncertainty"] else None, 0, f["severity"], kt, fp))
        audit.record(c, p.org_id, p.actor, "patterns.run", "pattern_run", rid, request_id, {"findings": len(found)})
    return list_findings(store, p, rid)


def lvl_of(y):
    return max(sum(y[-26:]) / max(len(y[-26:]), 1), 1.0)


def _f(kind, sku, loc, a, b, obs, ev, method, assumptions, limitations, unc, severity):
    return {"kind": kind, "sku": sku, "location": loc, "period_start": a.isoformat() if a else None, "period_end": b.isoformat() if b else None,
            "observation": obs, "evidence": ev, "method": method, "assumptions": assumptions, "limitations": limitations,
            "uncertainty": unc, "severity": float(severity or 0)}


def list_findings(store, p, run_id=None, kind=None, limit=100, offset=0):
    c = store.conn()
    if not run_id:
        r = c.execute("SELECT run_id FROM findings WHERE org_id=? ORDER BY created_at DESC LIMIT 1", (p.org_id,)).fetchone()
        if not r:
            return {"run_id": None, "total": 0, "counts": {}, "items": []}
        run_id = r[0]
    q, a = "FROM findings WHERE org_id=? AND run_id=?", [p.org_id, run_id]
    if kind:
        q += " AND kind=?"; a.append(kind)
    total = c.execute("SELECT COUNT(*) " + q, a).fetchone()[0]
    counts = {r[0]: r[1] for r in c.execute("SELECT kind, COUNT(*) FROM findings WHERE org_id=? AND run_id=? GROUP BY kind", (p.org_id, run_id))}
    limit = max(1, min(int(limit), 500))
    items = []
    for r in c.execute("SELECT * " + q + " ORDER BY severity DESC, id LIMIT ? OFFSET ?", a + [limit, int(offset)]):
        d = dict(r)
        for k in ("evidence", "assumptions", "limitations", "uncertainty"):
            v = d.pop(k + "_json"); d[k] = json.loads(v) if v else None
        d["validated"] = bool(d["validated"]); d.pop("org_id")
        items.append(d)
    return {"run_id": run_id, "total": total, "counts": counts, "items": items}
