"""Small deterministic descriptors shared by forecasting and pattern detection."""
from __future__ import annotations


def demand_class(y, min_weeks=26):
    """Syntetos-Boylan-Croston classification from inter-demand interval (ADI) and squared CV of non-zero sizes."""
    if len(y) < min_weeks:
        return "insufficient_history"
    nz = [v for v in y if v > 0]
    if len(nz) < 3:
        return "mostly_zero"
    adi = len(y) / len(nz)
    m = sum(nz) / len(nz)
    cv2 = (sum((v - m) ** 2 for v in nz) / len(nz)) / (m * m) if m > 0 else 0.0
    if adi < 1.32:
        return "smooth" if cv2 < 0.49 else "erratic"
    return "intermittent" if cv2 < 0.49 else "lumpy"
