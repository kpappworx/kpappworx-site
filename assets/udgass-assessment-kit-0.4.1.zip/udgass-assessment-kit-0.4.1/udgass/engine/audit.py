"""Append-only audit log of every write. Records who, what, when and which object; never data rows or secrets."""
from __future__ import annotations
from .db import dumps, ts


def record(c, org_id, actor, action, object_type=None, object_id=None, request_id=None, detail=None):
    c.execute("INSERT INTO audit_log(org_id,at,actor,action,object_type,object_id,request_id,detail_json) VALUES(?,?,?,?,?,?,?,?)",
              (org_id, ts(), actor, action, object_type, object_id, request_id, dumps(detail or {})))


def list_entries(store, p, limit=100, cursor=None):
    from .tenancy import require
    require(p, "admin")
    limit = max(1, min(int(limit), 500))
    q = "SELECT id, at, actor, action, object_type, object_id, request_id, detail_json FROM audit_log WHERE org_id=?"
    args = [p.org_id]
    if cursor:
        q += " AND id < ?"; args.append(int(cursor))
    rows = [dict(r) for r in store.conn().execute(q + " ORDER BY id DESC LIMIT ?", args + [limit])]
    import json
    for r in rows:
        r["detail"] = json.loads(r.pop("detail_json") or "{}")
    return {"items": rows, "next_cursor": str(rows[-1]["id"]) if len(rows) == limit else None}
