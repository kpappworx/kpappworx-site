"""Outcomes against forecasts, performance over time, and drift. Forecast accuracy is measured here; decision results are
measured in decisions.py. The two are kept apart on purpose: a good forecast can lead to a poor decision and the reverse.

An evaluation is appended, never edited. If the actuals are corrected later, re-evaluating appends a new row with the
new knowledge time, so the earlier assessment stays visible.
"""
from __future__ import annotations
import json
from datetime import date, timedelta
from .db import dumps, ts
from .forecasting import active_policy, baseline_weekly
from .tenancy import require
from . import audit, memory


def evaluate_due(store, p, knowledge_time=None, request_id=None, now=None):
    require(p, "analyst")
    kt = memory.kt_str(knowledge_time or now)
    c = store.conn()
    cache_now, cache_then = {}, {}
    added = unchanged = pending = no_data = 0
    rows = c.execute("SELECT f.*, r.knowledge_time AS run_kt, r.params_json FROM forecasts f JOIN forecast_runs r ON r.id=f.run_id "
                     "WHERE f.org_id=? ORDER BY f.target_end", (p.org_id,)).fetchall()
    new_rows = []
    for f in rows:
        params = json.loads(f["params_json"])
        bl = params["by_location"]
        if bl not in cache_now:
            try:
                cache_now[bl] = memory.weekly_demand(store, p.org_id, kt, None, None, None, bl)
            except Exception:
                cache_now[bl] = None
        wn = cache_now[bl]
        if wn is None or date.fromisoformat(f["target_end"]) > wn["last_week"] + timedelta(days=6):
            pending += 1; continue
        key = (f["sku"], f["location"])
        if key not in wn["series"]:
            no_data += 1; continue
        s0 = wn["start"][key]
        i0 = (date.fromisoformat(f["target_start"]) - s0).days // 7
        ys = wn["series"][key]
        weekly_actual = [ys[i] if 0 <= i < len(ys) else 0.0 for i in range(i0, i0 + f["horizon_weeks"])]
        actual = sum(weekly_actual)
        last = c.execute("SELECT actual FROM forecast_evaluations WHERE org_id=? AND forecast_id=? ORDER BY id DESC LIMIT 1", (p.org_id, f["id"])).fetchone()
        if last is not None and abs(last[0] - actual) < 1e-9:
            unchanged += 1; continue
        tk = (f["run_kt"], bl)
        if tk not in cache_then:
            cache_then[tk] = memory.weekly_demand(store, p.org_id, f["run_kt"], date.fromisoformat(params["last_complete_week"]) + timedelta(days=6), None, None, bl)
        wt = cache_then[tk]
        hist = wt["series"].get(key) or []
        b = baseline_weekly("moving_avg_4", hist, f["horizon_weeks"])
        notes = []
        so = [d for d in memory.stockout_weeks(store, p.org_id, f["sku"], f["location"] if bl else None, kt)
              if f["target_start"] <= d.isoformat() <= f["target_end"]]
        if so:
            notes.append("Stock was recorded at zero in %d target weeks: actual sales may understate demand." % len(so))
        if last is not None:
            notes.append("Re-evaluated because the actuals changed since the previous evaluation (was %.1f)." % last[0])
        new_rows.append((p.org_id, f["id"], ts(now), kt, actual, dumps(weekly_actual), f["point"] - actual,
                         int(f["low"] <= actual <= f["high"]), sum(b) if b else None, dumps(notes)))
        added += 1
    with store.tx() as c2:
        c2.executemany("INSERT INTO forecast_evaluations(org_id,forecast_id,evaluated_at,knowledge_time,actual,weekly_actual_json,error,inside,baseline,notes_json) "
                       "VALUES(?,?,?,?,?,?,?,?,?,?)", new_rows)
        audit.record(c2, p.org_id, p.actor, "evaluation.run", "evaluation", None, request_id, {"added": added, "pending": pending})
    return {"evaluated": added, "unchanged": unchanged, "not_yet_due": pending, "series_without_data": no_data, "knowledge_time": kt}


def _agg(rs):
    a = sum(r["actual"] for r in rs)
    if not rs:
        return None
    out = {"n": len(rs), "actual": a, "wape": sum(abs(r["error"]) for r in rs) / a if a > 0 else None,
           "bias": sum(r["error"] for r in rs) / a if a > 0 else None,
           "coverage": sum(r["inside"] for r in rs) / len(rs)}
    bs = [r for r in rs if r["baseline"] is not None]
    if bs:
        ab = sum(r["actual"] for r in bs)
        out["baseline_wape"] = sum(abs(r["baseline"] - r["actual"]) for r in bs) / ab if ab > 0 else None
    return out


def performance(store, p):
    """Latest evaluation per forecast, summarised overall, by forecast run, by horizon week, by category; plus drift checks."""
    c = store.conn()
    rows = [dict(r) for r in c.execute(
        "SELECT e.*, f.run_id, f.sku, f.location, f.weekly_json, f.level, f.target_start, f.point, f.low, f.high, r.created_at AS run_at "
        "FROM forecast_evaluations e JOIN forecasts f ON f.id=e.forecast_id JOIN forecast_runs r ON r.id=f.run_id "
        "WHERE e.org_id=? AND e.id IN (SELECT MAX(id) FROM forecast_evaluations WHERE org_id=? GROUP BY forecast_id)", (p.org_id, p.org_id))]
    total_fc = c.execute("SELECT COUNT(*) FROM forecasts WHERE org_id=?", (p.org_id,)).fetchone()[0]
    cats = {r["sku"]: r["category"] or "uncategorised" for r in c.execute("SELECT sku, category FROM products WHERE org_id=?", (p.org_id,))}
    by_run = {}
    for r in rows:
        by_run.setdefault((r["run_at"], r["run_id"], r["target_start"]), []).append(r)
    runs = [{"run_id": k[1], "run_at": k[0], "target_start": k[2], **_agg(v)} for k, v in sorted(by_run.items())]
    by_h = {}
    for r in rows:
        f = json.loads(r["weekly_json"]); a = json.loads(r["weekly_actual_json"])
        for i, (x, y) in enumerate(zip(f, a)):
            by_h.setdefault(i + 1, []).append((x, y))
    horizon = {str(h): {"n": len(v), "mae": sum(abs(x - y) for x, y in v) / len(v),
                        "wape": (sum(abs(x - y) for x, y in v) / sum(y for _, y in v)) if sum(y for _, y in v) > 0 else None} for h, v in sorted(by_h.items())}
    by_cat = {}
    for r in rows:
        by_cat.setdefault(cats.get(r["sku"], "uncategorised"), []).append(r)
    drift = []
    bt = c.execute("SELECT results_json FROM backtests WHERE org_id=? ORDER BY created_at DESC LIMIT 1", (p.org_id,)).fetchone()
    overall = _agg(rows)
    if bt and overall and overall["n"] >= 20 and overall["wape"] is not None:
        res = json.loads(bt[0])
        act = next((m for m in res["models"] if m.startswith("active:")), None)
        exp = res["models"][act]["test"]["window_total"]["wape"] if act and res["models"][act].get("test") else None
        if exp:
            ratio = overall["wape"] / exp
            drift.append({"check": "error vs backtest expectation", "live_wape": overall["wape"], "backtest_wape": exp, "ratio": ratio,
                          "flag": ratio > 1.5, "meaning": "Live error more than 1.5 times the backtest's test-period error suggests the data or the method has drifted."})
    if len(runs) >= 3:
        last3 = [r["bias"] for r in runs[-3:] if r["bias"] is not None]
        if len(last3) == 3:
            same = all(b > 0.1 for b in last3) or all(b < -0.1 for b in last3)
            drift.append({"check": "persistent bias", "last_three_periods": last3, "flag": same,
                          "meaning": "Three periods in a row with more than 10% bias in the same direction."})
    if overall and overall["n"] >= 20:
        lv = rows[0]["level"]
        drift.append({"check": "interval coverage", "coverage": overall["coverage"], "target": lv, "flag": overall["coverage"] < lv - 0.15,
                      "meaning": "Coverage more than 15 points under target means the ranges are too narrow."})
    dq = []
    for r in c.execute("SELECT id, dataset_kind, committed_at, report_json FROM imports WHERE org_id=? AND status='committed' ORDER BY committed_at", (p.org_id,)):
        rep = json.loads(r["report_json"])
        if rep.get("rows_read"):
            dq.append({"import_id": r["id"], "kind": r["dataset_kind"], "committed_at": r["committed_at"],
                       "rejected_share": rep["rows_rejected"] / rep["rows_read"], "corrections": rep.get("committed", {}).get("corrections", 0)})
    for kind in {d["kind"] for d in dq}:
        ks = [d for d in dq if d["kind"] == kind]
        if len(ks) >= 2:
            prev = sum(d["rejected_share"] for d in ks[:-1]) / (len(ks) - 1)
            drift.append({"check": "data quality (%s)" % kind, "latest_rejected_share": ks[-1]["rejected_share"], "earlier_average": prev,
                          "flag": ks[-1]["rejected_share"] > max(0.02, 2 * prev), "meaning": "A jump in rejected rows usually means the export changed."})
    return {"completeness": {"forecasts": total_fc, "evaluated": len(rows), "not_yet_evaluated": total_fc - len(rows)},
            "overall": overall, "by_period": runs, "by_horizon_week": horizon,
            "by_category": {k: _agg(v) for k, v in sorted(by_cat.items())}, "drift": drift, "data_quality_history": dq,
            "notes": ["WAPE = total absolute error / total actual. Bias > 0 means forecasts were too high.",
                      "Baseline = mean of the last four weeks known at forecast time, for the same windows.",
                      "These are observed results, not causal effects."]}
