"""Deterministic SYNTHETIC enterprise dataset for development, tests and demos. Not customer data.

What it contains (and the answer key it returns)
- 3 categories, 2 plants, 3 vendors, 16 materials with different demand profiles: smooth seasonal, trending, a trend break,
  a level drop (which leaves excess stock), intermittent spare parts, lumpy, and a new product with short history.
- Daily sales that are CENSORED by stock: when the simulated plant runs out, recorded sales are lower than true demand.
- Weekly stock snapshots, purchase orders with vendor lead times. Vendor V2's lead time roughly doubles part-way through.
- Promotions (recorded as events) that lift demand, and one export gap (two weeks with no rows for one material).
- A history period and a later period. The later files hold the "future": sales, stock and receipts for open orders
  (a receipt date added to an order that was open is a correction of that record).
"""
from __future__ import annotations
import csv, math, os, random
from datetime import date, timedelta

START = date(2023, 1, 2)            # a Monday
HIST_WEEKS = 156
LATER_WEEKS = 12

PROFILES = [
    # name, category, base, trend/wk, season amp, noise cv, kind
    ("M-1001", "Cooling", 120, 0.0, 0.35, 0.12, "seasonal"),
    ("M-1002", "Cooling", 80, 0.15, 0.30, 0.15, "seasonal"),
    ("M-1003", "Cooling", 60, 0.0, 0.10, 0.18, "trend_break"),
    ("M-1004", "Cooling", 45, 0.0, 0.05, 0.20, "level_drop"),
    ("M-1005", "Cooling", 200, -0.2, 0.20, 0.10, "seasonal"),
    ("M-2001", "Power", 150, 0.4, 0.05, 0.10, "trend"),
    ("M-2002", "Power", 90, 0.0, 0.05, 0.12, "promo"),
    ("M-2003", "Power", 70, 0.0, 0.08, 0.15, "smooth"),
    ("M-2004", "Power", 40, 0.0, 0.0, 0.25, "smooth"),
    ("M-2005", "Power", 30, 0.0, 0.0, 0.30, "new"),
    ("M-2006", "Power", 110, 0.0, 0.15, 0.12, "gap"),
    ("M-3001", "Spares", 3, 0.0, 0.0, 0.6, "intermittent"),
    ("M-3002", "Spares", 2, 0.0, 0.0, 0.8, "intermittent"),
    ("M-3003", "Spares", 6, 0.0, 0.0, 1.0, "lumpy"),
    ("M-3004", "Spares", 25, 0.0, 0.0, 0.2, "smooth"),
    ("M-3005", "Spares", 15, 0.05, 0.0, 0.25, "trend"),
]
PLANTS = {"P-BLR": 1.0, "P-PUN": 0.6}
VENDORS = {"Cooling": "V1", "Power": "V2", "Spares": "V3"}


def _lead_days(vendor, week, rnd):
    if vendor == "V1":
        return max(5, int(rnd.gauss(14, 2)))
    if vendor == "V2":
        base = 14 if week < 110 else 28          # the lead-time change to be detected
        return max(5, int(rnd.gauss(base, 3)))
    return max(3, int(rnd.gauss(21, 6)))


def _weekly_demand(prof, plant_scale, w, rnd):
    name, cat, base, trend, amp, cv, kind = prof
    level = base * plant_scale
    if kind == "trend_break":
        level *= 1.0 if w < 100 else 1.0 + 0.012 * (w - 100)
    if kind == "level_drop" and w >= 120:
        level *= 0.5
    if kind == "new" and w < HIST_WEEKS - 20:
        return 0.0
    mu = max(0.0, level + trend * w) * (1 + amp * math.sin(2 * math.pi * (w % 52) / 52 - 1.2))
    if kind == "promo" and w % 13 == 6:
        mu *= 1.6
    if kind in ("intermittent", "lumpy"):
        p_any = 0.35 if kind == "intermittent" else 0.25
        if rnd.random() > p_any:
            return 0.0
        return max(1.0, round(rnd.expovariate(1 / (base * (1 if kind == "intermittent" else 3)))))
    return max(0.0, rnd.gauss(mu, mu * cv))


def generate(out_dir, seed=7):
    """Write the CSV files and return the answer key. Same seed, same files, byte for byte."""
    rnd = random.Random(seed)
    os.makedirs(out_dir, exist_ok=True)
    total_weeks = HIST_WEEKS + LATER_WEEKS
    cutoff = START + timedelta(weeks=HIST_WEEKS) - timedelta(days=1)      # last history day (a Sunday)
    sales = {"hist": [], "later": []}
    inv = {"hist": [], "later": []}
    pos = []                                      # dicts; received may fall after cutoff
    events = []
    truth = {"cutoff_day": cutoff.isoformat(), "patterns": [], "note": "SYNTHETIC data. Not customer results."}
    po_no = 4500000
    for prof in PROFILES:
        name, cat, base, *_rest, kind = prof
        vendor = VENDORS[cat]
        unit_cost = round(5 + rnd.random() * 95, 2)
        for plant, scale in PLANTS.items():
            if kind in ("intermittent", "lumpy") and plant == "P-PUN":
                continue
            dem = [_weekly_demand(prof, scale, w, rnd) for w in range(total_weeks)]
            mean0 = max(1.0, sum(dem[:52]) / 52)
            stock = mean0 * 4
            pipeline = []                        # (arrival_day, qty, po record)
            for w in range(total_weeks):
                wk0 = START + timedelta(weeks=w)
                period = "hist" if w < HIST_WEEKS else "later"
                # receive
                for day_i in range(7):
                    d = wk0 + timedelta(days=day_i)
                    arr = [x for x in pipeline if x[0] == d]
                    for a in arr:
                        stock += a[1]; pipeline.remove(a)
                    want = dem[w] / 7.0 * (1 + rnd.gauss(0, 0.15))
                    want = max(0.0, want)
                    sold = min(stock, want)
                    stock -= sold
                    q = round(sold)
                    if kind == "gap" and plant == "P-BLR" and 70 <= w < 72:
                        continue                 # export gap: rows missing
                    if q > 0:
                        sales[period].append([d.isoformat(), name, plant, q, cat])
                inv[period].append([(wk0 + timedelta(days=6)).isoformat(), name, plant, round(stock)])
                # weekly review, order up to (lead + review + safety) weeks of recent demand
                recent = dem[max(0, w - 7):w + 1]
                rate = max(0.5, sum(recent) / len(recent))
                target = rate * (3 if vendor != "V2" else 3) + rate * 1.5
                if kind == "level_drop" and 112 <= w < 124:
                    target = rate * 9                   # over-ordering before the drop: leaves excess stock
                position = stock + sum(x[1] for x in pipeline)
                if position < target:
                    qty = round(target - position)
                    if qty > 0:
                        lt = _lead_days(vendor, w, rnd)
                        od = wk0 + timedelta(days=4)
                        rec = od + timedelta(days=lt)
                        po_no += 1
                        po = {"po": str(po_no), "line": "10", "sku": name, "plant": plant, "vendor": vendor,
                              "order": od, "promised": od + timedelta(days=14 if vendor != "V3" else 21), "received": rec,
                              "qty": qty, "cost": unit_cost}
                        pos.append(po)
                        pipeline.append((rec, qty, po))
            if kind == "promo":
                for w in range(6, total_weeks, 13):
                    wk0 = START + timedelta(weeks=w)
                    if wk0 <= cutoff:
                        events.append(["promotion", name, plant, wk0.isoformat(), (wk0 + timedelta(days=6)).isoformat(), "Planned promotion (synthetic)"])
    for name, cat, *_r, kind in PROFILES:
        if kind in ("trend_break", "level_drop", "gap", "new", "intermittent", "lumpy", "promo"):
            truth["patterns"].append({"sku": name, "kind": kind,
                                      "week_index": {"trend_break": 100, "level_drop": 120, "gap": 70, "new": HIST_WEEKS - 20}.get(kind)})
    truth["patterns"].append({"vendor": "V2", "kind": "lead_time_increase", "week_index": 110, "from_days": 14, "to_days": 28})
    events.append(["supplier_delay", "", "", (START + timedelta(weeks=110)).isoformat(), (START + timedelta(weeks=118)).isoformat(),
                   "Vendor V2 capacity problem reported (synthetic)"])

    def w(fname, header, rows):
        with open(os.path.join(out_dir, fname), "w", newline="", encoding="utf-8") as f:
            cw = csv.writer(f); cw.writerow(header); cw.writerows(rows)

    w("sales.csv", ["Posting Date", "Material", "Plant", "Order Qty", "Category"], sales["hist"])
    w("sales_later.csv", ["Posting Date", "Material", "Plant", "Order Qty", "Category"], sales["later"])
    w("inventory.csv", ["Snapshot Date", "Material", "Plant", "Stock On Hand"], inv["hist"])
    w("inventory_later.csv", ["Snapshot Date", "Material", "Plant", "Stock On Hand"], inv["later"])
    hdr = ["PO Number", "Line", "Material", "Plant", "Vendor", "PO Date", "Promised Date", "Goods Receipt Date", "Ordered Qty", "Unit Price"]

    def porow(p, known_until):
        rec = p["received"].isoformat() if p["received"] <= known_until else ""
        return [p["po"], p["line"], p["sku"], p["plant"], p["vendor"], p["order"].isoformat(), p["promised"].isoformat(), rec, p["qty"], p["cost"]]
    end = START + timedelta(weeks=total_weeks) - timedelta(days=1)
    w("purchase_orders.csv", hdr, [porow(p, cutoff) for p in pos if p["order"] <= cutoff])
    w("purchase_orders_later.csv", hdr, [porow(p, end) for p in pos if p["order"] <= end])
    w("events.csv", ["Event Type", "Material", "Plant", "Start", "End", "Notes"], events)
    truth["files"] = sorted(os.listdir(out_dir))
    truth["later_end_day"] = end.isoformat()
    return truth
