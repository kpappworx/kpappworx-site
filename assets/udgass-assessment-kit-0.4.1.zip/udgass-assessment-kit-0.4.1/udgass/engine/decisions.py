"""Decision records: a first-class, append-only, hash-chained record per decision.

Entry types, in the order they may happen:
  opened          what was known: linked forecasts and scenarios (snapshotted), assumptions, constraints, objective, options
  recommendation  an option suggested (by a person, or from a scenario result) with its rationale. Not a decision.
  decision        the option a named person chose. Only one, unless a revision re-opens it.
  approval        sign-off by an admin, where the organisation wants one
  action          what was actually done (it may differ from the decision)
  outcome         what was observed afterwards
  revision        a correction or change of course, with a reason; earlier entries stay as they were
  note            anything else
The opening evidence can never be replaced; outcomes are separate entries, so hindsight cannot leak into the record of
what was known. Each entry's hash covers the previous one, so any edit to the database breaks verify().
"""
from __future__ import annotations
import hashlib, json
from datetime import date, timedelta
from .db import dumps, new_id, ts
from .errors import Conflict, Invalid, NotFound
from .tenancy import require
from . import audit, memory

TYPES = ("recommendation", "decision", "approval", "action", "outcome", "revision", "note")
OBJECTIVES = {"min_fill_rate", "no_stockout_weeks", "max_ending_stock", "max_units_ordered"}
GENESIS = "0" * 64


def _h(prev, seq, typ, actor, at, payload):
    return hashlib.sha256(dumps({"prev": prev, "seq": seq, "type": typ, "actor": actor, "at": at, "payload": payload}).encode()).hexdigest()


def _text(x, n, what, required=True):
    x = (x or "").strip() if isinstance(x, str) or x is None else None
    if x is None or (required and not x) or len(x) > n:
        raise Invalid("%s must be text of 1 to %d characters" % (what, n))
    return x


def _append(c, org, did, typ, actor, payload, at=None):
    last = c.execute("SELECT seq, hash FROM decision_log WHERE org_id=? AND decision_id=? ORDER BY seq DESC LIMIT 1", (org, did)).fetchone()
    seq, prev = (last[0] + 1, last[1]) if last else (1, GENESIS)
    at = at or ts()
    h = _h(prev, seq, typ, actor, at, payload)
    c.execute("INSERT INTO decision_log(org_id,decision_id,seq,entry_type,actor,recorded_at,payload_json,prev_hash,hash) VALUES(?,?,?,?,?,?,?,?,?)",
              (org, did, seq, typ, actor, at, dumps(payload), prev, h))
    return seq, h


def create(store, p, title, owner, decision_type="inventory_replenishment", sku=None, location=None, forecast_ids=(), scenario_ids=(),
           options=(), assumptions=None, constraints=None, objective=None, risk_tolerance=None, evidence_notes="", request_id=None, now=None):
    require(p, "analyst")
    title, owner = _text(title, 200, "title"), _text(owner, 120, "owner")
    decision_type = _text(decision_type, 60, "decision_type")
    opts = []
    for o in options or []:
        if not isinstance(o, dict):
            raise Invalid("each option needs a name")
        opts.append({"name": _text(o.get("name"), 80, "option name"), "description": _text(o.get("description"), 500, "option description", False)})
    if len({o["name"] for o in opts}) != len(opts):
        raise Invalid("option names must be unique")
    if objective is not None:
        if not isinstance(objective, dict) or objective.get("metric") not in OBJECTIVES or not isinstance(objective.get("target"), (int, float)):
            raise Invalid("objective must be {metric: one of %s, target: number}" % ", ".join(sorted(OBJECTIVES)))
    if risk_tolerance is not None and risk_tolerance not in ("low", "medium", "high"):
        raise Invalid("risk_tolerance must be low, medium or high")
    c = store.conn()
    fsnap = []
    for fid in forecast_ids or []:
        f = c.execute("SELECT f.id, f.sku, f.location, f.target_start, f.target_end, f.point, f.low, f.high, f.level, f.method, f.evidence_quality, "
                      "r.knowledge_time, r.dataset_fingerprint, r.engine_version, r.policy_id FROM forecasts f JOIN forecast_runs r ON r.id=f.run_id "
                      "WHERE f.id=? AND f.org_id=?", (fid, p.org_id)).fetchone()
        if not f:
            raise NotFound("no forecast %s in this organisation" % fid)
        fsnap.append(dict(f))
    ssnap = []
    for sid in scenario_ids or []:
        s = c.execute("SELECT id, name, sku, location, knowledge_time, results_json FROM scenarios WHERE id=? AND org_id=?", (sid, p.org_id)).fetchone()
        if not s:
            raise NotFound("no scenario %s in this organisation" % sid)
        res = json.loads(s["results_json"])
        ssnap.append({"id": s["id"], "name": s["name"], "knowledge_time": s["knowledge_time"],
                      "variants": [{"name": v["name"], "fill_rate": (v.get("results") or {}).get("fill_rate"),
                                    "avg_on_hand": (v.get("results") or {}).get("avg_on_hand"), "policy_used": v.get("policy_used"),
                                    "constraints": v.get("constraints")} for v in res["variants"]]})
    did = new_id("dec")
    at = ts(now)
    payload = {"knowledge_time": at, "forecasts": fsnap, "scenarios": ssnap, "options": opts, "assumptions": assumptions or {},
               "constraints": constraints or {}, "objective": objective, "risk_tolerance": risk_tolerance,
               "evidence_notes": _text(evidence_notes, 2000, "evidence_notes", False)}
    with store.tx() as c:
        c.execute("INSERT INTO decisions VALUES(?,?,?,?,?,?,?,?,?)", (did, p.org_id, at, p.actor, decision_type, title, owner, sku, location))
        _append(c, p.org_id, did, "opened", p.actor, payload, at)
        audit.record(c, p.org_id, p.actor, "decision.open", "decision", did, request_id, {"title": title})
    return get(store, p, did)


def _entries(c, org, did):
    rows = [dict(r) for r in c.execute("SELECT seq, entry_type, actor, recorded_at, payload_json, prev_hash, hash FROM decision_log "
                                       "WHERE org_id=? AND decision_id=? ORDER BY seq", (org, did))]
    for r in rows:
        r["payload"] = json.loads(r.pop("payload_json"))
    return rows


def _state(entries):
    st = {"status": "open", "recommendations": 0, "decided_option": None, "approved": None, "actions": 0, "outcomes": 0}
    for e in entries:
        t = e["entry_type"]
        if t == "recommendation":
            st["recommendations"] += 1
        elif t == "decision":
            st["decided_option"] = e["payload"]["option"]; st["status"] = "decided"
        elif t == "approval":
            st["approved"] = e["payload"]["approved"]
        elif t == "action":
            st["actions"] += 1; st["status"] = "acted"
        elif t == "outcome":
            st["outcomes"] += 1; st["status"] = "outcome_recorded"
        elif t == "revision" and e["payload"].get("reopen"):
            st["decided_option"] = None; st["status"] = "open"; st["approved"] = None
    return st


def add_entry(store, p, did, entry_type, payload, request_id=None, now=None):
    if entry_type not in TYPES:
        raise Invalid("entry type must be one of %s" % ", ".join(TYPES))
    require(p, "admin" if entry_type == "approval" else "analyst")
    if not isinstance(payload, dict):
        raise Invalid("payload must be an object")
    c = store.conn()
    d = c.execute("SELECT * FROM decisions WHERE id=? AND org_id=?", (did, p.org_id)).fetchone()
    if not d:
        raise NotFound("no decision %s in this organisation" % did)
    ents = _entries(c, p.org_id, did)
    st = _state(ents)
    opts = {o["name"] for o in ents[0]["payload"]["options"]}
    clean = {}
    if entry_type == "recommendation":
        clean["option"] = _text(payload.get("option"), 80, "option")
        if opts and clean["option"] not in opts:
            raise Invalid("option must be one of %s" % ", ".join(sorted(opts)))
        clean["rationale"] = _text(payload.get("rationale"), 2000, "rationale")
        clean["source"] = payload.get("source") if payload.get("source") in ("person", "scenario") else "person"
        if payload.get("scenario_id"):
            clean["scenario_id"] = _text(payload["scenario_id"], 40, "scenario_id")
        clean["is_decision"] = False
    elif entry_type == "decision":
        if st["decided_option"] is not None:
            raise Conflict("a decision is already recorded; add a revision with reopen=true to change it")
        clean["option"] = _text(payload.get("option"), 80, "option")
        if opts and clean["option"] not in opts:
            raise Invalid("option must be one of %s" % ", ".join(sorted(opts)))
        clean["decided_by"] = _text(payload.get("decided_by"), 120, "decided_by")
        clean["rationale"] = _text(payload.get("rationale"), 2000, "rationale")
    elif entry_type == "approval":
        if st["decided_option"] is None:
            raise Conflict("nothing to approve: no decision recorded")
        if not isinstance(payload.get("approved"), bool):
            raise Invalid("approved must be true or false")
        clean = {"approved": payload["approved"], "comment": _text(payload.get("comment"), 1000, "comment", False)}
    elif entry_type == "action":
        if st["decided_option"] is None:
            raise Conflict("record the decision before the action taken")
        clean["description"] = _text(payload.get("description"), 1000, "description")
        clean["executed_on"] = _day(payload.get("executed_on"), "executed_on")
        if payload.get("quantity") is not None:
            if not isinstance(payload["quantity"], (int, float)) or payload["quantity"] < 0:
                raise Invalid("quantity must be a number >= 0")
            clean["quantity"] = payload["quantity"]
        clean["matches_decision"] = bool(payload.get("matches_decision", True))
    elif entry_type == "outcome":
        if st["actions"] == 0:
            raise Conflict("record the action taken before an outcome")
        clean["period_start"] = _day(payload.get("period_start"), "period_start")
        clean["period_end"] = _day(payload.get("period_end"), "period_end")
        if clean["period_end"] < clean["period_start"]:
            raise Invalid("period_end is before period_start")
        vals = payload.get("values") or {}
        if not isinstance(vals, dict) or any(not isinstance(v, (int, float)) for v in vals.values()):
            raise Invalid("values must be an object of numbers")
        clean["values"] = vals
        clean["note"] = _text(payload.get("note"), 2000, "note", False)
    elif entry_type == "revision":
        clean["reason"] = _text(payload.get("reason"), 2000, "reason")
        clean["reopen"] = bool(payload.get("reopen"))
        clean["changes"] = payload.get("changes") if isinstance(payload.get("changes"), dict) else {}
    else:
        clean["text"] = _text(payload.get("text"), 4000, "text")
    with store.tx() as c:
        seq, h = _append(c, p.org_id, did, entry_type, p.actor, clean, ts(now))
        audit.record(c, p.org_id, p.actor, "decision." + entry_type, "decision", did, request_id, {"seq": seq})
    return get(store, p, did)


def _day(x, what):
    try:
        return date.fromisoformat(str(x)).isoformat()
    except ValueError:
        raise Invalid("%s must be a date YYYY-MM-DD" % what)


def get(store, p, did):
    c = store.conn()
    d = c.execute("SELECT * FROM decisions WHERE id=? AND org_id=?", (did, p.org_id)).fetchone()
    if not d:
        raise NotFound("no decision %s in this organisation" % did)
    ents = _entries(c, p.org_id, did)
    out = dict(d); out.pop("org_id")
    return {**out, "state": _state(ents), "entries": ents}


def list_decisions(store, p, limit=50, cursor=None):
    limit = max(1, min(int(limit), 200))
    q, a = "SELECT id FROM decisions WHERE org_id=?", [p.org_id]
    if cursor:
        q += " AND created_at < ?"; a.append(cursor)
    items = []
    for r in store.conn().execute(q + " ORDER BY created_at DESC LIMIT ?", a + [limit]):
        g = get(store, p, r[0]); g.pop("entries"); items.append(g)
    return {"items": items, "next_cursor": items[-1]["created_at"] if len(items) == limit else None}


def verify(store, p, did):
    ents = _entries(store.conn(), p.org_id, did)
    if not ents:
        raise NotFound("no decision %s in this organisation" % did)
    prev = GENESIS
    for i, e in enumerate(ents, 1):
        if e["seq"] != i or e["prev_hash"] != prev or e["hash"] != _h(prev, e["seq"], e["entry_type"], e["actor"], e["recorded_at"], e["payload"]):
            return {"ok": False, "broken_at": i}
        prev = e["hash"]
    return {"ok": True, "entries": len(ents)}


def evaluate(store, p, did, knowledge_time=None):
    """Two separate questions. 1: how accurate were the forecasts that were considered? 2: did the observed outcome meet the
    stated objective? Neither answer says the decision caused the outcome."""
    g = get(store, p, did)
    ents = g["entries"]
    opened = ents[0]["payload"]
    c = store.conn()
    fq = []
    for f in opened["forecasts"]:
        e = c.execute("SELECT actual, error, inside, baseline, evaluated_at, knowledge_time FROM forecast_evaluations WHERE org_id=? AND forecast_id=? "
                      "ORDER BY id DESC LIMIT 1", (p.org_id, f["id"])).fetchone()
        fq.append({"forecast_id": f["id"], "estimate": f["point"], "range": [f["low"], f["high"]],
                   **({"actual": e["actual"], "abs_pct_error": abs(e["error"]) / e["actual"] if e["actual"] else None, "inside_range": bool(e["inside"]),
                       "baseline_estimate": e["baseline"], "evaluated_at": e["evaluated_at"]} if e else {"status": "not evaluated yet (run evaluations once actuals are in)"})})
    outcome = None
    oc = [e for e in ents if e["entry_type"] == "outcome"]
    acts = [e for e in ents if e["entry_type"] == "action"]
    if g["sku"] and oc:
        last = oc[-1]["payload"]
        a, b = date.fromisoformat(last["period_start"]), date.fromisoformat(last["period_end"])
        kt = memory.kt_str(knowledge_time)
        loc = g["location"]
        dem = c.execute("SELECT SUM(quantity) FROM demand WHERE org_id=:org AND sku=:sku AND day BETWEEN :a AND :b%s AND %s"
                        % ("" if loc in (None, "ALL") else " AND location=:loc", memory.known()),
                        {"org": p.org_id, "sku": g["sku"], "a": a.isoformat(), "b": b.isoformat(), "loc": loc, "kt": kt}).fetchone()[0]
        so = [d for d in memory.stockout_weeks(store, p.org_id, g["sku"], loc, kt) if a <= d <= b]
        end = memory.inventory_position(store, p.org_id, g["sku"], loc, b, kt)
        observed = {"recorded_sales": dem, "weeks_with_zero_stock_snapshot": len(so),
                    "ending_stock": end[1] if end else None, "ending_stock_day": end[0].isoformat() if end else None,
                    "entered_values": last["values"]}
        obj = opened.get("objective")
        met, why = None, "no objective was stated when the decision was opened"
        if obj:
            m, t = obj["metric"], obj["target"]
            val = {"no_stockout_weeks": len(so), "max_ending_stock": end[1] if end else None,
                   "min_fill_rate": last["values"].get("fill_rate"), "max_units_ordered": sum(x["payload"].get("quantity", 0) for x in acts)}.get(m)
            if val is None:
                why = "the data needed for %s is not available; enter it in the outcome values" % m
            else:
                met = (val <= t) if m in ("no_stockout_weeks", "max_ending_stock", "max_units_ordered") else (val >= t)
                why = "%s observed %s vs target %s" % (m, round(val, 3), t)
        outcome = {"period": [a.isoformat(), b.isoformat()], "observed": observed, "objective": obj, "objective_met": met, "explanation": why,
                   "action_matched_decision": all(x["payload"].get("matches_decision", True) for x in acts)}
    return {"decision_id": did, "state": g["state"], "forecast_quality": fq, "decision_outcome": outcome or {"status": "no outcome recorded yet"},
            "integrity": verify(store, p, did),
            "caution": "Forecast accuracy and decision outcome are measured separately. An observed outcome is not proof that the decision caused it; "
                       "that needs a comparison against what would have happened otherwise."}
