"""Ingestion: validate a file, map its columns to the canonical model, preview, then commit idempotently.

Rules that matter for trust
- Nothing is stored until a preview has been reviewed and the import is committed.
- Invalid rows are rejected with a reason. They are never coerced into plausible values.
- Ambiguous mappings and ambiguous date formats stop the import and ask for a decision.
- Columns that are not mapped are never stored (data minimisation). If they look personal, the report says so.
- Re-importing the same records changes nothing. A record whose content changed is a correction: the old row is kept,
  marked superseded at the time of the correction, and the new row is added. History is never overwritten.
- A commit is one transaction. If it fails part-way, nothing from it is kept and it can be retried.
"""
from __future__ import annotations
import csv, hashlib, io, json, math, os, re, shutil, tempfile
from datetime import date, datetime, timedelta
from .db import dumps, new_id, ts, utcnow
from .errors import Conflict, Invalid, NotFound, TooLarge
from .tenancy import require
from . import audit

MAX_BYTES = 512 * 1024 * 1024
MAX_ROWS = 20_000_000
EXAMPLES = 5

SPEC = {
    "sales": {"table": "demand", "required": ["date", "sku", "quantity"], "optional": ["location", "record_id", "category", "unit"]},
    "inventory": {"table": "inventory", "required": ["date", "sku", "on_hand"], "optional": ["location", "record_id"]},
    "purchase_orders": {"table": "purchase_orders", "required": ["po_number", "sku", "order_date", "quantity"],
                        "optional": ["expected_date", "received_date", "supplier", "location", "unit_cost", "line_id"]},
    "events": {"table": "events", "required": ["event_type", "start_date"], "optional": ["end_date", "sku", "location", "description", "record_id"]},
}
DATE_FIELDS = {"date", "order_date", "expected_date", "received_date", "start_date", "end_date"}
NUM_FIELDS = {"quantity", "on_hand", "unit_cost"}

SYNONYMS = {
    "date": ["date", "day", "month", "period", "order_date", "invoice_date", "transaction_date", "sales_date", "posting_date", "ship_date", "snapshot_date", "as_of", "ds"],
    "sku": ["sku", "product", "product_id", "item", "item_id", "item_number", "material", "material_number", "part", "part_number", "article"],
    "quantity": ["quantity", "qty", "units", "units_sold", "quantity_sold", "order_qty", "shipped_qty", "volume", "demand", "sales_qty", "ordered_qty"],
    "on_hand": ["on_hand", "on_hand_qty", "stock", "stock_on_hand", "inventory", "available", "qty_on_hand", "soh"],
    "location": ["location", "warehouse", "site", "store", "plant", "dc", "branch", "location_id", "warehouse_id"],
    "record_id": ["record_id", "transaction_id", "txn_id", "order_line_id", "line_id", "invoice_line", "id", "event_id"],
    "category": ["category", "product_category", "product_group", "family", "segment"],
    "unit": ["unit", "uom", "unit_of_measure"],
    "po_number": ["po_number", "po", "po_id", "purchase_order", "order_number"],
    "order_date": ["order_date", "po_date", "created_date"],
    "expected_date": ["expected_date", "promised_date", "due_date", "eta"],
    "received_date": ["received_date", "receipt_date", "delivery_date", "delivered_date", "goods_receipt_date"],
    "supplier": ["supplier", "vendor", "supplier_id", "vendor_id"],
    "unit_cost": ["unit_cost", "cost", "unit_price", "price"],
    "line_id": ["line_id", "line", "po_line", "line_number"],
    "event_type": ["event_type", "type", "event", "kind"],
    "start_date": ["start_date", "start", "from", "date"],
    "end_date": ["end_date", "end", "to"],
    "description": ["description", "notes", "comment"],
}
DATE_FORMATS = ["%Y-%m-%d", "%d/%m/%Y", "%m/%d/%Y", "%d-%m-%Y", "%m-%d-%Y", "%Y/%m/%d", "%d.%m.%Y", "%Y%m%d"]
PERSONAL_HEADER = re.compile(r"(e-?mail|phone|mobile|first.?name|last.?name|full.?name|^name$|customer.?name|contact|address|street|postcode|zip|ssn|passport|dob|birth|card|iban|account.?number|tax.?id|aadhaar|pan)", re.I)
EMAIL = re.compile(r"[^@\s,;]+@[^@\s,;]+\.[A-Za-z]{2,}")


def norm(h):
    return "_".join(re.sub(r"[^0-9a-z]+", " ", (h or "").strip().lower()).split())


# ---------- file handling ----------

def stage_bytes(store, data: bytes, name="upload.csv"):
    if len(data) > MAX_BYTES:
        raise TooLarge("file is larger than %d MB" % (MAX_BYTES // 2**20))
    d = _staging_dir(store)
    fd, path = tempfile.mkstemp(dir=d, suffix=".csv")
    with os.fdopen(fd, "wb") as f:
        f.write(data)
    return path


def stage_stream(store, stream, length):
    if length > MAX_BYTES:
        raise TooLarge("file is larger than %d MB" % (MAX_BYTES // 2**20))
    d = _staging_dir(store)
    fd, path = tempfile.mkstemp(dir=d, suffix=".csv")
    left = length
    with os.fdopen(fd, "wb") as f:
        while left > 0:
            chunk = stream.read(min(1 << 20, left))
            if not chunk:
                break
            f.write(chunk); left -= len(chunk)
    if left:
        os.unlink(path)
        raise Invalid("upload ended early: received %d of %d bytes" % (length - left, length))
    return path


def _staging_dir(store):
    base = store.data_dir or tempfile.gettempdir()
    d = os.path.join(base, "udgass-staging")
    os.makedirs(d, mode=0o700, exist_ok=True)
    return d


def _sha(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for b in iter(lambda: f.read(1 << 20), b""):
            h.update(b)
    return h.hexdigest()


def _sniff(path):
    with open(path, "rb") as f:
        head = f.read(65536)
    if not head.strip():
        raise Invalid("the file is empty")
    if head[:4] == b"PK\x03\x04":
        raise Invalid("this looks like a spreadsheet or archive (.xlsx/.zip). Export the sheet as CSV (UTF-8). Spreadsheet macros are never run.")
    if b"\x00" in head:
        raise Invalid("this looks like a binary file, not CSV text")
    try:
        text = head.decode("utf-8-sig")
    except UnicodeDecodeError as e:
        if e.start < len(head) - 4:
            raise Invalid("the file is not UTF-8 text. Export as CSV UTF-8.")
        text = head[:e.start].decode("utf-8-sig")
    first = text.splitlines()[0] if text.splitlines() else ""
    delim = max(",;\t|", key=first.count)
    return delim if first.count(delim) else ","


def _reader(path, delim):
    f = open(path, newline="", encoding="utf-8-sig")
    return f, csv.reader(f, delimiter=delim)


# ---------- mapping ----------

def suggest_mapping(kind, header, given=None):
    spec = SPEC[kind]
    fields = spec["required"] + spec["optional"]
    given = dict(given or {})
    nh = {norm(h): h for h in header}
    bad = [f for f in given if f not in fields]
    if bad:
        raise Invalid("unknown field(s) for %s: %s. Valid: %s" % (kind, ", ".join(bad), ", ".join(fields)))
    for f, col in given.items():
        if col is not None and col not in header:
            raise Invalid("column %r (for %s) is not in the file. Columns: %s" % (col, f, ", ".join(header)))
    mapping, ambiguous = {}, {}
    used = {c for c in given.values() if c}
    for f in fields:
        if f in given:
            if given[f]:
                mapping[f] = given[f]
            continue
        cands = [nh[n] for n in SYNONYMS.get(f, [f]) if n in nh and nh[n] not in used]
        # an exact field-name match wins; otherwise more than one candidate is ambiguous
        exact = [c for c in cands if norm(c) == f]
        if exact:
            mapping[f] = exact[0]
        elif len(cands) == 1:
            mapping[f] = cands[0]
        elif len(cands) > 1:
            ambiguous[f] = cands
    # one column must not feed two fields
    seen = {}
    for f, col in list(mapping.items()):
        if col in seen and f not in given:
            ambiguous.setdefault(f, [col]); del mapping[f]
        else:
            seen[col] = f
    missing = [f for f in spec["required"] if f not in mapping and f not in ambiguous]
    return mapping, ambiguous, missing


def detect_date_format(values):
    """Pick the format that reads the most sample values (at least 80%). Two formats that read equally many values
    but give different dates (03/04 vs 04/03) are ambiguous and need a decision."""
    vals = sorted({v.strip() for v in values if v and v.strip()})[:2000]
    if not vals:
        return None, []
    scored = []
    for fmt in DATE_FORMATS:
        parsed = {}
        for v in vals:
            d, err = parse_day(v, fmt)
            if not err:
                parsed[v] = d
        if parsed:
            scored.append((len(parsed), fmt, parsed))
    if not scored:
        return None, []
    best = max(n for n, _, _ in scored)
    if best < 0.8 * len(vals):
        return None, [f for _, f, _ in scored]
    top = [(f, p) for n, f, p in scored if n == best]
    if all(p == top[0][1] for _, p in top[1:]):
        return top[0][0], [f for f, _ in top]
    return None, [f for f, _ in top]


# ---------- parsing ----------

_NUM = re.compile(r"^-?\d+(\.\d+)?$")
_THOUS = re.compile(r"^-?\d{1,3}(,\d{3})+(\.\d+)?$")
_DCOMMA = re.compile(r"^-?\d+,\d+$")
_EURO = re.compile(r"^-?\d{1,3}(\.\d{3})+(,\d+)?$")


def parse_number(s, decimal_comma=False):
    s = (s or "").strip().replace(" ", "").replace(" ", "")
    if not s:
        return None, "missing"
    if _NUM.match(s):
        v = float(s)
    elif decimal_comma and _DCOMMA.match(s):
        v = float(s.replace(",", "."))
    elif decimal_comma and _EURO.match(s):
        v = float(s.replace(".", "").replace(",", "."))
    elif not decimal_comma and _THOUS.match(s):
        v = float(s.replace(",", ""))
    else:
        return None, "unreadable number"
    if not math.isfinite(v):
        return None, "unreadable number"
    return v, None


def parse_day(s, fmt):
    s = (s or "").strip()
    if not s:
        return None, "missing"
    try:
        if fmt == "%Y-%m-%d" and "T" in s:
            s = s[:10]
        return datetime.strptime(s, fmt).date(), None
    except ValueError:
        return None, "unreadable date"


def _validate(kind, rec, today, opts=None):
    """Business and temporal rules. Returns a reason string or None."""
    lo = date(1990, 1, 1)
    for f in DATE_FIELDS & rec.keys():
        d = rec[f]
        if d is None:
            continue
        if d > today and f not in ("expected_date", "end_date", "start_date"):      # promised dates and planned events may lie ahead
            return "%s is in the future" % f
        if d < lo:
            return "%s is before 1990" % f
    if kind == "sales" and rec["quantity"] < 0 and (opts or {}).get("returns") != "net":
        return "negative quantity (returns; commit with returns=net to subtract them from the day's sales)"
    if kind == "inventory" and rec["on_hand"] < 0:
        return "negative on-hand stock"
    if kind == "purchase_orders":
        if rec["quantity"] <= 0:
            return "order quantity must be positive"
        if rec.get("received_date") and rec["received_date"] < rec["order_date"]:
            return "received before ordered"
        if rec.get("unit_cost") is not None and rec["unit_cost"] < 0:
            return "negative unit cost"
    if kind == "events":
        if rec.get("end_date") and rec["end_date"] < rec["start_date"]:
            return "event ends before it starts"
    return None


def _key(kind, r):
    loc = r.get("location") or "ALL"
    if kind == "sales":
        return ("id:" + r["record_id"]) if r.get("record_id") else "agg:%s|%s|%s" % (r["sku"], loc, r["date"])
    if kind == "inventory":
        return ("id:" + r["record_id"]) if r.get("record_id") else "%s|%s|%s" % (r["sku"], loc, r["date"])
    if kind == "purchase_orders":
        return "%s|%s" % (r["po_number"], r["line_id"]) if r.get("line_id") else "%s|%s|%s" % (r["po_number"], r["sku"], loc)
    return ("id:" + r["record_id"]) if r.get("record_id") else "%s|%s|%s|%s" % (r["event_type"], r.get("sku") or "", loc, r["start_date"])


def _canonical(kind, r):
    """The stored content of a record (what its hash covers)."""
    loc = r.get("location") or "ALL"
    if kind == "sales":
        return {"sku": r["sku"], "location": loc, "day": r["date"].isoformat(), "quantity": r["quantity"]}
    if kind == "inventory":
        return {"sku": r["sku"], "location": loc, "day": r["date"].isoformat(), "on_hand": r["on_hand"]}
    if kind == "purchase_orders":
        d = lambda x: x.isoformat() if x else None
        return {"po_number": r["po_number"], "sku": r["sku"], "location": loc, "supplier": r.get("supplier") or None,
                "order_day": d(r["order_date"]), "expected_day": d(r.get("expected_date")), "received_day": d(r.get("received_date")),
                "quantity": r["quantity"], "unit_cost": r.get("unit_cost")}
    end = r.get("end_date") or r["start_date"]
    return {"event_type": r["event_type"].lower(), "sku": r.get("sku") or None, "location": r.get("location") or None,
            "start_day": r["start_date"].isoformat(), "end_day": end.isoformat(), "description": (r.get("description") or "")[:500] or None}


def _rhash(content):
    return hashlib.sha256(dumps(content).encode()).hexdigest()


class _Bucket:
    def __init__(self):
        self.counts, self.examples = {}, {}

    def add(self, reason, rownum, raw=None):
        self.counts[reason] = self.counts.get(reason, 0) + 1
        ex = self.examples.setdefault(reason, [])
        if len(ex) < EXAMPLES:
            ex.append({"row": rownum, **({"value": raw} if raw is not None else {})})

    def out(self):
        return [{"reason": k, "rows": v, "examples": self.examples[k]} for k, v in sorted(self.counts.items(), key=lambda kv: -kv[1])]


def _scan(path, delim, kind, mapping, fmts, opts, today):
    """One streaming pass: parse, validate, build canonical records keyed by record key. Returns (records, report)."""
    rej, warn = _Bucket(), _Bucket()
    records = {}          # key -> (content, first_row, n_rows)
    rows = 0; exact_dupes = 0; merged = 0; seen_lines = set(); days = set()
    agg = kind == "sales" and "record_id" not in mapping
    conflicts = set()
    dmin = dmax = None
    text_fields = [f for f in mapping if f not in DATE_FIELDS and f not in NUM_FIELDS]
    f, rd = _reader(path, delim)
    try:
        header = next(rd)
        idx = {fld: header.index(col) for fld, col in mapping.items()}
        for i, row in enumerate(rd, start=2):
            if not any(c.strip() for c in row):
                continue
            rows += 1
            if rows > MAX_ROWS:
                raise TooLarge("more than %d rows; split the export" % MAX_ROWS)
            if len(row) != len(header):
                rej.add("wrong number of columns (%d, header has %d)" % (len(row), len(header)), i); continue
            lh = hash(tuple(row))
            if lh in seen_lines:
                exact_dupes += 1
                if opts.get("duplicate_rows") == "drop":
                    warn.add("identical row dropped (duplicate_rows=drop)", i); continue
            elif len(seen_lines) < 5_000_000:
                seen_lines.add(lh)
            rec, bad = {}, None
            for fld, j in idx.items():
                v = row[j]
                if fld in DATE_FIELDS:
                    if not v.strip() and fld not in SPEC[kind]["required"]:
                        rec[fld] = None; continue
                    d, err = parse_day(v, fmts[fld])
                    if err:
                        bad = ("%s: %s" % (fld, err), v[:40]); break
                    rec[fld] = d
                elif fld in NUM_FIELDS:
                    if not v.strip() and fld not in SPEC[kind]["required"]:
                        rec[fld] = None; continue
                    n, err = parse_number(v, opts.get("decimal_comma", False))
                    if err:
                        bad = ("%s: %s" % (fld, err), v[:40]); break
                    rec[fld] = n
                else:
                    v = v.strip()
                    if not v and fld in SPEC[kind]["required"]:
                        bad = ("%s: missing" % fld, None); break
                    if len(v) > 200:
                        bad = ("%s: longer than 200 characters" % fld, v[:40]); break
                    rec[fld] = v
            if bad:
                rej.add(bad[0], i, bad[1]); continue
            reason = _validate(kind, rec, today, opts)
            if reason:
                rej.add(reason, i); continue
            for tf in text_fields:
                if rec.get(tf) and EMAIL.search(rec[tf]):
                    warn.add("%s contains an email address (it will be stored)" % tf, i)
            d0 = rec.get("date") or rec.get("order_date") or rec.get("start_date")
            if len(days) < 100000:
                days.add(d0)
            dmin = d0 if dmin is None or d0 < dmin else dmin
            dmax = d0 if dmax is None or d0 > dmax else dmax
            k = _key(kind, rec)
            content = _canonical(kind, rec)
            if k in records:
                prev, r0, n, ex0 = records[k]
                if agg:
                    prev = dict(prev, quantity=prev["quantity"] + content["quantity"])
                    records[k] = (prev, r0, n + 1, ex0)
                    merged += 1
                elif prev == content:
                    warn.add("same record repeated in the file (kept once)", i)
                else:
                    conflicts.add(k); rej.add("conflicting values for the same record (also row %d)" % r0, i)
                continue
            extra = {"category": rec.get("category"), "unit": rec.get("unit")} if kind == "sales" else {}
            records[k] = (content, i, 1, extra)
    finally:
        f.close()
    for k in conflicts:                      # every row of a conflicting record is rejected, not just the later ones
        r0 = records.pop(k)[1]
        rej.add("conflicting values for the same record", r0)
    if exact_dupes and opts.get("duplicate_rows") != "drop":
        warn.add("%d rows are identical to an earlier row. Without a record id they are counted as separate sales. "
                 "If they are export duplicates, commit with duplicate_rows=drop." % exact_dupes, 0)
    gran = granularity(days)
    rep = {"granularity": gran,
           "rows_read": rows, "rows_rejected": sum(rej.counts.values()), "records": len(records),
           "rows_aggregated": merged,
           "rejected": rej.out(), "warnings": warn.out(), "identical_rows": exact_dupes,
           "first_day": dmin.isoformat() if dmin else None, "last_day": dmax.isoformat() if dmax else None}
    if agg:
        rep["assumption"] = ("No record id is mapped, so rows are added up per product, location and day, and this file is treated as "
                             "the complete total for each product, location and day it contains. Re-importing a day replaces its total.")
    return records, rep


def granularity(days):
    """daily, weekly, monthly or irregular, from the distinct dates in the file."""
    ds = sorted(days)
    if len(ds) < 3:
        return "too_few_dates"
    gaps = sorted((b - a).days for a, b in zip(ds, ds[1:]))
    med = gaps[len(gaps) // 2]
    if med >= 27 and sum(d.day == ds[0].day for d in ds) >= 0.8 * len(ds):
        return "monthly"
    if med == 7 and len({d.weekday() for d in ds}) == 1:
        return "weekly"
    if med <= 2:
        return "daily"
    return "irregular"


def _ignored_columns(path, delim, header, mapping):
    used = set(mapping.values())
    out = []
    for col in header:
        if col in used:
            continue
        flag = bool(PERSONAL_HEADER.search(col))
        out.append({"column": col, "looks_personal": flag})
    # value check on ignored columns, first 300 rows
    f, rd = _reader(path, delim)
    try:
        next(rd)
        for i, row in enumerate(rd):
            if i >= 300:
                break
            for o in out:
                j = header.index(o["column"])
                if j < len(row) and EMAIL.search(row[j] or ""):
                    o["looks_personal"] = True
    finally:
        f.close()
    return out


def _compare_existing(c, kind, org, source_id, records):
    t = SPEC[kind]["table"]
    new = dup = corr = 0
    keys = list(records)
    for i in range(0, len(keys), 500):
        part = keys[i:i + 500]
        cur = {r["record_key"]: r["row_hash"] for r in c.execute(
            "SELECT record_key,row_hash FROM %s WHERE org_id=? AND source_id=? AND superseded_at IS NULL AND record_key IN (%s)"
            % (t, ",".join("?" * len(part))), [org, source_id] + part)}
        for k in part:
            h = _rhash(records[k][0])
            if k not in cur:
                new += 1
            elif cur[k] == h:
                dup += 1
            else:
                corr += 1
    return {"new": new, "already_present": dup, "corrections": corr}


def _source(c, org, name, kind, create):
    name = (name or "").strip()
    if not 1 <= len(name) <= 80 or not re.match(r"^[\w .:/-]+$", name):
        raise Invalid("source name must be 1 to 80 letters, digits, spaces or . _ : / -")
    r = c.execute("SELECT id, kind FROM data_sources WHERE org_id=? AND name=?", (org, name)).fetchone()
    if r:
        return r["id"]
    if not create:
        return None
    sid = new_id("src")
    c.execute("INSERT INTO data_sources VALUES(?,?,?,?,?)", (sid, org, name, kind, ts()))
    return sid


def _analyse(store, p, kind, source_name, path, mapping_in, date_format, opts, now):
    delim = _sniff(path)
    f, rd = _reader(path, delim)
    try:
        header = next(rd, None)
    finally:
        f.close()
    if not header or not any(h.strip() for h in header):
        raise Invalid("the file has no header row")
    dupes = sorted({norm(h) for h in header if [norm(x) for x in header].count(norm(h)) > 1})
    if dupes:
        raise Invalid("duplicate column names: %s" % ", ".join(dupes))
    mapping, ambiguous, missing = suggest_mapping(kind, header, mapping_in)
    fmts, fmt_issues = {}, {}
    for fld in DATE_FIELDS & set(mapping):
        if date_format:
            fmts[fld] = date_format; continue
        j = header.index(mapping[fld])
        f, rd = _reader(path, delim)
        try:
            next(rd)
            vals = [row[j] for _, row in zip(range(2000), rd) if j < len(row)]
        finally:
            f.close()
        fmt, cands = detect_date_format(vals)
        if fmt:
            fmts[fld] = fmt
        else:
            fmt_issues[fld] = {"candidates": cands, "message": "ambiguous date format; pass date_format" if cands else "no supported date format matched"}
    ready = not ambiguous and not missing and not fmt_issues
    report = {"columns": header, "delimiter": delim, "mapping": mapping, "ambiguous": ambiguous, "missing_required": missing,
              "date_formats": fmts, "date_format_issues": fmt_issues, "ready": ready}
    records = None
    if ready:
        today = (now or utcnow()).date()
        records, rep = _scan(path, delim, kind, mapping, fmts, opts, today)
        report.update(rep)
        report["ignored_columns"] = _ignored_columns(path, delim, header, mapping)
        if any(o["looks_personal"] for o in report["ignored_columns"]):
            report["personal_data_notice"] = "Some ignored columns look personal. They are not stored. Leaving them out of the export is better."
        c = store.conn()
        sid = _source(c, p.org_id, source_name, kind, create=False)
        report["compared_with_stored"] = _compare_existing(c, kind, p.org_id, sid, records) if sid else {
            "new": len(records), "already_present": 0, "corrections": 0}
        if not records:
            report["ready"] = False
            report["blocking"] = "no valid records"
        elif kind == "sales" and report.get("granularity") == "monthly":
            report["ready"] = False
            report["blocking"] = ("The dates look monthly (one date per month). Udgass analyses weekly demand, so monthly totals would look like "
                                  "one large week followed by empty weeks. Export daily or weekly sales instead.")
    return report, records


def preview(store, p, kind, source_name, path, file_name="upload.csv", mapping=None, date_format=None, options=None,
            request_id=None, now=None):
    """Validate and analyse a staged file. Stores nothing but the import record and the staged file."""
    require(p, "analyst")
    if kind not in SPEC:
        raise Invalid("kind must be one of %s" % ", ".join(SPEC))
    if date_format and date_format not in DATE_FORMATS:
        raise Invalid("date_format must be one of %s" % ", ".join(DATE_FORMATS))
    opts = {"duplicate_rows": (options or {}).get("duplicate_rows", "keep"), "decimal_comma": bool((options or {}).get("decimal_comma")),
            "returns": (options or {}).get("returns", "reject")}
    if opts["duplicate_rows"] not in ("keep", "drop"):
        raise Invalid("duplicate_rows must be keep or drop")
    if opts["returns"] not in ("reject", "net"):
        raise Invalid("returns must be reject or net")
    _source(store.conn(), p.org_id, source_name, kind, create=False)    # validates the name
    report, records = _analyse(store, p, kind, source_name, path, mapping, date_format, opts, now)
    iid = new_id("imp")
    final = os.path.join(_staging_dir(store), iid + ".csv")
    if os.path.dirname(os.path.abspath(path)) == _staging_dir(store):
        os.replace(path, final)               # our own staged upload
    else:
        shutil.copyfile(path, final)          # a caller's file: copy it, never move or change it
    with store.tx() as c:
        c.execute("INSERT INTO imports(id,org_id,source_name,dataset_kind,file_name,file_sha256,file_bytes,mapping_json,options_json,status,report_json,created_at,created_by) "
                  "VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)",
                  (iid, p.org_id, source_name, kind, (file_name or "")[:200], _sha(final), os.path.getsize(final),
                   dumps({"mapping": report["mapping"], "date_format": date_format}), dumps(opts), "previewed", dumps(report), ts(now), p.actor))
        audit.record(c, p.org_id, p.actor, "import.preview", "import", iid, request_id, {"kind": kind, "source": source_name, "ready": report["ready"]})
    sample = []
    if records:
        for k in list(records)[:5]:
            sample.append({"record_key": k, **records[k][0]})
    return {"import_id": iid, "status": "previewed", "kind": kind, "source": source_name, "ready": report["ready"],
            "report": report, "sample": sample}


def commit(store, p, import_id, mapping=None, date_format=None, options=None, request_id=None, now=None, _fail_after=None):
    """Persist a previewed import in one transaction. Safe to retry. Re-importing identical records is a no-op."""
    require(p, "analyst")
    c = store.conn()
    imp = c.execute("SELECT * FROM imports WHERE id=? AND org_id=?", (import_id, p.org_id)).fetchone()
    if imp is None:
        raise NotFound("no import %s in this organisation" % import_id)
    if imp["status"] == "committed":
        return {"import_id": import_id, "status": "committed", "already_committed": True, "report": json.loads(imp["report_json"])}
    if imp["status"] != "previewed":
        raise Conflict("import is %s and cannot be committed" % imp["status"])
    path = os.path.join(_staging_dir(store), import_id + ".csv")
    if not os.path.exists(path):
        raise Conflict("the staged file is gone (previews expire). Upload it again.")
    if _sha(path) != imp["file_sha256"]:
        raise Conflict("the staged file changed after preview. Upload it again.")
    stored = json.loads(imp["mapping_json"])
    kind = imp["dataset_kind"]
    opts = json.loads(imp["options_json"])
    opts.update({k: v for k, v in (options or {}).items() if k in ("duplicate_rows", "decimal_comma", "returns")})
    report, records = _analyse(store, p, kind, imp["source_name"], path, mapping or stored["mapping"], date_format or stored.get("date_format"), opts, now)
    if not report["ready"]:
        raise Invalid("import is not ready to commit", details={"ambiguous": report.get("ambiguous"), "missing_required": report.get("missing_required"),
                                                              "date_format_issues": report.get("date_format_issues"), "blocking": report.get("blocking")})
    t = SPEC[kind]["table"]
    at = ts(now)
    counts = {"new": 0, "already_present": 0, "corrections": 0}
    try:
        with store.tx() as c:
            sid = _source(c, p.org_id, imp["source_name"], kind, create=True)
            done = 0
            keys = list(records)
            for i in range(0, len(keys), 500):
                part = keys[i:i + 500]
                cur = {r["record_key"]: (r["id"], r["row_hash"]) for r in c.execute(
                    "SELECT id,record_key,row_hash FROM %s WHERE org_id=? AND source_id=? AND superseded_at IS NULL AND record_key IN (%s)"
                    % (t, ",".join("?" * len(part))), [p.org_id, sid] + part)}
                for k in part:
                    entry = records[k]
                    content, row = entry[0], entry[1]
                    h = _rhash(content)
                    if k in cur and cur[k][1] == h:
                        counts["already_present"] += 1; continue
                    if k in cur:
                        c.execute("UPDATE %s SET superseded_at=? WHERE id=?" % t, (at, cur[k][0]))
                        counts["corrections"] += 1
                    else:
                        counts["new"] += 1
                    cols = list(content)
                    c.execute("INSERT INTO %s(org_id,source_id,record_key,%s,row_hash,import_id,source_row,recorded_at) VALUES(?,?,?,%s,?,?,?,?)"
                              % (t, ",".join(cols), ",".join("?" * len(cols))),
                              [p.org_id, sid, k] + [content[x] for x in cols] + [h, import_id, row, at])
                    _dims(c, p.org_id, kind, content, entry[3], at)
                    done += 1
                    if _fail_after is not None and done >= _fail_after:
                        raise RuntimeError("injected failure")
            report["committed"] = counts
            c.execute("UPDATE imports SET status='committed', committed_at=?, report_json=?, mapping_json=?, error=NULL WHERE id=?",
                      (at, dumps(report), dumps({"mapping": report["mapping"], "date_format": date_format or stored.get("date_format")}), import_id))
            audit.record(c, p.org_id, p.actor, "import.commit", "import", import_id, request_id, {"kind": kind, **counts})
    except Exception as e:
        with store.tx() as c2:
            c2.execute("UPDATE imports SET error=? WHERE id=?", (str(e)[:300], import_id))
        raise
    try:
        os.unlink(path)          # retention: the raw file is not kept after commit
    except OSError:
        pass
    return {"import_id": import_id, "status": "committed", "counts": counts, "report": report}


def _dims(c, org, kind, content, extra, at):
    if content.get("sku"):
        c.execute("INSERT OR IGNORE INTO products(org_id,sku,created_at) VALUES(?,?,?)", (org, content["sku"], at))
        if extra.get("category") or extra.get("unit"):
            c.execute("UPDATE products SET category=COALESCE(?,category), unit=COALESCE(?,unit) WHERE org_id=? AND sku=?",
                      (extra.get("category"), extra.get("unit"), org, content["sku"]))
    if content.get("location"):
        c.execute("INSERT OR IGNORE INTO locations VALUES(?,?,?)", (org, content["location"], at))
    if content.get("supplier"):
        c.execute("INSERT OR IGNORE INTO suppliers VALUES(?,?,?)", (org, content["supplier"], at))


def expire_previews(store, max_age_hours=24, now=None):
    """Retention for staged files: previews not committed within max_age_hours are expired and their file deleted."""
    cutoff = ts((now or utcnow()) - timedelta(hours=max_age_hours))
    c = store.conn()
    old = [r["id"] for r in c.execute("SELECT id FROM imports WHERE status='previewed' AND created_at < ?", (cutoff,))]
    for iid in old:
        try:
            os.unlink(os.path.join(_staging_dir(store), iid + ".csv"))
        except OSError:
            pass
        with store.tx() as c2:
            c2.execute("UPDATE imports SET status='expired' WHERE id=?", (iid,))
    return len(old)


def get_import(store, p, import_id):
    r = store.conn().execute("SELECT * FROM imports WHERE id=? AND org_id=?", (import_id, p.org_id)).fetchone()
    if r is None:
        raise NotFound("no import %s in this organisation" % import_id)
    d = dict(r)
    d["report"] = json.loads(d.pop("report_json") or "{}")
    d["mapping"] = json.loads(d.pop("mapping_json") or "{}")
    d["options"] = json.loads(d.pop("options_json") or "{}")
    d["source"] = d.pop("source_name")
    return d


def list_imports(store, p, limit=50, cursor=None):
    limit = max(1, min(int(limit), 200))
    q = "SELECT id, dataset_kind, source_name AS source, file_name, status, created_at, committed_at, error FROM imports WHERE org_id=?"
    args = [p.org_id]
    if cursor:
        q += " AND created_at < ?"; args.append(cursor)
    items = [dict(r) for r in store.conn().execute(q + " ORDER BY created_at DESC LIMIT ?", args + [limit])]
    return {"items": items, "next_cursor": items[-1]["created_at"] if len(items) == limit else None}
