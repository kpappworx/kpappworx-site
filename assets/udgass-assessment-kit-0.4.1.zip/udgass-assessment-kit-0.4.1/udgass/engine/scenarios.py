"""Inventory scenarios: what happens to one product's stock under stated assumptions.

A scenario record holds a baseline and any number of named variants (higher demand, a late supplier, less stock than
recorded, higher costs). All are simulated with the same random draws (common random numbers), so differences between
them come from the assumptions, not from simulation noise.

Inputs come from organisational memory as known at the scenario's knowledge time, each with its source: the stored
forecast (path and its measured errors), the latest stock snapshot, open purchase orders, and observed lead times.
Anything missing is listed. Money is only calculated when costs are given or found in purchase orders.

optimise: searches order-up-to levels for the lowest expected cost (or the smallest stock meeting a service target)
under the stated assumptions. That is a mathematical optimum for this model, not a guaranteed real-world one.
Nothing here places or changes an order.
"""
from __future__ import annotations
import json, math, random
from datetime import date, timedelta
from .. import __version__
from ..forecast import internal_errors
from .db import dumps, new_id, ts
from .errors import InsufficientData, Invalid, NotFound
from .tenancy import require
from . import audit, memory

ASSUMPTION_KEYS = {"demand_multiplier": (0.1, 5.0), "lead_time_delay_weeks": (0, 26), "stock_adjustment_pct": (-100, 100),
                   "unit_cost_change_pct": (-90, 500), "lead_time_weeks": (0, 52)}
COST_KEYS = {"unit_cost": (0, 1e9), "holding_rate_per_year": (0, 2), "shortage_cost_per_unit": (0, 1e9), "order_cost": (0, 1e9)}
CONSTRAINT_KEYS = {"min_fill_rate": (0, 1), "max_avg_inventory_value": (0, 1e13)}


def _check(d, spec, what):
    d = dict(d or {})
    for k, v in d.items():
        if k not in spec:
            raise Invalid("unknown %s %r. Allowed: %s" % (what, k, ", ".join(spec)))
        if not isinstance(v, (int, float)) or isinstance(v, bool) or not math.isfinite(v) or not spec[k][0] <= v <= spec[k][1]:
            raise Invalid("%s %s must be a number from %s to %s" % (what, k, spec[k][0], spec[k][1]))
    return d


def _policy(pol):
    pol = dict(pol or {"type": "order_up_to_auto"})
    t = pol.get("type")
    if t == "order_up_to":
        if not isinstance(pol.get("level"), (int, float)) or pol["level"] < 0:
            raise Invalid("order_up_to needs level >= 0")
    elif t == "reorder_point":
        if not all(isinstance(pol.get(k), (int, float)) and pol[k] >= 0 for k in ("reorder_point", "order_qty")) or pol["order_qty"] <= 0:
            raise Invalid("reorder_point needs reorder_point >= 0 and order_qty > 0")
    elif t not in ("order_up_to_auto", "optimise"):
        raise Invalid("policy type must be order_up_to, reorder_point, order_up_to_auto or optimise")
    return pol


def resolve_inputs(store, p, sku, location, forecast_id=None, knowledge_time=None):
    """Gather inputs with provenance. Returns (inputs, missing)."""
    kt = memory.kt_str(knowledge_time)
    c = store.conn()
    if forecast_id:
        f = c.execute("SELECT f.*, r.knowledge_time AS run_kt, r.params_json FROM forecasts f JOIN forecast_runs r ON r.id=f.run_id "
                      "WHERE f.id=? AND f.org_id=?", (forecast_id, p.org_id)).fetchone()
        if not f:
            raise NotFound("no forecast %s in this organisation" % forecast_id)
    else:
        f = c.execute("SELECT f.*, r.knowledge_time AS run_kt, r.params_json FROM forecasts f JOIN forecast_runs r ON r.id=f.run_id "
                      "WHERE f.org_id=? AND f.sku=? AND f.location=? AND r.knowledge_time<=? ORDER BY r.created_at DESC LIMIT 1",
                      (p.org_id, sku, location, kt)).fetchone()
        if not f:
            raise InsufficientData("no stored forecast for %s at %s. Create a forecast run first." % (sku, location))
    if f["sku"] != sku or f["location"] != location:
        raise Invalid("forecast %s is for %s at %s" % (f["id"], f["sku"], f["location"]))
    params = json.loads(f["params_json"])
    by_loc = params["by_location"]
    w = memory.weekly_demand(store, p.org_id, f["run_kt"], date.fromisoformat(params["last_complete_week"]) + timedelta(days=6),
                             [sku], [location] if by_loc else None, by_loc)
    hist = w["series"][(sku, location)]
    errs, _ = internal_errors(hist, f["horizon_weeks"], f["method"])
    missing, sources = [], {}
    origin = date.fromisoformat(f["target_start"])
    snap = memory.inventory_position(store, p.org_id, sku, location if by_loc else None, origin - timedelta(days=1), kt)
    if snap:
        sources["start_stock"] = "stock snapshot of %s (as known at %s UTC)" % (snap[0].isoformat(), kt[:19].replace("T", " "))
        if (origin - snap[0]).days > 14:
            missing.append("latest stock snapshot is %d days before the forecast start" % (origin - snap[0]).days)
    else:
        missing.append("starting stock (no snapshot recorded); pass start_stock")
    pos = memory.purchase_orders(store, p.org_id, sku, location if by_loc else None, kt)
    lts = [l["days"] for l in memory.lead_times_days(pos, origin - timedelta(days=1))
           if l["received_day"] >= (origin - timedelta(weeks=52)).isoformat()]
    if len(lts) < 5:
        sup = next((x["supplier"] for x in reversed(pos) if x["supplier"]), None)
        if sup:
            allpos = memory.purchase_orders(store, p.org_id, None, None, kt)
            lts = [l["days"] for l in memory.lead_times_days([x for x in allpos if x["supplier"] == sup], origin - timedelta(days=1))
                   if l["received_day"] >= (origin - timedelta(weeks=52)).isoformat()]
            sources["lead_time"] = "%d receipts from vendor %s in the 52 weeks before %s" % (len(lts), sup, origin)
    else:
        sources["lead_time"] = "%d receipts of %s in the 52 weeks before %s" % (len(lts), sku, origin)
    if len(lts) < 5:
        missing.append("observed lead times (fewer than 5 receipts); pass lead_time_weeks")
    open_orders = []
    for x in pos:
        # open at the forecast start: ordered before it and not yet received by then. A receipt recorded later is
        # hindsight, so the arrival week comes from the promised date, never from the actual receipt.
        if x["order_day"] < origin.isoformat() and (not x["received_day"] or x["received_day"] >= origin.isoformat()):
            due = date.fromisoformat(x["expected_day"]) if x["expected_day"] else None
            open_orders.append({"po": x["po_number"], "qty": x["quantity"], "expected_day": x["expected_day"],
                                "week": max(0, (due - origin).days // 7) if due else None})
    if any(o["week"] is None for o in open_orders):
        missing.append("expected date for some open orders (assumed to arrive at the median lead time)")
    costs = [x["unit_cost"] for x in pos if x["unit_cost"] is not None]
    unit_cost = sorted(costs)[len(costs) // 2] if costs else None
    if unit_cost is not None:
        sources["unit_cost"] = "median unit price on %d purchase order lines" % len(costs)
    return {"forecast": {"id": f["id"], "run_id": f["run_id"], "point": f["point"], "low": f["low"], "high": f["high"],
                         "weekly": json.loads(f["weekly_json"]), "horizon_weeks": f["horizon_weeks"], "method": f["method"],
                         "target_start": f["target_start"], "knowledge_time": f["run_kt"]},
            "rel_errors": errs, "start_stock": snap[1] if snap else None, "start_stock_day": snap[0].isoformat() if snap else None,
            "lead_time_days": lts, "open_orders": open_orders, "unit_cost": unit_cost, "sources": sources,
            "knowledge_time": kt}, missing


def simulate(inp, assumptions, policy, weeks, runs, seed, start_stock=None):
    """Weekly stock simulation. Demand path = forecast weekly path (repeated mean beyond its horizon) x multiplier x (1+e),
    e resampled from the forecast method's own past window errors, one draw per forecast-horizon block."""
    a = assumptions
    path = list(inp["forecast"]["weekly"])
    mean = sum(path) / len(path)
    path = (path + [mean] * weeks)[:weeks]
    mult = a.get("demand_multiplier", 1.0)
    block = inp["forecast"]["horizon_weeks"]
    errs = inp["rel_errors"] or [0.0]
    if a.get("lead_time_weeks") is not None:
        lead_pool = [int(a["lead_time_weeks"])]
    else:
        lead_pool = [max(0, math.ceil(d / 7)) for d in inp["lead_time_days"]] or [2]
    delay = int(a.get("lead_time_delay_weeks", 0))
    s0 = start_stock if start_stock is not None else (inp["start_stock"] or 0.0)
    s0 = max(0.0, s0 * (1 + a.get("stock_adjustment_pct", 0) / 100.0))
    med_lead = sorted(lead_pool)[len(lead_pool) // 2]
    sched = {}
    for o in inp["open_orders"]:
        wk = (o["week"] if o["week"] is not None else med_lead) + delay
        sched[wk] = sched.get(wk, 0.0) + o["qty"]
    S = policy.get("level")
    per_run_fill, short_any = [], 0
    tot = {"demand": 0.0, "served": 0.0, "short": 0.0, "stock": 0.0, "end": 0.0, "ordered": 0.0, "orders": 0}
    for r in range(runs):
        rnd = random.Random(seed * 1_000_003 + r)       # same draws for every scenario: common random numbers
        stock, pipe = s0, dict(sched)
        d_run = s_run = 0.0
        e = 0.0
        hit = False
        for wk in range(weeks):
            if wk % block == 0:
                e = errs[rnd.randrange(len(errs))]
            lt_draw = lead_pool[rnd.randrange(len(lead_pool))]
            stock += pipe.pop(wk, 0.0)
            d = max(0.0, path[wk] * mult * (1 + e))
            s = min(stock, d)
            stock -= s
            d_run += d; s_run += s
            if d - s > 1e-9:
                hit = True
            tot["stock"] += stock
            position = stock + sum(pipe.values())
            q = 0.0
            if policy["type"] == "order_up_to" and position < S:
                q = S - position
            elif policy["type"] == "reorder_point" and position <= policy["reorder_point"]:
                q = policy["order_qty"]
            if q > 0:
                arr = wk + 1 + lt_draw + delay
                pipe[arr] = pipe.get(arr, 0.0) + q
                tot["ordered"] += q; tot["orders"] += 1
        tot["demand"] += d_run; tot["served"] += s_run; tot["short"] += d_run - s_run; tot["end"] += stock
        per_run_fill.append(s_run / d_run if d_run > 0 else 1.0)
        short_any += hit
    n = runs
    fills = sorted(per_run_fill)
    mf = sum(fills) / n
    sd = math.sqrt(sum((x - mf) ** 2 for x in fills) / max(n - 1, 1))
    next4 = sum(path[:4]) * mult
    return {"expected_demand": tot["demand"] / n, "fill_rate": tot["served"] / tot["demand"] if tot["demand"] else 1.0,
            "fill_rate_p05_p95": [fills[int(0.05 * (n - 1))], fills[int(0.95 * (n - 1))]], "fill_rate_mc_standard_error": sd / math.sqrt(n),
            "expected_shortage_units": tot["short"] / n, "probability_of_any_shortage": short_any / n,
            "avg_on_hand": tot["stock"] / (n * weeks), "expected_ending_stock": tot["end"] / n,
            "expected_excess_at_end": max(0.0, tot["end"] / n - next4), "expected_units_ordered": tot["ordered"] / n,
            "expected_orders": tot["orders"] / n, "start_stock_used": s0, "median_lead_time_weeks": med_lead + delay}


def _money(res, costs, assumptions, weeks):
    uc = costs.get("unit_cost")
    if uc is None:
        return None, ["unit cost"]
    uc = uc * (1 + assumptions.get("unit_cost_change_pct", 0) / 100.0)
    out = {"unit_cost_used": uc, "avg_inventory_value": res["avg_on_hand"] * uc, "purchase_value": res["expected_units_ordered"] * uc}
    missing = []
    if "holding_rate_per_year" in costs:
        out["holding_cost"] = res["avg_on_hand"] * uc * costs["holding_rate_per_year"] * weeks / 52
    else:
        missing.append("holding_rate_per_year")
    if "shortage_cost_per_unit" in costs:
        out["shortage_cost"] = res["expected_shortage_units"] * costs["shortage_cost_per_unit"]
    else:
        missing.append("shortage_cost_per_unit")
    if "order_cost" in costs:
        out["ordering_cost"] = res["expected_orders"] * costs["order_cost"]
    else:
        missing.append("order_cost")
    if not missing:
        out["total_relevant_cost"] = out["holding_cost"] + out["shortage_cost"] + out["ordering_cost"]
    return out, missing


def _constraints(res, money, cons):
    out = []
    if "min_fill_rate" in cons:
        out.append({"constraint": "min_fill_rate", "target": cons["min_fill_rate"], "value": res["fill_rate"], "met": res["fill_rate"] >= cons["min_fill_rate"]})
    if "max_avg_inventory_value" in cons:
        v = money["avg_inventory_value"] if money else None
        out.append({"constraint": "max_avg_inventory_value", "target": cons["max_avg_inventory_value"], "value": v,
                    "met": (v <= cons["max_avg_inventory_value"]) if v is not None else None,
                    **({"note": "cannot check without a unit cost"} if v is None else {})})
    return out


def _auto_level(inp, assumptions):
    path = inp["forecast"]["weekly"]
    rate = sum(path) / len(path) * assumptions.get("demand_multiplier", 1.0)
    lt = assumptions.get("lead_time_weeks")
    if lt is None:
        pool = [math.ceil(d / 7) for d in inp["lead_time_days"]] or [2]
        lt = sorted(pool)[len(pool) // 2]
    return rate * (lt + assumptions.get("lead_time_delay_weeks", 0) + 1 + 1)       # lead time + review week + one week of safety


def _optimise(inp, a, costs, cons, weeks, runs, seed, start_stock):
    base = max(_auto_level(inp, a), 1.0)
    grid = [base * f for f in [0.4 + 0.15 * i for i in range(25)]]
    table = []
    for S in grid:
        r = simulate(inp, a, {"type": "order_up_to", "level": S}, weeks, max(200, runs // 4), seed, start_stock)
        m, _ = _money(r, costs, a, weeks)
        table.append({"level": S, "fill_rate": r["fill_rate"], "avg_on_hand": r["avg_on_hand"],
                      "avg_inventory_value": m["avg_inventory_value"] if m else None, "total_relevant_cost": (m or {}).get("total_relevant_cost")})
    feas = [t for t in table if all(c["met"] is not False for c in _constraints(t, {"avg_inventory_value": t["avg_inventory_value"]} if t["avg_inventory_value"] is not None else None, cons))]
    if all(t["total_relevant_cost"] is not None for t in table):
        objective = "lowest expected holding + shortage + ordering cost"
        best = min(feas, key=lambda t: t["total_relevant_cost"]) if feas else None
    elif "min_fill_rate" in cons:
        objective = "smallest order-up-to level meeting the fill-rate target"
        best = min(feas, key=lambda t: t["level"]) if feas else None
    else:
        raise Invalid("optimise needs either full costs (unit_cost, holding_rate_per_year, shortage_cost_per_unit, order_cost) or constraints.min_fill_rate")
    return best, table, objective


def create(store, p, sku, location, name="scenario", forecast_id=None, weeks=13, runs=1000, seed=1, policy=None, costs=None,
           constraints=None, variants=None, start_stock=None, knowledge_time=None, request_id=None, now=None):
    require(p, "analyst")
    if not 4 <= int(weeks) <= 52 or not 100 <= int(runs) <= 20000:
        raise Invalid("weeks 4-52, runs 100-20000")
    weeks, runs, seed = int(weeks), int(runs), int(seed)
    pol = _policy(policy)
    costs = _check(costs, COST_KEYS, "cost")
    cons = _check(constraints, CONSTRAINT_KEYS, "constraint")
    vs = [{"name": "baseline", "assumptions": {}}]
    for v in (variants or []):
        if not isinstance(v, dict) or not str(v.get("name", "")).strip():
            raise Invalid("each variant needs a name and assumptions")
        vs.append({"name": str(v["name"])[:80], "assumptions": _check(v.get("assumptions"), ASSUMPTION_KEYS, "assumption")})
    if len(vs) > 8:
        raise Invalid("at most 7 variants")
    if start_stock is not None and (not isinstance(start_stock, (int, float)) or start_stock < 0):
        raise Invalid("start_stock must be >= 0")
    inp, missing = resolve_inputs(store, p, sku, location, forecast_id, knowledge_time or now)
    if inp["start_stock"] is None and start_stock is None:
        raise InsufficientData("starting stock is unknown: no snapshot recorded for this product. Pass start_stock.", details={"missing": missing})
    if start_stock is not None:
        inp["sources"]["start_stock"] = "stated by user"
        missing = [m for m in missing if not m.startswith("starting stock")]
    if "unit_cost" not in costs and inp["unit_cost"] is not None:
        costs["unit_cost"] = inp["unit_cost"]
    results = []
    opt = None
    for v in vs:
        a = v["assumptions"]
        if pol["type"] == "optimise":
            best, table, objective = _optimise(inp, a, costs, cons, weeks, runs, seed, start_stock)
            if best is None:
                results.append({"name": v["name"], "assumptions": a, "feasible": False,
                                "note": "no order-up-to level in the searched range meets the constraints", "frontier": table}); continue
            use = {"type": "order_up_to", "level": best["level"]}
            opt = {"objective": objective, "searched_levels": [round(t["level"], 1) for t in table]}
        elif pol["type"] == "order_up_to_auto":
            # the rule is set once from the baseline and then held fixed, so variants test the same policy under different conditions
            use = {"type": "order_up_to", "level": _auto_level(inp, {})}
        else:
            use = pol
        r = simulate(inp, a, use, weeks, runs, seed, start_stock)
        money, money_missing = _money(r, costs, a, weeks)
        results.append({"name": v["name"], "assumptions": a, "policy_used": use, "results": r, "money": money,
                        "money_inputs_missing": money_missing, "constraints": _constraints(r, money, cons),
                        **({"frontier": table, "optimisation": opt} if pol["type"] == "optimise" else {})})
    base = results[0].get("results")
    for r in results[1:]:
        if base and r.get("results"):
            r["vs_baseline"] = {k: r["results"][k] - base[k] for k in ("fill_rate", "expected_shortage_units", "avg_on_hand", "expected_ending_stock", "expected_units_ordered")}
    inputs = {"sku": sku, "location": location, "weeks": weeks, "runs": runs, "seed": seed, "policy": pol, "costs": costs, "constraints": cons,
              "variants": vs, "start_stock": start_stock, "resolved": {k: v for k, v in inp.items() if k != "rel_errors"},
              "rel_errors_n": len(inp["rel_errors"]), "missing": missing}
    out = {"variants": results, "limitations": [
        "Demand uncertainty comes from this method's past errors on this product; a regime change outside that history is not covered.",
        "Weekly buckets: shortages within a week are netted.", "Lost sales are not back-ordered.",
        "Stated assumptions and policies are for comparison. An optimum here is optimal for this model and these inputs only."]
        + (["Missing inputs: " + "; ".join(missing)] if missing else [])}
    sid = new_id("scn")
    with store.tx() as c:
        c.execute("INSERT INTO scenarios VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
                  (sid, p.org_id, ts(now), p.actor, (name or "scenario")[:120], sku, location, inp["forecast"]["id"], __version__,
                   inp["knowledge_time"], dumps(inputs), dumps(out)))
        audit.record(c, p.org_id, p.actor, "scenario.create", "scenario", sid, request_id, {"sku": sku, "variants": len(vs)})
    return get(store, p, sid)


def get(store, p, sid):
    r = store.conn().execute("SELECT * FROM scenarios WHERE id=? AND org_id=?", (sid, p.org_id)).fetchone()
    if not r:
        raise NotFound("no scenario %s in this organisation" % sid)
    d = dict(r); d.pop("org_id")
    d["inputs"] = json.loads(d.pop("inputs_json")); d.update(json.loads(d.pop("results_json")))
    return d


def list_scenarios(store, p, limit=50):
    rows = store.conn().execute("SELECT id, name, sku, location, created_at, forecast_id FROM scenarios WHERE org_id=? ORDER BY created_at DESC LIMIT ?",
                                (p.org_id, max(1, min(int(limit), 200))))
    return {"items": [dict(r) for r in rows]}
