"""Udgass engine: persistent, multi-organisation decision intelligence for demand and inventory.

Module boundaries
  db          storage, migrations, clock
  errors      typed errors shared by all layers
  tenancy     organisations, API keys, roles, authorisation
  audit       append-only audit log
  ingest      file validation, mapping, preview, idempotent commit, corrections
  memory      what was known at a time: series, fingerprints, history
  patterns    findings with evidence, method, limitations
  forecasting versioned forecast runs, backtests, policies (model promotion)
  evaluation  outcomes vs forecasts, performance over time, drift
  scenarios   inventory scenarios, constraints, optimisation under stated assumptions
  decisions   append-only decision records
  api         versioned local HTTP API

Calculations live in deterministic modules (udgass.forecast, udgass.detect and the ones above). No language model is used.
"""
