/* Udgass engine web app. Talks only to this server's /v1 API. Every number shown comes from the API; nothing is computed or invented here
   except formatting and chart scaling. All text from the server is inserted with textContent (never innerHTML). */
(function () {
  "use strict";
  var KEY = null, ME = null, VIEW = "overview", STATE = {};
  try { KEY = sessionStorage.getItem("udgass_key"); } catch (e) { KEY = null; }

  // ---------- tiny helpers ----------
  function h(tag, attrs) {
    var el = document.createElement(tag), i, k;
    attrs = attrs || {};
    for (k in attrs) {
      if (!Object.prototype.hasOwnProperty.call(attrs, k) || attrs[k] == null || attrs[k] === false) continue;
      if (k === "text") el.textContent = attrs[k];
      else if (k === "on") { for (var ev in attrs.on) el.addEventListener(ev, attrs.on[ev]); }
      else if (k === "cls") el.className = attrs[k];
      else if (k === "style") el.style.cssText = attrs[k];          // CSSOM, allowed under the page's CSP (no inline style attributes)
      else el.setAttribute(k, attrs[k] === true ? "" : attrs[k]);
    }
    for (i = 2; i < arguments.length; i++) add(el, arguments[i]);
    return el;
  }
  function add(el, c) {
    if (c == null || c === false) return;
    if (Array.isArray(c)) { c.forEach(function (x) { add(el, x); }); return; }
    el.appendChild(typeof c === "string" || typeof c === "number" ? document.createTextNode(String(c)) : c);
  }
  function svg(tag, attrs) {
    var el = document.createElementNS("http://www.w3.org/2000/svg", tag);
    for (var k in attrs) if (attrs[k] != null) el.setAttribute(k === "cls" ? "class" : k, attrs[k]);
    for (var i = 2; i < arguments.length; i++) if (arguments[i]) el.appendChild(arguments[i]);
    return el;
  }
  function pct(x, d) { return x == null || isNaN(x) ? "n/a" : (x * 100).toFixed(d == null ? 1 : d) + "%"; }
  function num(x, d) { return x == null || isNaN(x) ? "n/a" : Number(x).toLocaleString(undefined, { maximumFractionDigits: d == null ? 0 : d, minimumFractionDigits: d || 0 }); }
  function sgn(x) { return x == null ? "n/a" : (x > 0 ? "+" : "") + (x * 100).toFixed(1) + "%"; }
  function short(id) { return id ? String(id).slice(0, 14) : ""; }
  function when(t) { return t ? String(t).replace("T", " ").slice(0, 19) + " UTC" : ""; }
  function tag(text, kind) { return h("span", { cls: "tag " + (kind || ""), text: text }); }
  var TABLES = 0;
  function table(cols, rows, onClick, selected) {
    var thead = h("thead", {}, h("tr", {}, cols.map(function (c) { return h("th", { cls: c.n ? "n" : "", scope: "col", text: c.t }); })));
    var tb = h("tbody", {}, rows.map(function (r) {
      var tr = h("tr", { cls: (onClick ? "click" : "") + (selected && selected(r) ? " sel" : ""), tabindex: onClick ? "0" : null },
        cols.map(function (c) { var v = c.f(r); return h("td", { cls: c.n ? "n" : "" }, v == null ? "" : v); }));
      if (onClick) {
        tr.addEventListener("click", function () { onClick(r); });
        tr.addEventListener("keydown", function (e) { if (e.key === "Enter") onClick(r); });
      }
      return tr;
    }));
    TABLES += 1;
    return h("div", { cls: "tw", role: "region", tabindex: "0", "aria-label": "Table " + TABLES + ": " + cols.map(function (c) { return c.t; }).filter(Boolean).slice(0, 3).join(", ") }, h("table", {}, thead, tb));
  }
  function api(method, path, body, raw) {
    var opt = { method: method, headers: { "Authorization": "Bearer " + KEY } };
    if (raw) { opt.body = raw; opt.headers["Content-Type"] = "text/csv"; }
    else if (body !== undefined) { opt.body = JSON.stringify(body); opt.headers["Content-Type"] = "application/json"; }
    return fetch(path, opt).then(function (r) {
      return r.json().catch(function () { return {}; }).then(function (j) {
        if (!r.ok) { var e = new Error((j.error && j.error.message) || ("HTTP " + r.status)); e.details = j.error && j.error.details; e.status = r.status; e.rid = j.error && j.error.request_id; throw e; }
        return j;
      });
    });
  }
  function errBox(e) {
    var box = h("div", { cls: "err", role: "alert" }, h("b", { text: e.message }));
    if (e.details && Object.keys(e.details).length) box.appendChild(h("pre", { cls: "mono small", text: JSON.stringify(e.details, null, 2) }));
    if (e.rid) box.appendChild(h("div", { cls: "small muted", text: "request id " + e.rid }));
    return box;
  }
  function busy(btn, p) {
    btn.disabled = true; var t = btn.textContent; btn.textContent = "Working…";
    return p.then(function (x) { btn.disabled = false; btn.textContent = t; return x; }, function (e) { btn.disabled = false; btn.textContent = t; throw e; });
  }
  function field(label, input) { return h("label", { cls: "f" }, label, input); }
  function main() { return document.getElementById("main"); }
  function page(title, sub) { var m = main(); m.textContent = ""; m.appendChild(h("h1", { text: title })); if (sub) m.appendChild(h("p", { cls: "sub", text: sub })); m.focus(); return m; }

  // ---------- charts ----------
  function lineChart(series, opts) {
    // series: [{name, color, points:[[x(index), y]], dash, band:[[x, lo, hi]]}], opts: {labels: [..], shade: [index...], height}
    var W = 900, H = opts.height || 260, L = 48, R = 12, T = 12, B = 28;
    var xs = [], ys = [];
    series.forEach(function (s) { (s.points || []).forEach(function (p) { xs.push(p[0]); ys.push(p[1]); }); (s.band || []).forEach(function (b) { xs.push(b[0]); ys.push(b[1], b[2]); }); });
    if (!xs.length) return h("p", { cls: "muted", text: "No data to chart." });
    var x0 = Math.min.apply(null, xs), x1 = Math.max.apply(null, xs), y1 = Math.max.apply(null, ys) * 1.08 || 1, y0 = 0;
    function X(v) { return L + (W - L - R) * (x1 === x0 ? 0.5 : (v - x0) / (x1 - x0)); }
    function Y(v) { return T + (H - T - B) * (1 - (v - y0) / (y1 - y0)); }
    var g = svg("svg", { viewBox: "0 0 " + W + " " + H, cls: "chart", role: "img", "aria-label": opts.label || "chart" });
    for (var i = 0; i <= 4; i++) {
      var v = y0 + (y1 - y0) * i / 4;
      g.appendChild(svg("line", { x1: L, x2: W - R, y1: Y(v), y2: Y(v), stroke: "rgba(155,168,181,.15)" }));
      var t = svg("text", { x: L - 6, y: Y(v) + 4, "text-anchor": "end" }); t.textContent = num(v); g.appendChild(t);
    }
    (opts.shade || []).forEach(function (si) { g.appendChild(svg("rect", { x: X(si) - 3, y: T, width: 6, height: H - T - B, fill: "rgba(227,154,128,.18)" })); });
    (opts.marks || []).forEach(function (m) { g.appendChild(svg("line", { x1: X(m), x2: X(m), y1: T, y2: H - B, stroke: "rgba(227,185,111,.6)", "stroke-dasharray": "3 3" })); });
    if (opts.labels) {
      var step = Math.max(1, Math.ceil(opts.labels.length / 8));
      opts.labels.forEach(function (lb, i2) { if (i2 % step === 0) { var tt = svg("text", { x: X(x0 + i2), y: H - 8, "text-anchor": "middle" }); tt.textContent = lb; g.appendChild(tt); } });
    }
    series.forEach(function (s) {
      if (s.band && s.band.length) {
        var up = s.band.map(function (b) { return X(b[0]) + "," + Y(b[2]); }), dn = s.band.slice().reverse().map(function (b) { return X(b[0]) + "," + Y(b[1]); });
        g.appendChild(svg("polygon", { points: up.concat(dn).join(" "), fill: s.fill || "rgba(112,214,195,.16)" }));
      }
      if (s.points && s.points.length) {
        g.appendChild(svg("polyline", { points: s.points.map(function (p) { return X(p[0]) + "," + Y(p[1]); }).join(" "), fill: "none", stroke: s.color, "stroke-width": s.width || 1.6, "stroke-dasharray": s.dash || null }));
      }
    });
    return g;
  }
  function legend(items) { return h("div", { cls: "legend" }, items.map(function (it) { return h("span", {}, h("i", { style: "background:" + it[1] }), it[0]); })); }

  // ---------- shell ----------
  var SECTIONS = [
    ["Workspace", [["overview", "Overview"]]],
    ["Evidence", [["data", "Data and imports"], ["history", "History"], ["patterns", "Patterns"]]],
    ["Estimates", [["forecasts", "Forecasts"], ["backtest", "Backtest and models"]]],
    ["Decisions", [["scenarios", "Scenarios"], ["decisions", "Decision records"], ["performance", "Outcomes and performance"]]],
    ["Governance", [["audit", "Audit log"], ["access", "Access"]]]
  ];
  function nav() {
    var n = document.getElementById("nav"); n.textContent = "";
    if (!ME) return;
    SECTIONS.forEach(function (g) {
      n.appendChild(h("div", { cls: "grp", text: g[0] }));
      g[1].forEach(function (s) {
        n.appendChild(h("button", { type: "button", "aria-current": VIEW === s[0] ? "page" : null, on: { click: function () { go(s[0]); } } }, s[1]));
      });
    });
    var w = document.getElementById("who"); w.textContent = "";
    w.appendChild(h("div", { text: ME.name })); w.appendChild(h("div", { cls: "mono small", text: ME.role + " · " + short(ME.key_id) }));
    w.appendChild(h("button", { cls: "btn ghost", type: "button", style: "margin-top:8px", on: { click: signOut } }, "Sign out"));
    var b = document.getElementById("banner");
    if (/synthetic/i.test(ME.name)) { b.hidden = false; b.textContent = "Synthetic data workspace. Every result here comes from invented data and is not a customer result."; }
    else b.hidden = true;
  }
  function go(v) { VIEW = v; nav(); (VIEWS[v] || VIEWS.overview)(); try { history.replaceState(null, "", "#" + v); } catch (e) {} }
  function signOut() { KEY = null; ME = null; try { sessionStorage.removeItem("udgass_key"); } catch (e) {} nav(); login(); }

  function login(msg) {
    var m = page("Sign in", "Paste an API key for your organisation. It is kept in this browser tab only and sent only to this server.");
    var inp = h("input", { type: "password", autocomplete: "off", id: "key", "aria-label": "API key", style: "width:420px;max-width:100%" });
    var btn = h("button", { cls: "btn", type: "submit" }, "Sign in");
    var out = h("div");
    var f = h("form", { cls: "card row", on: { submit: function (e) {
      e.preventDefault(); KEY = inp.value.trim();
      busy(btn, api("GET", "/v1/me")).then(function (me) {
        ME = me; try { sessionStorage.setItem("udgass_key", KEY); } catch (er) {}
        go(location.hash.slice(1) || "overview");
      }).catch(function (er) { out.textContent = ""; out.appendChild(errBox(er)); });
    } } }, field("API key", inp), btn);
    m.appendChild(f); m.appendChild(out);
    if (msg) out.appendChild(h("div", { cls: "err", text: msg }));
    m.appendChild(h("p", { cls: "muted small", text: "No key yet? On the server machine run: udgass admin create-org \"Your organisation\" --db udgass.db. For a synthetic demo: udgass demo-workflow." }));
  }

  var VIEWS = {};

  // ---------- overview ----------
  VIEWS.overview = function () {
    var m = page("Overview", "What is happening, what supports it, and how well past estimates held up.");
    var k = h("div", { cls: "grid" }); m.appendChild(k);
    var rest = h("div"); m.appendChild(rest);
    Promise.all([api("GET", "/v1/products?limit=500"), api("GET", "/v1/imports?limit=200"), api("GET", "/v1/forecast-runs?limit=1"),
      api("GET", "/v1/findings?limit=6"), api("GET", "/v1/performance"), api("GET", "/v1/decisions?limit=5")]).then(function (r) {
      var prods = r[0], imps = r[1], runs = r[2], fnd = r[3], perf = r[4], decs = r[5];
      var committed = imps.items.filter(function (i) { return i.status === "committed"; }).length;
      [[num(prods.items.length), "products", prods.locations.length + " locations"], [num(committed), "committed imports", imps.items.length - committed + " other"],
       [runs.items[0] ? when(runs.items[0].created_at).slice(0, 10) : "none", "latest forecast run", runs.items[0] ? "data to " + runs.items[0].data_cutoff_day : "create one in Forecasts"],
       [perf.overall ? pct(perf.overall.wape) : "n/a", "live forecast error (WAPE)", perf.overall ? "baseline " + pct(perf.overall.baseline_wape) + " · " + perf.overall.n + " evaluated" : "nothing evaluated yet"],
       [perf.overall ? pct(perf.overall.coverage, 0) : "n/a", "actuals inside the range", perf.overall ? "target " + pct((runs.items[0] || {}).level || 0.8, 0) : ""]]
        .forEach(function (x) { k.appendChild(h("div", { cls: "kpi" }, h("b", { text: x[0] }), h("span", { text: x[1] }), h("div", { cls: "small muted", text: x[2] }))); });
      var flags = (perf.drift || []).filter(function (d) { return d.flag; });
      rest.appendChild(h("h2", { text: "Checks that need attention" }));
      rest.appendChild(flags.length ? h("ul", { cls: "plain" }, flags.map(function (d) { return h("li", {}, tag("flag", "bad"), " ", d.check + ": " + d.meaning); }))
        : h("p", { cls: "muted", text: perf.overall ? "No drift checks are flagged." : "Drift checks run once forecasts have been evaluated against outcomes." }));
      rest.appendChild(h("h2", { text: "Largest findings" }));
      if (!fnd.items.length) rest.appendChild(h("p", { cls: "muted", text: "No pattern run yet. Run one in Patterns." }));
      else rest.appendChild(table([{ t: "Kind", f: function (x) { return tag(x.kind.replace(/_/g, " "), "ac"); } }, { t: "Observation", f: function (x) { return x.observation; } },
        { t: "Period", f: function (x) { return (x.period_start || "") + (x.period_end ? " to " + x.period_end : ""); } }], fnd.items, function () { go("patterns"); }));
      rest.appendChild(h("h2", { text: "Recent decisions" }));
      if (!decs.items.length) rest.appendChild(h("p", { cls: "muted", text: "No decision records yet." }));
      else rest.appendChild(table([{ t: "Decision", f: function (x) { return x.title; } }, { t: "Owner", f: function (x) { return x.owner; } }, { t: "Status", f: function (x) { return tag(x.state.status.replace(/_/g, " ")); } }, { t: "Opened", f: function (x) { return when(x.created_at); } }],
        decs.items, function (x) { STATE.decision = x.id; go("decisions"); }));
    }).catch(function (e) { m.appendChild(errBox(e)); });
  };

  // ---------- data ----------
  VIEWS.data = function () {
    var m = page("Data and imports", "Upload an export, check how its columns map to the model and what would be rejected, then commit. Nothing is stored until you commit. Unmapped columns are never stored.");
    var kind = h("select", { id: "kind" }, ["sales", "inventory", "purchase_orders", "events"].map(function (k) { return h("option", { value: k, text: k.replace("_", " ") }); }));
    var src = h("input", { value: "erp", id: "src" });
    var file = h("input", { type: "file", accept: ".csv,.txt,.tsv,text/csv", id: "file" });
    var dfmt = h("select", { id: "dfmt" }, [["", "detect"], ["%Y-%m-%d", "2024-01-31"], ["%d/%m/%Y", "31/01/2024"], ["%m/%d/%Y", "01/31/2024"], ["%d-%m-%Y", "31-01-2024"], ["%d.%m.%Y", "31.01.2024"], ["%Y/%m/%d", "2024/01/31"], ["%Y%m%d", "20240131"]]
      .map(function (o) { return h("option", { value: o[0], text: o[1] }); }));
    var dup = h("select", {}, [["keep", "count identical rows separately"], ["drop", "drop identical rows"]].map(function (o) { return h("option", { value: o[0], text: o[1] }); }));
    var btn = h("button", { cls: "btn", type: "submit" }, "Check file");
    var out = h("div");
    var mapping = {};
    function upload() {
      var f = file.files[0];
      if (!f) { out.textContent = ""; out.appendChild(h("div", { cls: "err", text: "Choose a file first." })); return; }
      var q = "/v1/imports?kind=" + encodeURIComponent(kind.value) + "&source=" + encodeURIComponent(src.value) + "&file_name=" + encodeURIComponent(f.name) +
        "&duplicate_rows=" + dup.value + (dfmt.value ? "&date_format=" + encodeURIComponent(dfmt.value) : "") +
        (Object.keys(mapping).length ? "&mapping=" + encodeURIComponent(JSON.stringify(mapping)) : "");
      busy(btn, api("POST", q, undefined, f)).then(function (pv) { showPreview(pv); }).catch(function (e) { out.textContent = ""; out.appendChild(errBox(e)); });
    }
    function showPreview(pv) {
      out.textContent = "";
      var r = pv.report;
      out.appendChild(h("h2", { text: "Preview " + short(pv.import_id) }));
      out.appendChild(h("p", {}, pv.ready ? tag("ready to commit", "ok") : tag("needs a decision", "am"), " ", h("span", { cls: "muted", text: "delimiter " + JSON.stringify(r.delimiter) })));
      var fields = Object.keys(r.mapping).concat(Object.keys(r.ambiguous || {})).concat(r.missing_required || []);
      var rows = fields.filter(function (x, i) { return fields.indexOf(x) === i; }).map(function (fld) { return { f: fld }; });
      out.appendChild(h("h3", { text: "Column mapping" }));
      out.appendChild(table([{ t: "Field", f: function (x) { return h("span", { cls: "mono", text: x.f }); } },
        { t: "Column in your file", f: function (x) {
          var sel = h("select", { "aria-label": "column for " + x.f, on: { change: function () { mapping[x.f] = sel.value || null; } } },
            [h("option", { value: "", text: "(not mapped)" })].concat(r.columns.map(function (c) { return h("option", { value: c, text: c, selected: r.mapping[x.f] === c ? true : null }); })));
          return sel; } },
        { t: "Status", f: function (x) { return r.mapping[x.f] ? tag("mapped", "ok") : (r.ambiguous && r.ambiguous[x.f] ? tag("ambiguous: " + r.ambiguous[x.f].join(" / "), "am") : tag("missing", "bad")); } },
        { t: "Date format", f: function (x) { var di = (r.date_format_issues || {})[x.f]; return r.date_formats && r.date_formats[x.f] ? h("span", { cls: "mono", text: r.date_formats[x.f] }) : (di ? tag(di.message, "am") : ""); } }], rows));
      out.appendChild(h("div", { cls: "row" }, h("button", { cls: "btn ghost", type: "button", on: { click: upload } }, "Check again with these choices")));
      if (r.rows_read != null) {
        out.appendChild(h("div", { cls: "grid" }, [["rows read", num(r.rows_read)], ["rejected", num(r.rows_rejected)], ["records", num(r.records)],
          ["new", num(r.compared_with_stored.new)], ["already stored", num(r.compared_with_stored.already_present)], ["corrections", num(r.compared_with_stored.corrections)]]
          .map(function (x) { return h("div", { cls: "kpi" }, h("b", { text: x[1] }), h("span", { text: x[0] })); })));
        out.appendChild(h("p", { cls: "muted", text: "Dates " + (r.first_day || "?") + " to " + (r.last_day || "?") + "." }));
        if (r.assumption) out.appendChild(h("div", { cls: "note", text: r.assumption }));
        if (r.compared_with_stored.corrections) out.appendChild(h("div", { cls: "note", text: "Corrections keep the old values: each corrected record gets a new version and the old one is marked as superseded at commit time." }));
        if (r.rejected.length) {
          out.appendChild(h("h3", { text: "Rejected rows" }));
          out.appendChild(table([{ t: "Reason", f: function (x) { return x.reason; } }, { t: "Rows", n: 1, f: function (x) { return num(x.rows); } },
            { t: "Examples (row: value)", f: function (x) { return x.examples.map(function (e) { return e.row + (e.value != null ? ": " + e.value : ""); }).join(", "); } }], r.rejected));
        }
        if (r.warnings.length) out.appendChild(h("div", {}, h("h3", { text: "Warnings" }), h("ul", { cls: "plain" }, r.warnings.map(function (w) { return h("li", { text: w.reason + (w.rows > 1 ? " (" + w.rows + " rows)" : "") }); }))));
        var ign = (r.ignored_columns || []);
        if (ign.length) out.appendChild(h("div", {}, h("h3", { text: "Ignored columns (not stored)" }), h("p", {}, ign.map(function (c) { return [tag(c.column, c.looks_personal ? "bad" : ""), " "]; })),
          r.personal_data_notice ? h("div", { cls: "note", text: r.personal_data_notice }) : null));
        if (pv.sample && pv.sample.length) {
          out.appendChild(h("h3", { text: "First records as they will be stored" }));
          var keys = Object.keys(pv.sample[0]);
          out.appendChild(table(keys.map(function (k2) { return { t: k2, f: function (x) { return String(x[k2] == null ? "" : x[k2]); } }; }), pv.sample));
        }
      }
      var cbtn = h("button", { cls: "btn", type: "button", disabled: pv.ready ? null : true }, "Commit import");
      cbtn.addEventListener("click", function () {
        busy(cbtn, api("POST", "/v1/imports/" + pv.import_id + "/commit", { mapping: Object.keys(mapping).length ? Object.assign({}, r.mapping, mapping) : null, date_format: dfmt.value || null, options: { duplicate_rows: dup.value } }))
          .then(function (res) { out.insertBefore(h("div", { cls: "note", role: "status", text: "Committed: " + res.counts.new + " new, " + res.counts.already_present + " already stored, " + res.counts.corrections + " corrections." }), out.firstChild); list(); })
          .catch(function (e) { out.appendChild(errBox(e)); });
      });
      out.appendChild(h("div", { cls: "row", style: "margin-top:12px" }, cbtn, pv.ready ? null : h("span", { cls: "muted", text: "Resolve the mapping and date format first." })));
    }
    m.appendChild(h("form", { cls: "card row", on: { submit: function (e) { e.preventDefault(); mapping = {}; upload(); } } },
      field("Dataset", kind), field("Source system name", src), field("File (CSV, UTF-8)", file), field("Date format", dfmt), field("Identical rows", dup), btn));
    m.appendChild(out);
    var lst = h("div"); m.appendChild(h("h2", { text: "Imports" })); m.appendChild(lst);
    function list() {
      api("GET", "/v1/imports?limit=100").then(function (r) {
        lst.textContent = "";
        lst.appendChild(table([{ t: "When", f: function (x) { return when(x.created_at); } }, { t: "Dataset", f: function (x) { return x.dataset_kind; } }, { t: "Source", f: function (x) { return x.source; } },
          { t: "File", f: function (x) { return x.file_name; } }, { t: "Status", f: function (x) { return tag(x.status, x.status === "committed" ? "ok" : x.status === "previewed" ? "am" : ""); } },
          { t: "Last error", f: function (x) { return x.error || ""; } }], r.items));
      }).catch(function (e) { lst.appendChild(errBox(e)); });
    }
    list();
  };

  // ---------- history ----------
  function productPicker(onPick, preset) {
    var sku = h("select", { "aria-label": "product" }), loc = h("select", { "aria-label": "location" });
    api("GET", "/v1/products?limit=500").then(function (r) {
      r.items.forEach(function (p) { sku.appendChild(h("option", { value: p.sku, text: p.sku + (p.category ? " · " + p.category : ""), selected: preset && preset.sku === p.sku ? true : null })); });
      loc.appendChild(h("option", { value: "ALL", text: "all locations" }));
      r.locations.forEach(function (l) { loc.appendChild(h("option", { value: l, text: l, selected: preset && preset.location === l ? true : null })); });
      if (!preset && r.locations.length) loc.value = r.locations[0];
      onPick && onPick(sku.value, loc.value);
    });
    return { sku: sku, loc: loc };
  }
  VIEWS.history = function () {
    var m = page("History", "What is recorded for one product, as known at a chosen time. Stock-out weeks are shaded: sales in those weeks can understate demand.");
    var asof = h("input", { type: "datetime-local", "aria-label": "as known at" });
    var out = h("div");
    var pp = productPicker(function () { show(); }, STATE.series);
    var btn = h("button", { cls: "btn", type: "submit" }, "Show");
    m.appendChild(h("form", { cls: "card row", on: { submit: function (e) { e.preventDefault(); show(); } } }, field("Product", pp.sku), field("Location", pp.loc), field("As known at (optional, your local time)", asof), btn));
    m.appendChild(out);
    function show() {
      STATE.series = { sku: pp.sku.value, location: pp.loc.value };
      var q = "/v1/history?sku=" + encodeURIComponent(pp.sku.value) + "&location=" + encodeURIComponent(pp.loc.value) + (asof.value ? "&as_known_at=" + encodeURIComponent(new Date(asof.value).toISOString()) : "");
      out.textContent = ""; out.appendChild(h("p", { cls: "loading", text: "Loading…" }));
      api("GET", q).then(function (hs) {
        out.textContent = "";
        var labels = hs.weeks.map(function (w) { return w.week.slice(0, 7); });
        var idx = {}; hs.weeks.forEach(function (w, i) { idx[w.week] = i; });
        var shade = hs.stockout_weeks.map(function (d) { return idx[d]; }).filter(function (x) { return x != null; });
        var marks = hs.events.map(function (e) { var mon = new Date(e.start_day + "T00:00:00Z"); var d = (mon.getUTCDay() + 6) % 7; mon.setUTCDate(mon.getUTCDate() - d); return idx[mon.toISOString().slice(0, 10)]; }).filter(function (x) { return x != null; });
        out.appendChild(h("dl", { cls: "kv" }, h("dt", { text: "As known at" }), h("dd", { text: when(hs.knowledge_time) }), h("dt", { text: "Data up to" }), h("dd", { text: hs.data_cutoff_day }),
          h("dt", { text: "Complete weeks" }), h("dd", { text: hs.weeks.length + " (" + hs.weeks_without_rows + " without any sales rows, treated as zero)" })));
        out.appendChild(lineChart([{ name: "demand", color: "#70D6C3", points: hs.weeks.map(function (w, i) { return [i, w.demand]; }) }], { labels: labels, shade: shade, marks: marks, label: "weekly demand" }));
        out.appendChild(legend([["weekly recorded sales", "#70D6C3"], ["zero-stock week", "rgba(227,154,128,.6)"], ["recorded event", "#E3B96F"]]));
        out.appendChild(h("div", { cls: "note", text: hs.assumption }));
        if (hs.events.length) { out.appendChild(h("h2", { text: "Recorded events" })); out.appendChild(table([{ t: "Type", f: function (e) { return e.event_type; } }, { t: "From", f: function (e) { return e.start_day; } }, { t: "To", f: function (e) { return e.end_day; } }, { t: "Notes", f: function (e) { return e.description || ""; } }], hs.events)); }
        var pos = hs.purchase_orders.slice(-12).reverse();
        if (pos.length) { out.appendChild(h("h2", { text: "Latest purchase orders" })); out.appendChild(table([{ t: "PO", f: function (x) { return x.po_number; } }, { t: "Vendor", f: function (x) { return x.supplier || ""; } }, { t: "Ordered", f: function (x) { return x.order_day; } }, { t: "Promised", f: function (x) { return x.expected_day || ""; } }, { t: "Received", f: function (x) { return x.received_day || tag("open", "am"); } }, { t: "Qty", n: 1, f: function (x) { return num(x.quantity); } }], pos)); }
      }).catch(function (e) { out.textContent = ""; out.appendChild(errBox(e)); });
    }
  };

  // ---------- patterns ----------
  VIEWS.patterns = function () {
    var m = page("Patterns", "Observations worth a person's review, each with its evidence, method and limits. A finding is not a cause and has not been validated by anyone.");
    var sens = h("select", {}, [["balanced", "balanced (fewer false flags)"], ["sensitive", "sensitive (catches more, more false flags)"]].map(function (o) { return h("option", { value: o[0], text: o[1] }); }));
    var btn = h("button", { cls: "btn", type: "submit" }, "Run pattern detection");
    var out = h("div");
    m.appendChild(h("form", { cls: "card row", on: { submit: function (e) { e.preventDefault(); busy(btn, api("POST", "/v1/patterns/runs", { sensitivity: sens.value })).then(show).catch(function (er) { out.appendChild(errBox(er)); }); } } }, field("Sensitivity", sens), btn));
    m.appendChild(out);
    function show(res) {
      out.textContent = "";
      if (!res.run_id) { out.appendChild(h("p", { cls: "muted", text: "No pattern run yet." })); return; }
      out.appendChild(h("p", { cls: "muted", text: res.total + " findings in run " + short(res.run_id) + ", largest first. " + Object.keys(res.counts).map(function (k) { return res.counts[k] + " " + k.replace(/_/g, " "); }).join(", ") + "." }));
      res.items.forEach(function (f) {
        var c = h("div", { cls: "card" }, h("div", { cls: "row" }, tag(f.kind.replace(/_/g, " "), "ac"), f.sku ? tag(f.sku + (f.location ? " · " + f.location : "")) : null, tag("not validated", "am"),
          h("span", { cls: "muted small", text: (f.period_start || "") + (f.period_end && f.period_end !== f.period_start ? " to " + f.period_end : "") })),
          h("h2", { cls: "t", text: f.observation }),
          h("details", {}, h("summary", { text: "Evidence, method and limits" }),
            h("dl", { cls: "kv" }, h("dt", { text: "Method" }), h("dd", { text: f.method }), h("dt", { text: "Assumptions" }), h("dd", { text: (f.assumptions || []).join(" ") }),
              f.uncertainty ? [h("dt", { text: "Uncertainty" }), h("dd", { cls: "mono small", text: JSON.stringify(f.uncertainty) })] : null,
              h("dt", { text: "Evidence" }), h("dd", { cls: "mono small", text: JSON.stringify(f.evidence) }),
              h("dt", { text: "Known when" }), h("dd", { text: when(f.knowledge_time) + " · data " + short(f.dataset_fingerprint.replace("sha256:", "")) })),
            h("ul", { cls: "plain" }, (f.limitations || []).map(function (l) { return h("li", { text: l }); }))));
        out.appendChild(c);
      });
    }
    api("GET", "/v1/findings?limit=200").then(show).catch(function (e) { out.appendChild(errBox(e)); });
  };

  // ---------- forecasts ----------
  VIEWS.forecasts = function () {
    var m = page("Forecasts", "Each run is stored as made: the data it could see, its cutoff and fingerprint, the method chosen per product, and a range. Later data never changes a stored forecast.");
    var hz = h("input", { type: "number", min: 1, max: 26, value: 4, style: "width:90px" }), lv = h("select", {}, [["0.8", "80%"], ["0.9", "90%"], ["0.5", "50%"]].map(function (o) { return h("option", { value: o[0], text: o[1] }); }));
    var btn = h("button", { cls: "btn", type: "submit" }, "Create forecast run");
    var runsBox = h("div"), fcBox = h("div"), detail = h("div");
    m.appendChild(h("form", { cls: "card row", on: { submit: function (e) { e.preventDefault(); busy(btn, api("POST", "/v1/forecast-runs", { horizon: Number(hz.value), level: Number(lv.value) })).then(function (r) { STATE.run = r.id; loadRuns(); }).catch(function (er) { runsBox.appendChild(errBox(er)); }); } } },
      field("Horizon (weeks)", hz), field("Range level", lv), btn));
    m.appendChild(runsBox); m.appendChild(fcBox); m.appendChild(detail);
    function loadRuns() {
      api("GET", "/v1/forecast-runs?limit=20").then(function (r) {
        runsBox.textContent = "";
        runsBox.appendChild(h("h2", { text: "Runs" }));
        if (!r.items.length) { runsBox.appendChild(h("p", { cls: "muted", text: "No forecast runs yet." })); return; }
        if (!STATE.run) STATE.run = r.items[0].id;
        runsBox.appendChild(table([{ t: "Created", f: function (x) { return when(x.created_at); } }, { t: "Data up to", f: function (x) { return x.data_cutoff_day; } },
          { t: "Forecasts", n: 1, f: function (x) { return num(x.summary.forecasts); } }, { t: "Skipped", n: 1, f: function (x) { return num(x.summary.skipped.length); } },
          { t: "Horizon", n: 1, f: function (x) { return x.horizon_weeks + " wk"; } }, { t: "Fingerprint", f: function (x) { return h("span", { cls: "mono", text: x.dataset_fingerprint.slice(7, 19) }); } }],
          r.items, function (x) { STATE.run = x.id; loadRuns(); }, function (x) { return x.id === STATE.run; }));
        var sel = r.items.filter(function (x) { return x.id === STATE.run; })[0];
        if (sel && sel.summary.skipped.length) runsBox.appendChild(h("details", {}, h("summary", { text: sel.summary.skipped.length + " series skipped" }), h("ul", { cls: "plain" }, sel.summary.skipped.map(function (s) { return h("li", { text: s.sku + " · " + s.location + ": " + s.reason }); }))));
        loadFc();
      }).catch(function (e) { runsBox.appendChild(errBox(e)); });
    }
    function loadFc() {
      api("GET", "/v1/forecast-runs/" + STATE.run + "/forecasts?limit=500").then(function (r) {
        fcBox.textContent = "";
        fcBox.appendChild(h("h2", { text: "Forecasts in this run" }));
        fcBox.appendChild(table([{ t: "Product", f: function (x) { return x.sku; } }, { t: "Location", f: function (x) { return x.location; } }, { t: "Window", f: function (x) { return x.target_start + " to " + x.target_end; } },
          { t: "Estimate", n: 1, f: function (x) { return num(x.point); } }, { t: "Range", n: 1, f: function (x) { return num(x.low) + " – " + num(x.high); } },
          { t: "Method", f: function (x) { return x.method; } }, { t: "Evidence", f: function (x) { return tag(x.evidence_quality, x.evidence_quality === "thin" ? "am" : ""); } },
          { t: "Notes", n: 1, f: function (x) { return x.notes.length ? tag(x.notes.length + (x.notes.length === 1 ? " note" : " notes"), "am") : ""; } }], r.items, function (x) { STATE.forecast = x.id; explain(x.id); }, function (x) { return x.id === STATE.forecast; }));
      }).catch(function (e) { fcBox.appendChild(errBox(e)); });
    }
    function explain(id) {
      detail.textContent = ""; detail.appendChild(h("p", { cls: "loading", text: "Loading…" }));
      api("GET", "/v1/forecasts/" + id).then(function (e) {
        var f = e.forecast;
        detail.textContent = "";
        detail.appendChild(h("h2", { text: "Why this estimate: " + f.sku + " · " + f.location }));
        var rb = h("button", { cls: "btn ghost", type: "button" }, "Rebuild from what was known then");
        var rbo = h("span", { cls: "small" });
        rb.addEventListener("click", function () { busy(rb, api("GET", "/v1/forecasts/" + id + "/reconstruct")).then(function (r) { rbo.textContent = ""; rbo.appendChild(r.matches && r.fingerprint_matches ? tag("rebuilt exactly: same data, same result", "ok") : tag("did not match", "bad")); }).catch(function (er) { detail.appendChild(errBox(er)); }); });
        var hist = h("div");
        detail.appendChild(h("div", { cls: "split" },
          h("div", { cls: "card" }, h("h3", { text: "Observed and recorded" }), h("dl", { cls: "kv" },
            h("dt", { text: "History used" }), h("dd", { text: e.facts.history_weeks_used + " complete weeks, the last one starting " + e.facts.last_complete_week + " (data to " + e.facts.data_cutoff_day + ")" }),
            h("dt", { text: "Known at" }), h("dd", { text: when(e.facts.knowledge_time) }),
            h("dt", { text: "Data fingerprint" }), h("dd", { cls: "mono small", text: e.facts.dataset_fingerprint }),
            h("dt", { text: "Engine / policy" }), h("dd", { text: e.facts.engine_version + " · " + e.facts.policy_methods.join(", ") })), h("div", { cls: "row" }, rb, rbo)),
          h("div", { cls: "card" }, h("h3", { text: "Statistical estimate" }), h("p", { text: e.estimate.what }),
            h("p", {}, h("b", { text: num(f.point) }), " (range " + num(f.low) + " to " + num(f.high) + ")"), h("p", { cls: "muted small", text: e.estimate.range_meaning }))));
        detail.appendChild(hist);
        api("GET", "/v1/history?sku=" + encodeURIComponent(f.sku) + "&location=" + encodeURIComponent(f.location) + "&as_known_at=" + encodeURIComponent(e.facts.knowledge_time)).then(function (hs) {
          var w = hs.weeks.slice(-52), n = w.length;
          var pts = w.map(function (x, i) { return [i, x.demand]; });
          var fw = f.weekly.map(function (v, i) { return [n + i, v]; });
          var ratioLo = f.low / f.point, ratioHi = f.high / f.point;
          var band = f.weekly.map(function (v, i) { return [n + i, v * (isFinite(ratioLo) ? ratioLo : 1), v * (isFinite(ratioHi) ? ratioHi : 1)]; });
          hist.appendChild(lineChart([{ color: "#9BA8B5", points: pts }, { color: "#70D6C3", points: [[n - 1, pts[n - 1][1]]].concat(fw), dash: "5 4", band: band }],
            { labels: w.map(function (x) { return x.week.slice(0, 7); }).concat(f.weekly.map(function () { return ""; })), label: "history and forecast" }));
          hist.appendChild(legend([["history known at forecast time (52 weeks)", "#9BA8B5"], ["weekly path of the estimate", "#70D6C3"], ["range spread across weeks (for orientation; the range applies to the window total)", "rgba(112,214,195,.4)"]]));
        }).catch(function () {});
        detail.appendChild(h("h3", { text: "Method selection evidence" }));
        detail.appendChild(h("p", { cls: "muted small", text: "Chosen: " + e.method.chosen + ". " + e.method.why + "." }));
        var cands = Object.keys(e.method.all_candidates).map(function (k) { return { m: k, w: e.method.all_candidates[k].internal_wape, n: e.method.all_candidates[k].past_errors }; });
        detail.appendChild(table([{ t: "Method", f: function (x) { return x.m === e.method.chosen ? h("b", { text: x.m + " (chosen)" }) : x.m; } }, { t: "Error on its own past windows", n: 1, f: function (x) { return pct(x.w); } }, { t: "Past windows", n: 1, f: function (x) { return x.n; } }], cands));
        detail.appendChild(h("h3", { text: "Limitations" })); detail.appendChild(h("ul", { cls: "plain" }, e.limitations.map(function (l) { return h("li", { text: l }); })));
        detail.appendChild(h("h3", { text: "Evaluations against what happened" }));
        detail.appendChild(e.evaluations.length ? table([{ t: "Evaluated", f: function (x) { return when(x.evaluated_at); } }, { t: "Actual", n: 1, f: function (x) { return num(x.actual); } }, { t: "Error", n: 1, f: function (x) { return num(x.error); } },
          { t: "Inside range", f: function (x) { return x.inside ? tag("yes", "ok") : tag("no", "bad"); } }, { t: "Baseline estimate", n: 1, f: function (x) { return num(x.baseline); } }, { t: "Notes", f: function (x) { return x.notes.join(" "); } }], e.evaluations)
          : h("p", { cls: "muted", text: "Not evaluated yet. Evaluations run once the whole window is in the data (Outcomes and performance)." }));
      }).catch(function (er) { detail.textContent = ""; detail.appendChild(errBox(er)); });
    }
    loadRuns();
  };

  // ---------- backtest ----------
  VIEWS.backtest = function () {
    var m = page("Backtest and models", "Replays the past with rolling origins: every estimate uses only weeks before its date. The active policy is compared with three baselines on the same windows. A new policy becomes active only if it wins on both halves of the history.");
    var cand = h("select", {}, h("option", { value: "", text: "(none)" }));
    var btn = h("button", { cls: "btn", type: "submit" }, "Run backtest");
    var pol = h("div"), out = h("div");
    m.appendChild(h("form", { cls: "card row", on: { submit: function (e) { e.preventDefault(); busy(btn, api("POST", "/v1/backtests", { candidate_policy_id: cand.value || null })).then(function (b) { STATE.bt = b.id; show(b.id); }).catch(function (er) { out.textContent = ""; out.appendChild(errBox(er)); }); } } },
      field("Candidate policy to compare (optional)", cand), btn));
    m.appendChild(out); m.appendChild(pol);
    function policies() {
      api("GET", "/v1/policies").then(function (r) {
        pol.textContent = ""; cand.textContent = ""; cand.appendChild(h("option", { value: "", text: "(none)" }));
        r.policies.forEach(function (p) { if (!p.active) cand.appendChild(h("option", { value: p.id, text: p.name })); });
        pol.appendChild(h("h2", { text: "Policies" }));
        pol.appendChild(table([{ t: "Name", f: function (p) { return p.name; } }, { t: "Methods", f: function (p) { return p.methods.join(", "); } }, { t: "Status", f: function (p) { return p.active ? tag("active", "ok") : tag("candidate"); } },
          { t: "Action", f: function (p) { if (p.active || !STATE.bt || ME.role !== "admin") return ""; var b = h("button", { cls: "btn ghost", type: "button" }, "Promote using last backtest");
            b.addEventListener("click", function () { busy(b, api("POST", "/v1/policies/" + p.id + "/promote", { backtest_id: STATE.bt })).then(policies).catch(function (er) { pol.appendChild(errBox(er)); }); }); return b; } }], r.policies));
        var nm = h("input", { value: "candidate" }), ms = h("input", { value: "combo,holt_slow,seasonal", style: "min-width:260px" });
        var cb = h("button", { cls: "btn ghost", type: "submit" }, "Add candidate policy");
        pol.appendChild(h("form", { cls: "card row", on: { submit: function (e) { e.preventDefault(); busy(cb, api("POST", "/v1/policies", { name: nm.value, methods: ms.value.split(",").map(function (x) { return x.trim(); }) })).then(policies).catch(function (er) { pol.appendChild(errBox(er)); }); } } },
          field("Name", nm), field("Methods (naive, seasonal, holt_fast, holt_slow, sba, combo)", ms), cb));
        if (ME.role === "admin") { var rb = h("button", { cls: "btn warn", type: "button" }, "Roll back to the previous policy"); rb.addEventListener("click", function () { busy(rb, api("POST", "/v1/policies/rollback", {})).then(policies).catch(function (er) { pol.appendChild(errBox(er)); }); }); pol.appendChild(rb); }
        pol.appendChild(h("h3", { text: "Policy log" }));
        pol.appendChild(table([{ t: "When", f: function (l) { return when(l.at); } }, { t: "Action", f: function (l) { return l.action; } }, { t: "Policy", f: function (l) { return short(l.policy_id); } }, { t: "Evidence", f: function (l) { return h("span", { cls: "mono small", text: JSON.stringify(l.evidence).slice(0, 160) }); } }], r.log.slice().reverse()));
      });
    }
    function show(id) {
      out.textContent = ""; out.appendChild(h("p", { cls: "loading", text: "Loading…" }));
      api("GET", "/v1/backtests/" + id).then(function (b) {
        out.textContent = "";
        out.appendChild(h("p", { cls: "muted", text: b.origins + " as-of dates, " + b.params.horizon_weeks + "-week windows. Known at " + when(b.knowledge_time) + "." }));
        ["test", "all"].forEach(function (per) {
          out.appendChild(h("h2", { text: per === "test" ? "Later half of the history (test)" : "All windows" }));
          out.appendChild(table([{ t: "Model", f: function (r) { return r.model.indexOf(":") > 0 ? h("b", { text: r.model }) : r.model + " (baseline)"; } }, { t: "WAPE", n: 1, f: function (r) { return pct(r.wape); } },
            { t: "Bias", n: 1, f: function (r) { return sgn(r.bias); } }, { t: "MAE / week", n: 1, f: function (r) { return num(r.mae, 1); } }, { t: "RMSE / week", n: 1, f: function (r) { return num(r.rmse, 1); } },
            { t: "Inside range", n: 1, f: function (r) { return r.coverage == null ? "no range" : pct(r.coverage, 0); } }, { t: "Interval score", n: 1, f: function (r) { return r.interval_score == null ? "" : num(r.interval_score, 2); } }, { t: "Windows", n: 1, f: function (r) { return r.windows; } }],
            per === "test" ? b.leaderboard_test : b.leaderboard_all));
        });
        var act = Object.keys(b.models).filter(function (k) { return k.indexOf("active:") === 0; })[0];
        var A = b.models[act];
        out.appendChild(h("h3", { text: "Error by weeks ahead (active policy vs four-week mean)" }));
        out.appendChild(table([{ t: "Week ahead", f: function (k) { return k; } }, { t: "Active WAPE", n: 1, f: function (k) { return pct(A.all.by_horizon_week[k].wape); } }, { t: "Four-week mean WAPE", n: 1, f: function (k) { return pct(b.models.moving_avg_4.all.by_horizon_week[k].wape); } }], Object.keys(A.all.by_horizon_week)));
        ["category", "demand_class", "location"].forEach(function (dim) {
          out.appendChild(h("h3", { text: "By " + dim.replace("_", " ") }));
          var segs = Object.keys(A.by_segment[dim]);
          out.appendChild(table([{ t: dim.replace("_", " "), f: function (s) { return s; } }, { t: "Active WAPE", n: 1, f: function (s) { return pct(A.by_segment[dim][s].wape); } }, { t: "Bias", n: 1, f: function (s) { return sgn(A.by_segment[dim][s].bias); } },
            { t: "Four-week mean WAPE", n: 1, f: function (s) { var x = b.models.moving_avg_4.by_segment[dim][s]; return x ? pct(x.wape) : ""; } }, { t: "Windows", n: 1, f: function (s) { return A.by_segment[dim][s].n; } }], segs));
        });
        out.appendChild(h("h3", { text: "Largest errors (shown on purpose)" }));
        out.appendChild(table([{ t: "Product", f: function (r) { return r.sku; } }, { t: "Location", f: function (r) { return r.location; } }, { t: "WAPE", n: 1, f: function (r) { return pct(r.wape); } }, { t: "Bias", n: 1, f: function (r) { return sgn(r.bias); } }, { t: "Windows", n: 1, f: function (r) { return r.n; } }], b.worst_series_active));
        out.appendChild(h("ul", { cls: "plain muted small" }, b.notes.map(function (n) { return h("li", { text: n }); })));
        policies();
      }).catch(function (e) { out.textContent = ""; out.appendChild(errBox(e)); });
    }
    policies();
    if (STATE.bt) show(STATE.bt);
  };

  // ---------- scenarios ----------
  VIEWS.scenarios = function () {
    var m = page("Scenarios", "Compare what could happen to one product's stock under stated assumptions. Every variant uses the same random draws, so differences come from the assumptions. Nothing here places an order.");
    var pp = productPicker(null, STATE.series);
    var weeks = h("input", { type: "number", min: 4, max: 52, value: 13, style: "width:90px" });
    var ptype = h("select", {}, [["order_up_to_auto", "order-up-to: lead time + 2 weeks of baseline demand, same for every variant"], ["order_up_to", "order-up-to level I choose"], ["optimise", "find the best order-up-to level"]].map(function (o) { return h("option", { value: o[0], text: o[1] }); }));
    var lvl = h("input", { type: "number", min: 0, placeholder: "level", style: "width:110px" });
    var hr = h("input", { type: "number", step: "0.01", value: "0.25", style: "width:90px" }), sc = h("input", { type: "number", value: "", placeholder: "per unit", style: "width:110px" }), oc = h("input", { type: "number", value: "", placeholder: "per order", style: "width:110px" }), uc = h("input", { type: "number", placeholder: "from POs", style: "width:110px" });
    var minfr = h("input", { type: "number", step: "0.01", value: "0.95", style: "width:90px" }), maxval = h("input", { type: "number", placeholder: "optional", style: "width:130px" });
    var vchecks = [["demand +20%", { demand_multiplier: 1.2 }], ["demand -20%", { demand_multiplier: 0.8 }], ["vendor 3 weeks late", { lead_time_delay_weeks: 3 }], ["stock 30% below record", { stock_adjustment_pct: -30 }], ["unit cost +15%", { unit_cost_change_pct: 15 }]]
      .map(function (v) { var c = h("input", { type: "checkbox", checked: v[0] !== "demand -20%" && v[0] !== "unit cost +15%" ? true : null }); return { c: c, v: v }; });
    var btn = h("button", { cls: "btn", type: "submit" }, "Run scenarios");
    var out = h("div");
    m.appendChild(h("form", { cls: "card", on: { submit: function (e) {
      e.preventDefault();
      var costs = {}; if (hr.value) costs.holding_rate_per_year = Number(hr.value); if (sc.value) costs.shortage_cost_per_unit = Number(sc.value); if (oc.value) costs.order_cost = Number(oc.value); if (uc.value) costs.unit_cost = Number(uc.value);
      var cons = {}; if (minfr.value) cons.min_fill_rate = Number(minfr.value); if (maxval.value) cons.max_avg_inventory_value = Number(maxval.value);
      var pol = { type: ptype.value }; if (ptype.value === "order_up_to") pol.level = Number(lvl.value || 0);
      STATE.series = { sku: pp.sku.value, location: pp.loc.value };
      busy(btn, api("POST", "/v1/scenarios", { sku: pp.sku.value, location: pp.loc.value, name: "Scenarios", weeks: Number(weeks.value), policy: pol, costs: costs, constraints: cons,
        variants: vchecks.filter(function (x) { return x.c.checked; }).map(function (x) { return { name: x.v[0], assumptions: x.v[1] }; }) })).then(function (s) { STATE.scenario = s.id; show(s); list(); }).catch(function (er) { out.textContent = ""; out.appendChild(errBox(er)); });
    } } },
      h("div", { cls: "row" }, field("Product", pp.sku), field("Location", pp.loc), field("Weeks", weeks), field("Stock policy", ptype), field("Level (if chosen)", lvl)),
      h("h2", { cls: "t", text: "Costs (money is only shown when given or found in purchase orders)" }),
      h("div", { cls: "row" }, field("Unit cost", uc), field("Holding rate per year", hr), field("Shortage cost", sc), field("Order cost", oc)),
      h("h2", { cls: "t", text: "Constraints" }), h("div", { cls: "row" }, field("Minimum fill rate", minfr), field("Max average inventory value", maxval)),
      h("h2", { cls: "t", text: "Variants to compare with the baseline" }), h("div", { cls: "row" }, vchecks.map(function (x) { return h("label", { cls: "row", style: "gap:6px" }, x.c, x.v[0]); })),
      h("div", { style: "margin-top:14px" }, btn)));
    m.appendChild(out);
    var lst = h("div"); m.appendChild(h("h2", { text: "Saved scenarios" })); m.appendChild(lst);
    function list() { api("GET", "/v1/scenarios").then(function (r) { lst.textContent = ""; lst.appendChild(table([{ t: "Created", f: function (x) { return when(x.created_at); } }, { t: "Name", f: function (x) { return x.name; } }, { t: "Product", f: function (x) { return x.sku + " · " + x.location; } }, { t: "Forecast", f: function (x) { return short(x.forecast_id); } }], r.items, function (x) { api("GET", "/v1/scenarios/" + x.id).then(show); })); }); }
    function show(s) {
      out.textContent = "";
      var R = s.inputs.resolved;
      out.appendChild(h("h2", { text: s.name + " · " + s.sku + " · " + s.location }));
      out.appendChild(h("dl", { cls: "kv" }, h("dt", { text: "Forecast used" }), h("dd", { text: short(R.forecast.id) + ": " + num(R.forecast.point) + " (" + num(R.forecast.low) + " to " + num(R.forecast.high) + ") over " + R.forecast.horizon_weeks + " weeks from " + R.forecast.target_start }),
        h("dt", { text: "Demand uncertainty" }), h("dd", { text: s.inputs.rel_errors_n + " measured past window errors of the " + R.forecast.method + " method on this product" }),
        Object.keys(R.sources).map(function (k) { return [h("dt", { text: k.replace(/_/g, " ") }), h("dd", { text: R.sources[k] })]; }),
        h("dt", { text: "Open orders" }), h("dd", { text: R.open_orders.length ? R.open_orders.map(function (o) { return o.po + ": " + num(o.qty) + " due " + (o.expected_day || "?"); }).join("; ") : "none" }),
        h("dt", { text: "Simulation" }), h("dd", { text: s.inputs.runs + " runs, seed " + s.inputs.seed + ", " + s.inputs.weeks + " weeks" })));
      if (s.inputs.missing.length) out.appendChild(h("div", { cls: "note", text: "Missing or weak inputs: " + s.inputs.missing.join("; ") }));
      var V = s.variants.filter(function (v) { return v.results; });
      var cols = [{ t: "", f: function (r) { return r[0]; } }].concat(V.map(function (v, i) { return { t: v.name, n: 1, f: function (r) { return r[1](v, i); } }; }));
      var rows = [
        ["Policy used", function (v) { return v.policy_used.type === "order_up_to" ? "up to " + num(v.policy_used.level) : "reorder at " + num(v.policy_used.reorder_point); }],
        ["Fill rate", function (v) { return pct(v.results.fill_rate); }],
        ["Fill rate, 5th to 95th percentile of runs", function (v) { return pct(v.results.fill_rate_p05_p95[0], 0) + " – " + pct(v.results.fill_rate_p05_p95[1], 0); }],
        ["Chance of any shortage", function (v) { return pct(v.results.probability_of_any_shortage, 0); }],
        ["Expected shortage (units)", function (v) { return num(v.results.expected_shortage_units); }],
        ["Average on hand", function (v) { return num(v.results.avg_on_hand); }],
        ["Ending stock", function (v) { return num(v.results.expected_ending_stock); }],
        ["Excess at end (beyond next 4 weeks)", function (v) { return num(v.results.expected_excess_at_end); }],
        ["Units ordered", function (v) { return num(v.results.expected_units_ordered); }],
        ["Median lead time (weeks)", function (v) { return v.results.median_lead_time_weeks; }],
        ["Average inventory value", function (v) { return v.money ? num(v.money.avg_inventory_value) : "needs unit cost"; }],
        ["Total relevant cost", function (v) { return v.money && v.money.total_relevant_cost != null ? num(v.money.total_relevant_cost) : "missing: " + (v.money_inputs_missing || []).join(", "); }],
        ["Constraints", function (v) { return v.constraints.length ? v.constraints.map(function (c) { return c.met === true ? tag(c.constraint + " met", "ok") : c.met === false ? tag(c.constraint + " not met", "bad") : tag(c.constraint + " unknown", "am"); }) : "none"; }]
      ];
      out.appendChild(table(cols, rows));
      var opt = V.filter(function (v) { return v.frontier; })[0];
      if (opt) {
        out.appendChild(h("h3", { text: "Optimisation: " + opt.optimisation.objective }));
        out.appendChild(lineChart([{ color: "#70D6C3", points: opt.frontier.map(function (t, i) { return [i, t.fill_rate * 100]; }) }, { color: "#E3B96F", points: opt.frontier.map(function (t, i) { return [i, t.avg_on_hand / Math.max.apply(null, opt.frontier.map(function (z) { return z.avg_on_hand; })) * 100]; }) }],
          { labels: opt.frontier.map(function (t) { return num(t.level); }), label: "fill rate and stock by order-up-to level", height: 220 }));
        out.appendChild(legend([["fill rate %", "#70D6C3"], ["average stock, % of the largest", "#E3B96F"]]));
      }
      out.appendChild(h("ul", { cls: "plain muted small" }, s.limitations.map(function (l) { return h("li", { text: l }); })));
      var use = h("button", { cls: "btn ghost", type: "button" }, "Start a decision record from this");
      use.addEventListener("click", function () { STATE.newDecision = { sku: s.sku, location: s.location, forecast_id: s.forecast_id, scenario_id: s.id }; go("decisions"); });
      out.appendChild(use);
    }
    list();
  };

  // ---------- decisions ----------
  VIEWS.decisions = function () {
    var m = page("Decision records", "What was known, what was recommended, what a person decided, what was done and what happened. Entries are appended, never edited, and each is chained to the one before.");
    var left = h("div"), right = h("div");
    m.appendChild(left); m.appendChild(right);
    var nd = STATE.newDecision || {};
    var title = h("input", { value: nd.sku ? "Replenishment for " + nd.sku + " at " + nd.location : "", style: "min-width:320px" }), owner = h("input", { placeholder: "name of the accountable person" });
    var fid = h("input", { value: nd.forecast_id || "", placeholder: "fc_…", cls: "mono" }), sid = h("input", { value: nd.scenario_id || "", placeholder: "scn_…", cls: "mono" });
    var opts = h("input", { value: "keep current rule, use scenario level", style: "min-width:280px" });
    var obj = h("select", {}, [["", "none"], ["no_stockout_weeks", "no weeks with zero stock"], ["min_fill_rate", "minimum fill rate"], ["max_ending_stock", "maximum ending stock"], ["max_units_ordered", "maximum units ordered"]].map(function (o) { return h("option", { value: o[0], text: o[1] }); }));
    var objt = h("input", { type: "number", step: "any", value: "0", style: "width:100px" });
    var risk = h("select", {}, ["", "low", "medium", "high"].map(function (o) { return h("option", { value: o, text: o || "not stated" }); }));
    var btn = h("button", { cls: "btn", type: "submit" }, "Open decision record");
    left.appendChild(h("details", { open: nd.sku && !STATE.decision ? true : null, cls: "card" }, h("summary", { text: "Open a new decision record" }),
      h("form", { on: { submit: function (e) {
        e.preventDefault();
        busy(btn, api("POST", "/v1/decisions", { title: title.value, owner: owner.value, sku: nd.sku || null, location: nd.location || null, forecast_ids: fid.value ? [fid.value.trim()] : [], scenario_ids: sid.value ? [sid.value.trim()] : [],
          options: opts.value.split(",").map(function (x) { return x.trim(); }).filter(Boolean).map(function (x) { return { name: x }; }),
          objective: obj.value ? { metric: obj.value, target: Number(objt.value) } : null, risk_tolerance: risk.value || null })).then(function (d) { STATE.newDecision = null; STATE.decision = d.id; go("decisions"); }).catch(function (er) { left.appendChild(errBox(er)); });
      } } }, h("div", { cls: "row" }, field("Title", title), field("Owner", owner), field("Forecast considered", fid), field("Scenario considered", sid)),
        h("div", { cls: "row" }, field("Options (comma separated)", opts), field("Objective", obj), field("Target", objt), field("Risk tolerance", risk)), h("div", { style: "margin-top:12px" }, btn))));
    var lst = h("div"); left.appendChild(lst);
    function list() {
      api("GET", "/v1/decisions?limit=100").then(function (r) {
        lst.textContent = "";
        lst.appendChild(table([{ t: "Decision", f: function (x) { return x.title; } }, { t: "Owner", f: function (x) { return x.owner; } }, { t: "Status", f: function (x) { return tag(x.state.status.replace(/_/g, " "), x.state.status === "outcome_recorded" ? "ok" : ""); } },
          { t: "Decided", f: function (x) { return x.state.decided_option || ""; } }, { t: "Opened", f: function (x) { return when(x.created_at); } }], r.items, function (x) { STATE.decision = x.id; detail(x.id); list(); }, function (x) { return x.id === STATE.decision; }));
      });
    }
    function detail(id) {
      right.textContent = ""; right.appendChild(h("p", { cls: "loading", text: "Loading…" }));
      Promise.all([api("GET", "/v1/decisions/" + id), api("GET", "/v1/decisions/" + id + "/evaluation")]).then(function (r) {
        var d = r[0], ev = r[1];
        right.textContent = "";
        right.appendChild(h("h2", { text: d.title }));
        right.appendChild(h("p", {}, tag(d.state.status.replace(/_/g, " "), "ac"), " ", ev.integrity.ok ? tag("record intact: " + ev.integrity.entries + " entries verified", "ok") : tag("record broken at entry " + ev.integrity.broken_at, "bad"),
          h("span", { cls: "muted small", text: "  owner " + d.owner + (d.sku ? " · " + d.sku + " · " + d.location : "") })));
        var tl = h("div", { cls: "timeline" });
        d.entries.forEach(function (e) {
          var p = e.payload, body;
          if (e.entry_type === "opened") body = h("div", {}, h("div", { text: "Known at " + when(p.knowledge_time) + ". Options: " + (p.options.map(function (o) { return o.name; }).join(", ") || "none") + "." }),
            p.forecasts.map(function (f) { return h("div", { cls: "small", text: "Forecast " + short(f.id) + ": " + num(f.point) + " (" + num(f.low) + " to " + num(f.high) + "), " + f.method + ", data " + f.dataset_fingerprint.slice(7, 19) }); }),
            p.scenarios.map(function (s) { return h("div", { cls: "small", text: "Scenario " + short(s.id) + ": " + s.variants.map(function (v) { return v.name + " " + pct(v.fill_rate, 0); }).join(", ") }); }),
            p.objective ? h("div", { cls: "small", text: "Objective: " + p.objective.metric + " " + p.objective.target }) : null);
          else body = h("dl", { cls: "kv small" }, Object.keys(p).filter(function (k) { return k !== "is_decision" && p[k] !== "" && p[k] != null && !(typeof p[k] === "object" && !Object.keys(p[k]).length); })
            .map(function (k) { return [h("dt", { text: k.replace(/_/g, " ") }), h("dd", { text: typeof p[k] === "object" ? JSON.stringify(p[k]) : String(p[k]) })]; }));
          tl.appendChild(h("div", { cls: "ev" }, h("div", {}, h("b", { text: e.seq + ". " + e.entry_type }), h("span", { cls: "muted small", text: "  " + when(e.recorded_at) + " · " + e.actor + " · " + e.hash.slice(0, 10) })), body));
        });
        right.appendChild(tl);
        var types = ["recommendation", "decision", "approval", "action", "outcome", "revision", "note"];
        var et = h("select", {}, types.map(function (t) { return h("option", { value: t, text: t }); }));
        var form = h("div", { cls: "row" });
        var ab = h("button", { cls: "btn", type: "submit" }, "Append entry");
        var inputs = {};
        function fieldsFor() {
          form.textContent = ""; inputs = {};
          var optsel = function () { return h("select", {}, d.entries[0].payload.options.map(function (o) { return h("option", { value: o.name, text: o.name }); })); };
          var spec = { recommendation: [["option", optsel()], ["rationale", h("input", { style: "min-width:280px" })]], decision: [["option", optsel()], ["decided_by", h("input", { value: d.owner })], ["rationale", h("input", { style: "min-width:280px" })]],
            approval: [["approved", h("select", {}, h("option", { value: "true", text: "approved" }), h("option", { value: "false", text: "not approved" }))], ["comment", h("input")]],
            action: [["description", h("input", { style: "min-width:280px" })], ["executed_on", h("input", { type: "date" })], ["quantity", h("input", { type: "number" })]],
            outcome: [["period_start", h("input", { type: "date" })], ["period_end", h("input", { type: "date" })], ["fill_rate", h("input", { type: "number", step: "0.001", placeholder: "optional" })], ["note", h("input")]],
            revision: [["reason", h("input", { style: "min-width:280px" })], ["reopen", h("select", {}, h("option", { value: "false", text: "keep decision" }), h("option", { value: "true", text: "re-open the decision" }))]], note: [["text", h("input", { style: "min-width:320px" })]] }[et.value];
          spec.forEach(function (s) { inputs[s[0]] = s[1]; form.appendChild(field(s[0].replace(/_/g, " "), s[1])); });
        }
        et.addEventListener("change", fieldsFor); fieldsFor();
        right.appendChild(h("form", { cls: "card", on: { submit: function (e) {
          e.preventDefault();
          var p = {};
          Object.keys(inputs).forEach(function (k) { var v = inputs[k].value; if (v === "") return; p[k] = (k === "quantity") ? Number(v) : (k === "approved" || k === "reopen") ? v === "true" : v; });
          if (et.value === "outcome") { p.values = p.fill_rate != null ? { fill_rate: Number(p.fill_rate) } : {}; delete p.fill_rate; }
          busy(ab, api("POST", "/v1/decisions/" + id + "/entries", { type: et.value, payload: p })).then(function () { detail(id); list(); }).catch(function (er) { right.appendChild(errBox(er)); });
        } } }, h("div", { cls: "row" }, field("Entry", et)), form, h("div", { style: "margin-top:10px" }, ab)));
        right.appendChild(h("div", { cls: "split" },
          h("div", { cls: "card" }, h("h3", { text: "Forecast quality" }), ev.forecast_quality.length ? ev.forecast_quality.map(function (f) {
            return h("p", { cls: "small" }, short(f.forecast_id) + ": estimate " + num(f.estimate) + ". ", f.actual != null ? ["Actual " + num(f.actual) + ", error " + pct(f.abs_pct_error) + ", baseline estimate " + num(f.baseline_estimate) + ". ", f.inside_range ? tag("inside range", "ok") : tag("outside range", "bad")] : f.status);
          }) : h("p", { cls: "muted small", text: "No forecasts were linked." })),
          h("div", { cls: "card" }, h("h3", { text: "Decision outcome" }), ev.decision_outcome.status ? h("p", { cls: "muted small", text: ev.decision_outcome.status }) :
            h("div", { cls: "small" }, h("p", {}, ev.decision_outcome.objective_met === true ? tag("objective met", "ok") : ev.decision_outcome.objective_met === false ? tag("objective not met", "bad") : tag("cannot judge", "am"), " ", ev.decision_outcome.explanation),
              h("dl", { cls: "kv" }, h("dt", { text: "Period" }), h("dd", { text: ev.decision_outcome.period.join(" to ") }), h("dt", { text: "Recorded sales" }), h("dd", { text: num(ev.decision_outcome.observed.recorded_sales) }),
                h("dt", { text: "Zero-stock weeks" }), h("dd", { text: ev.decision_outcome.observed.weeks_with_zero_stock_snapshot }), h("dt", { text: "Ending stock" }), h("dd", { text: num(ev.decision_outcome.observed.ending_stock) + " (" + (ev.decision_outcome.observed.ending_stock_day || "") + ")" }),
                h("dt", { text: "Action matched decision" }), h("dd", { text: ev.decision_outcome.action_matched_decision ? "yes" : "no" }))))));
        right.appendChild(h("div", { cls: "note", text: ev.caution }));
      }).catch(function (e) { right.textContent = ""; right.appendChild(errBox(e)); });
    }
    list();
    if (STATE.decision) detail(STATE.decision);
  };

  // ---------- performance ----------
  VIEWS.performance = function () {
    var m = page("Outcomes and performance", "Stored forecasts checked against what happened, once each window is complete in the data. Evaluations are appended; a corrected actual adds a new evaluation and keeps the old one.");
    var btn = h("button", { cls: "btn", type: "button" }, "Evaluate forecasts that are due");
    var msg = h("div"), out = h("div");
    btn.addEventListener("click", function () { busy(btn, api("POST", "/v1/evaluations", {})).then(function (r) { msg.textContent = ""; msg.appendChild(h("div", { cls: "note", role: "status", text: r.evaluated + " evaluated now, " + r.unchanged + " unchanged, " + r.not_yet_due + " not yet due, " + r.series_without_data + " without data." })); load(); }).catch(function (e) { msg.appendChild(errBox(e)); }); });
    m.appendChild(h("div", { cls: "card row" }, btn)); m.appendChild(msg); m.appendChild(out);
    function load() {
      api("GET", "/v1/performance").then(function (p) {
        out.textContent = "";
        var c = p.completeness;
        out.appendChild(h("div", { cls: "grid" }, [[num(c.forecasts), "stored forecasts"], [num(c.evaluated), "evaluated"], [num(c.not_yet_evaluated), "not yet evaluated"],
          [p.overall ? pct(p.overall.wape) : "n/a", "WAPE"], [p.overall ? pct(p.overall.baseline_wape) : "n/a", "baseline WAPE, same windows"], [p.overall ? sgn(p.overall.bias) : "n/a", "bias (+ = too high)"], [p.overall ? pct(p.overall.coverage, 0) : "n/a", "inside the range"]]
          .map(function (x) { return h("div", { cls: "kpi" }, h("b", { text: x[0] }), h("span", { text: x[1] })); })));
        out.appendChild(h("h2", { text: "Drift and data-quality checks" }));
        out.appendChild(p.drift.length ? table([{ t: "Check", f: function (d) { return d.check; } }, { t: "Status", f: function (d) { return d.flag ? tag("flag", "bad") : tag("ok", "ok"); } }, { t: "Values", f: function (d) { var x = Object.assign({}, d); delete x.check; delete x.flag; delete x.meaning;
            return h("span", { cls: "small", text: Object.keys(x).map(function (k) { var v = x[k];
              var txt = Array.isArray(v) ? v.map(function (y) { return pct(y); }).join(", ") : typeof v === "number" ? (k === "ratio" ? v.toFixed(2) : pct(v)) : String(v);
              return k.replace(/_/g, " ") + ": " + txt; }).join(" · ") }); } }, { t: "Meaning", f: function (d) { return d.meaning; } }], p.drift)
          : h("p", { cls: "muted", text: "Checks need at least 20 evaluated forecasts and a stored backtest." }));
        if (p.by_period.length) {
          out.appendChild(h("h2", { text: "By forecast period" }));
          out.appendChild(table([{ t: "Run", f: function (r) { return when(r.run_at); } }, { t: "Window starts", f: function (r) { return r.target_start; } }, { t: "Forecasts", n: 1, f: function (r) { return r.n; } }, { t: "WAPE", n: 1, f: function (r) { return pct(r.wape); } }, { t: "Baseline WAPE", n: 1, f: function (r) { return pct(r.baseline_wape); } }, { t: "Bias", n: 1, f: function (r) { return sgn(r.bias); } }, { t: "Inside range", n: 1, f: function (r) { return pct(r.coverage, 0); } }], p.by_period));
          out.appendChild(h("h3", { text: "By weeks ahead" }));
          out.appendChild(table([{ t: "Week ahead", f: function (k) { return k; } }, { t: "MAE", n: 1, f: function (k) { return num(p.by_horizon_week[k].mae, 1); } }, { t: "WAPE", n: 1, f: function (k) { return pct(p.by_horizon_week[k].wape); } }], Object.keys(p.by_horizon_week)));
          out.appendChild(h("h3", { text: "By category" }));
          out.appendChild(table([{ t: "Category", f: function (k) { return k; } }, { t: "Forecasts", n: 1, f: function (k) { return p.by_category[k].n; } }, { t: "WAPE", n: 1, f: function (k) { return pct(p.by_category[k].wape); } }, { t: "Baseline", n: 1, f: function (k) { return pct(p.by_category[k].baseline_wape); } }, { t: "Bias", n: 1, f: function (k) { return sgn(p.by_category[k].bias); } }, { t: "Inside range", n: 1, f: function (k) { return pct(p.by_category[k].coverage, 0); } }], Object.keys(p.by_category)));
        }
        out.appendChild(h("ul", { cls: "plain muted small" }, p.notes.map(function (n) { return h("li", { text: n }); })));
      }).catch(function (e) { out.appendChild(errBox(e)); });
    }
    load();
  };

  // ---------- audit and access ----------
  VIEWS.audit = function () {
    var m = page("Audit log", "Every write: who, what, when, which object. No data values and no secrets are logged.");
    if (ME.role !== "admin") { m.appendChild(h("p", { cls: "muted", text: "The audit log needs an admin key." })); return; }
    api("GET", "/v1/audit?limit=200").then(function (r) {
      m.appendChild(table([{ t: "When", f: function (x) { return when(x.at); } }, { t: "Actor", f: function (x) { return x.actor; } }, { t: "Action", f: function (x) { return x.action; } }, { t: "Object", f: function (x) { return (x.object_type || "") + " " + short(x.object_id); } }, { t: "Detail", f: function (x) { return h("span", { cls: "mono small", text: JSON.stringify(x.detail).slice(0, 140) }); } }], r.items));
    }).catch(function (e) { m.appendChild(errBox(e)); });
  };
  VIEWS.access = function () {
    var m = page("Access", "Keys belong to this organisation only. Roles: viewer reads, analyst imports and analyses, admin manages keys, approvals and model promotion.");
    if (ME.role !== "admin") { m.appendChild(h("p", { cls: "muted", text: "Managing keys needs an admin key." })); return; }
    var out = h("div"), lst = h("div");
    var role = h("select", {}, ["viewer", "analyst", "admin"].map(function (r) { return h("option", { value: r, text: r }); })), label = h("input", { placeholder: "who or what uses it" });
    var btn = h("button", { cls: "btn", type: "submit" }, "Create key");
    m.appendChild(h("form", { cls: "card row", on: { submit: function (e) { e.preventDefault(); busy(btn, api("POST", "/v1/keys", { role: role.value, label: label.value })).then(function (k) { out.textContent = ""; out.appendChild(h("div", { cls: "note", role: "status" }, "New " + k.role + " key. Copy it now; it is not shown again: ", h("span", { cls: "mono", text: k.key }))); load(); }).catch(function (er) { out.appendChild(errBox(er)); }); } } },
      field("Role", role), field("Label", label), btn));
    m.appendChild(out); m.appendChild(lst);
    function load() {
      api("GET", "/v1/keys").then(function (r) {
        lst.textContent = "";
        lst.appendChild(table([{ t: "Key id", f: function (k) { return h("span", { cls: "mono", text: k.id }); } }, { t: "Role", f: function (k) { return k.role; } }, { t: "Label", f: function (k) { return k.label; } }, { t: "Created", f: function (k) { return when(k.created_at); } },
          { t: "Status", f: function (k) { if (k.revoked_at) return tag("revoked", "bad"); if (k.id === ME.key_id) return tag("this key", "ac"); var b = h("button", { cls: "btn warn", type: "button" }, "Revoke"); b.addEventListener("click", function () { busy(b, api("DELETE", "/v1/keys/" + k.id)).then(load); }); return b; } }], r.items));
      });
    }
    load();
  };

  window.addEventListener("hashchange", function () { var v = location.hash.slice(1); if (ME && VIEWS[v] && v !== VIEW) go(v); });

  // ---------- start ----------
  if (KEY) {
    api("GET", "/v1/me").then(function (me) { ME = me; go(location.hash.slice(1) || "overview"); }).catch(function () { KEY = null; login("Your saved key no longer works. Sign in again."); });
  } else login();
})();
