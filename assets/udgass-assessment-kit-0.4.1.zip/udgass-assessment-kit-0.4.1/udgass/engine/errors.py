"""Typed errors. Every layer raises these; the API maps them to one response shape."""


class UdgassError(Exception):
    status = 400
    code = "invalid_request"

    def __init__(self, message, code=None, details=None):
        super().__init__(message)
        self.message = message
        if code:
            self.code = code
        self.details = details or {}


class Invalid(UdgassError):
    status, code = 400, "invalid_request"


class Unauthorized(UdgassError):
    status, code = 401, "unauthorized"


class Forbidden(UdgassError):
    status, code = 403, "forbidden"


class NotFound(UdgassError):
    status, code = 404, "not_found"


class Conflict(UdgassError):
    status, code = 409, "conflict"


class TooLarge(UdgassError):
    status, code = 413, "too_large"


class RateLimited(UdgassError):
    status, code = 429, "rate_limited"


class InsufficientData(UdgassError):
    status, code = 422, "insufficient_data"


class MethodNotAllowed(UdgassError):
    status, code = 405, "method_not_allowed"
