"""Organisations, API keys and roles. The organisation of every request comes from the authenticated key,
never from anything the caller sends. Keys are random 256-bit secrets, stored only as SHA-256 hashes."""
from __future__ import annotations
import hashlib, hmac, secrets
from dataclasses import dataclass
from .db import new_id, ts
from .errors import Forbidden, Invalid, NotFound, Unauthorized
from . import audit

ROLES = {"viewer": 1, "analyst": 2, "admin": 3}
PREFIX = "udg_"


@dataclass(frozen=True)
class Principal:
    org_id: str
    key_id: str
    role: str

    @property
    def actor(self):
        return "key:" + self.key_id


def _hash(key):
    return hashlib.sha256(key.encode()).hexdigest()


def require(p: Principal, role: str):
    if ROLES[p.role] < ROLES[role]:
        raise Forbidden("this action needs the %s role; this key has %s" % (role, p.role))


def create_org(store, name, now=None):
    """Bootstrap: creates an organisation with its first admin key. Returns (org_id, plaintext_key) once."""
    name = (name or "").strip()
    if not 1 <= len(name) <= 120:
        raise Invalid("organisation name must be 1 to 120 characters")
    org = new_id("org")
    with store.tx() as c:
        c.execute("INSERT INTO organizations VALUES(?,?,?)", (org, name, ts(now)))
        key, kid = _insert_key(c, org, "admin", "bootstrap admin", now)
        from .forecasting import ensure_default_policy
        ensure_default_policy(c, org, "system", now)
        audit.record(c, org, "system", "org.create", "organization", org, detail={"name": name, "first_key": kid})
    return org, key


def _insert_key(c, org, role, label, now=None):
    if role not in ROLES:
        raise Invalid("role must be one of %s" % ", ".join(ROLES))
    key = PREFIX + secrets.token_urlsafe(32)
    kid = new_id("key")
    c.execute("INSERT INTO api_keys(id,org_id,key_hash,role,label,created_at) VALUES(?,?,?,?,?,?)",
              (kid, org, _hash(key), role, (label or "")[:120], ts(now)))
    return key, kid


def create_key(store, p: Principal, role, label="", request_id=None):
    require(p, "admin")
    with store.tx() as c:
        key, kid = _insert_key(c, p.org_id, role, label)
        audit.record(c, p.org_id, p.actor, "key.create", "api_key", kid, request_id, {"role": role, "label": label})
    return {"id": kid, "role": role, "key": key, "note": "Shown once. Store it in a secrets manager."}


def revoke_key(store, p: Principal, key_id, request_id=None):
    require(p, "admin")
    with store.tx() as c:
        n = c.execute("UPDATE api_keys SET revoked_at=? WHERE id=? AND org_id=? AND revoked_at IS NULL", (ts(), key_id, p.org_id)).rowcount
        if not n:
            raise NotFound("no active key %s in this organisation" % key_id)
        audit.record(c, p.org_id, p.actor, "key.revoke", "api_key", key_id, request_id)
    return {"id": key_id, "revoked": True}


def list_keys(store, p: Principal):
    require(p, "admin")
    rows = store.conn().execute("SELECT id, role, label, created_at, revoked_at FROM api_keys WHERE org_id=? ORDER BY created_at", (p.org_id,))
    return [dict(r) for r in rows]


def authenticate(store, key) -> Principal:
    if not key or not key.startswith(PREFIX) or len(key) > 200:
        raise Unauthorized("missing or malformed API key")
    h = _hash(key)
    r = store.conn().execute("SELECT id, org_id, role, revoked_at, key_hash FROM api_keys WHERE key_hash=?", (h,)).fetchone()
    if r is None or r["revoked_at"] or not hmac.compare_digest(r["key_hash"], h):
        raise Unauthorized("unknown or revoked API key")
    return Principal(r["org_id"], r["id"], r["role"])


def org_info(store, p: Principal):
    r = store.conn().execute("SELECT id, name, created_at FROM organizations WHERE id=?", (p.org_id,)).fetchone()
    return {**dict(r), "key_id": p.key_id, "role": p.role}
