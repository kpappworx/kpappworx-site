"""Storage: SQLite (standard library), versioned migrations, immutability enforced in the database itself.

Why SQLite: no server to run or pay for, transactional, and enough for one organisation's demand history on one
machine. The module boundary (all SQL lives in engine modules, nothing in the API) keeps a later move to Postgres
contained. Limits are documented in ARCHITECTURE.md.
"""
from __future__ import annotations
import json, os, sqlite3, threading, uuid
from contextlib import contextmanager
from datetime import datetime, timezone

SCHEMA_VERSION = 1

_IMMUTABLE = ["forecast_runs", "forecasts", "forecast_evaluations", "backtests", "findings", "scenarios",
              "decision_log", "audit_log", "decisions"]
_OBS = {"demand": ["quantity"], "inventory": ["on_hand"], "purchase_orders": ["quantity"], "events": ["event_type"]}

MIGRATIONS = {1: """
CREATE TABLE organizations(id TEXT PRIMARY KEY, name TEXT NOT NULL, created_at TEXT NOT NULL);
CREATE TABLE api_keys(id TEXT PRIMARY KEY, org_id TEXT NOT NULL REFERENCES organizations(id), key_hash TEXT NOT NULL UNIQUE,
  role TEXT NOT NULL CHECK(role IN ('viewer','analyst','admin')), label TEXT, created_at TEXT NOT NULL, revoked_at TEXT);
CREATE TABLE data_sources(id TEXT PRIMARY KEY, org_id TEXT NOT NULL, name TEXT NOT NULL, kind TEXT NOT NULL, created_at TEXT NOT NULL,
  UNIQUE(org_id, name));
CREATE TABLE imports(id TEXT PRIMARY KEY, org_id TEXT NOT NULL, source_name TEXT NOT NULL, dataset_kind TEXT NOT NULL,
  file_name TEXT, file_sha256 TEXT NOT NULL, file_bytes INTEGER NOT NULL, mapping_json TEXT, options_json TEXT,
  status TEXT NOT NULL CHECK(status IN ('previewed','committed','failed','expired')),
  report_json TEXT, created_at TEXT NOT NULL, created_by TEXT NOT NULL, committed_at TEXT, error TEXT);
CREATE INDEX imports_org ON imports(org_id, created_at);
CREATE TABLE products(org_id TEXT NOT NULL, sku TEXT NOT NULL, category TEXT, unit TEXT, created_at TEXT NOT NULL,
  PRIMARY KEY(org_id, sku));
CREATE TABLE locations(org_id TEXT NOT NULL, code TEXT NOT NULL, created_at TEXT NOT NULL, PRIMARY KEY(org_id, code));
CREATE TABLE suppliers(org_id TEXT NOT NULL, code TEXT NOT NULL, created_at TEXT NOT NULL, PRIMARY KEY(org_id, code));

CREATE TABLE demand(id INTEGER PRIMARY KEY, org_id TEXT NOT NULL, source_id TEXT NOT NULL, record_key TEXT NOT NULL,
  sku TEXT NOT NULL, location TEXT NOT NULL, day TEXT NOT NULL, quantity REAL NOT NULL,
  row_hash TEXT NOT NULL, import_id TEXT NOT NULL, source_row INTEGER, recorded_at TEXT NOT NULL, superseded_at TEXT);
CREATE UNIQUE INDEX demand_current ON demand(org_id, source_id, record_key) WHERE superseded_at IS NULL;
CREATE INDEX demand_series ON demand(org_id, sku, location, day);

CREATE TABLE inventory(id INTEGER PRIMARY KEY, org_id TEXT NOT NULL, source_id TEXT NOT NULL, record_key TEXT NOT NULL,
  sku TEXT NOT NULL, location TEXT NOT NULL, day TEXT NOT NULL, on_hand REAL NOT NULL,
  row_hash TEXT NOT NULL, import_id TEXT NOT NULL, source_row INTEGER, recorded_at TEXT NOT NULL, superseded_at TEXT);
CREATE UNIQUE INDEX inventory_current ON inventory(org_id, source_id, record_key) WHERE superseded_at IS NULL;
CREATE INDEX inventory_series ON inventory(org_id, sku, location, day);

CREATE TABLE purchase_orders(id INTEGER PRIMARY KEY, org_id TEXT NOT NULL, source_id TEXT NOT NULL, record_key TEXT NOT NULL,
  po_number TEXT NOT NULL, sku TEXT NOT NULL, location TEXT NOT NULL, supplier TEXT, order_day TEXT NOT NULL,
  expected_day TEXT, received_day TEXT, quantity REAL NOT NULL, unit_cost REAL,
  row_hash TEXT NOT NULL, import_id TEXT NOT NULL, source_row INTEGER, recorded_at TEXT NOT NULL, superseded_at TEXT);
CREATE UNIQUE INDEX po_current ON purchase_orders(org_id, source_id, record_key) WHERE superseded_at IS NULL;
CREATE INDEX po_sku ON purchase_orders(org_id, sku, order_day);

CREATE TABLE events(id INTEGER PRIMARY KEY, org_id TEXT NOT NULL, source_id TEXT NOT NULL, record_key TEXT NOT NULL,
  event_type TEXT NOT NULL, sku TEXT, location TEXT, start_day TEXT NOT NULL, end_day TEXT NOT NULL, description TEXT,
  row_hash TEXT NOT NULL, import_id TEXT NOT NULL, source_row INTEGER, recorded_at TEXT NOT NULL, superseded_at TEXT);
CREATE UNIQUE INDEX events_current ON events(org_id, source_id, record_key) WHERE superseded_at IS NULL;

CREATE TABLE policies(id TEXT PRIMARY KEY, org_id TEXT NOT NULL, name TEXT NOT NULL, methods_json TEXT NOT NULL,
  created_at TEXT NOT NULL, created_by TEXT NOT NULL);
CREATE TABLE policy_log(id INTEGER PRIMARY KEY, org_id TEXT NOT NULL, policy_id TEXT NOT NULL, action TEXT NOT NULL,
  at TEXT NOT NULL, actor TEXT NOT NULL, evidence_json TEXT);

CREATE TABLE forecast_runs(id TEXT PRIMARY KEY, org_id TEXT NOT NULL, created_at TEXT NOT NULL, created_by TEXT NOT NULL,
  engine_version TEXT NOT NULL, policy_id TEXT NOT NULL, knowledge_time TEXT NOT NULL, data_cutoff_day TEXT NOT NULL,
  dataset_fingerprint TEXT NOT NULL, horizon_weeks INTEGER NOT NULL, level REAL NOT NULL, params_json TEXT NOT NULL,
  summary_json TEXT NOT NULL);
CREATE INDEX runs_org ON forecast_runs(org_id, created_at);
CREATE TABLE forecasts(id TEXT PRIMARY KEY, run_id TEXT NOT NULL REFERENCES forecast_runs(id), org_id TEXT NOT NULL,
  sku TEXT NOT NULL, location TEXT NOT NULL, origin_week TEXT NOT NULL, target_start TEXT NOT NULL, target_end TEXT NOT NULL,
  horizon_weeks INTEGER NOT NULL, point REAL NOT NULL, low REAL NOT NULL, high REAL NOT NULL, level REAL NOT NULL,
  method TEXT NOT NULL, evidence_n INTEGER NOT NULL, evidence_quality TEXT NOT NULL, weekly_json TEXT NOT NULL,
  history_weeks INTEGER NOT NULL, notes_json TEXT NOT NULL);
CREATE INDEX forecasts_series ON forecasts(org_id, sku, location, target_start);
CREATE TABLE forecast_evaluations(id INTEGER PRIMARY KEY, org_id TEXT NOT NULL, forecast_id TEXT NOT NULL,
  evaluated_at TEXT NOT NULL, knowledge_time TEXT NOT NULL, actual REAL NOT NULL, weekly_actual_json TEXT NOT NULL,
  error REAL NOT NULL, inside INTEGER NOT NULL, baseline REAL, notes_json TEXT NOT NULL);
CREATE INDEX evals_fc ON forecast_evaluations(org_id, forecast_id, evaluated_at);

CREATE TABLE backtests(id TEXT PRIMARY KEY, org_id TEXT NOT NULL, created_at TEXT NOT NULL, created_by TEXT NOT NULL,
  engine_version TEXT NOT NULL, knowledge_time TEXT NOT NULL, data_cutoff_day TEXT NOT NULL, dataset_fingerprint TEXT NOT NULL,
  params_json TEXT NOT NULL, results_json TEXT NOT NULL);
CREATE TABLE findings(id TEXT PRIMARY KEY, org_id TEXT NOT NULL, created_at TEXT NOT NULL, run_id TEXT NOT NULL, kind TEXT NOT NULL,
  sku TEXT, location TEXT, period_start TEXT, period_end TEXT, observation TEXT NOT NULL, evidence_json TEXT NOT NULL,
  method TEXT NOT NULL, assumptions_json TEXT NOT NULL, limitations_json TEXT NOT NULL, uncertainty_json TEXT,
  validated INTEGER NOT NULL DEFAULT 0, severity REAL NOT NULL DEFAULT 0, knowledge_time TEXT NOT NULL,
  dataset_fingerprint TEXT NOT NULL);
CREATE INDEX findings_org ON findings(org_id, run_id);
CREATE TABLE scenarios(id TEXT PRIMARY KEY, org_id TEXT NOT NULL, created_at TEXT NOT NULL, created_by TEXT NOT NULL,
  name TEXT NOT NULL, sku TEXT NOT NULL, location TEXT NOT NULL, forecast_id TEXT NOT NULL, engine_version TEXT NOT NULL,
  knowledge_time TEXT NOT NULL, inputs_json TEXT NOT NULL, results_json TEXT NOT NULL);
CREATE TABLE decisions(id TEXT PRIMARY KEY, org_id TEXT NOT NULL, created_at TEXT NOT NULL, created_by TEXT NOT NULL,
  decision_type TEXT NOT NULL, title TEXT NOT NULL, owner TEXT NOT NULL, sku TEXT, location TEXT);
CREATE TABLE decision_log(id INTEGER PRIMARY KEY, org_id TEXT NOT NULL, decision_id TEXT NOT NULL, seq INTEGER NOT NULL,
  entry_type TEXT NOT NULL, actor TEXT NOT NULL, recorded_at TEXT NOT NULL, payload_json TEXT NOT NULL,
  prev_hash TEXT NOT NULL, hash TEXT NOT NULL, UNIQUE(org_id, decision_id, seq));
CREATE TABLE audit_log(id INTEGER PRIMARY KEY, org_id TEXT NOT NULL, at TEXT NOT NULL, actor TEXT NOT NULL, action TEXT NOT NULL,
  object_type TEXT, object_id TEXT, request_id TEXT, detail_json TEXT);
CREATE INDEX audit_org ON audit_log(org_id, id);
CREATE TABLE idempotency(org_id TEXT NOT NULL, key TEXT NOT NULL, endpoint TEXT NOT NULL, response_json TEXT NOT NULL,
  status INTEGER NOT NULL, created_at TEXT NOT NULL, PRIMARY KEY(org_id, key));
CREATE TABLE purge_lock(org_id TEXT PRIMARY KEY);
CREATE TABLE purges(id INTEGER PRIMARY KEY, org_id TEXT NOT NULL, at TEXT NOT NULL, actor TEXT NOT NULL, counts_json TEXT NOT NULL);
"""}


def _triggers():
    sql = []
    for t in _IMMUTABLE:
        sql.append("CREATE TRIGGER %s_no_update BEFORE UPDATE ON %s BEGIN SELECT RAISE(ABORT,'%s is append-only'); END;" % (t, t, t))
        sql.append("CREATE TRIGGER %s_no_delete BEFORE DELETE ON %s WHEN NOT EXISTS(SELECT 1 FROM purge_lock WHERE org_id=OLD.org_id) "
                   "BEGIN SELECT RAISE(ABORT,'%s is append-only'); END;" % (t, t, t))
    for t in _OBS:
        # an observation may only ever be marked superseded once; its content is fixed
        sql.append("CREATE TRIGGER %s_fixed BEFORE UPDATE ON %s WHEN OLD.superseded_at IS NOT NULL OR NEW.row_hash IS NOT OLD.row_hash "
                   "OR NEW.record_key IS NOT OLD.record_key OR NEW.recorded_at IS NOT OLD.recorded_at OR NEW.org_id IS NOT OLD.org_id "
                   "BEGIN SELECT RAISE(ABORT,'observations are immutable; corrections are new rows'); END;" % (t, t))
        sql.append("CREATE TRIGGER %s_no_delete BEFORE DELETE ON %s WHEN NOT EXISTS(SELECT 1 FROM purge_lock WHERE org_id=OLD.org_id) "
                   "BEGIN SELECT RAISE(ABORT,'observations are never deleted outside a purge'); END;" % (t, t))
    return "\n".join(sql)


def utcnow():
    return datetime.now(timezone.utc)


def ts(dt=None):
    return (dt or utcnow()).astimezone(timezone.utc).isoformat(timespec="microseconds")


def new_id(prefix):
    return "%s_%s" % (prefix, uuid.uuid4().hex[:20])


def dumps(x):
    return json.dumps(x, sort_keys=True, separators=(",", ":"), default=str)


class Store:
    """Owns the database path. Each thread gets its own connection; writes run in explicit transactions."""

    def __init__(self, path, data_dir=None):
        self.path = path
        self.data_dir = data_dir or (os.path.dirname(os.path.abspath(path)) if path != ":memory:" else None)
        self._local = threading.local()
        self._lock = threading.Lock()
        self.migrate()

    def conn(self):
        c = getattr(self._local, "c", None)
        if c is None:
            c = sqlite3.connect(self.path, timeout=30, isolation_level=None, check_same_thread=False)
            c.row_factory = sqlite3.Row
            c.execute("PRAGMA foreign_keys=ON")
            c.execute("PRAGMA busy_timeout=30000")
            if self.path != ":memory:":
                c.execute("PRAGMA journal_mode=WAL")
                c.execute("PRAGMA synchronous=NORMAL")
            self._local.c = c
        return c

    @contextmanager
    def tx(self):
        c = self.conn()
        if c.in_transaction:            # nested use joins the outer transaction
            yield c
            return
        c.execute("BEGIN IMMEDIATE")
        try:
            yield c
        except BaseException:
            c.execute("ROLLBACK")
            raise
        else:
            c.execute("COMMIT")

    def migrate(self):
        with self._lock:
            c = self.conn()
            c.execute("CREATE TABLE IF NOT EXISTS schema_migrations(version INTEGER PRIMARY KEY, applied_at TEXT NOT NULL)")
            have = {r[0] for r in c.execute("SELECT version FROM schema_migrations")}
            for v in sorted(MIGRATIONS):
                if v in have:
                    continue
                script = MIGRATIONS[v] + ("\n" + _triggers() if v == 1 else "")
                try:
                    c.executescript("BEGIN IMMEDIATE;\n%s\nINSERT INTO schema_migrations VALUES(%d,'%s');\nCOMMIT;" % (script, v, ts()))
                except BaseException:
                    if c.in_transaction:
                        c.execute("ROLLBACK")
                    raise

    def version(self):
        return self.conn().execute("SELECT MAX(version) FROM schema_migrations").fetchone()[0]
