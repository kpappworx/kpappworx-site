"""The first end-to-end workflow, on SYNTHETIC data, against a real database. Used by `udgass demo-workflow` and the tests.

import history -> quality -> patterns -> forecast run -> backtest vs baselines -> scenarios -> decision record ->
action -> import what happened next -> evaluate forecasts -> record outcome -> evaluate the decision -> verify integrity.
"""
from __future__ import annotations
import os
from . import decisions, evaluation, forecasting, ingest, patterns, scenarios, synthetic, tenancy
from .db import Store

FILES = [("sales", "sales.csv"), ("inventory", "inventory.csv"), ("purchase_orders", "purchase_orders.csv"), ("events", "events.csv")]
LATER = [("sales", "sales_later.csv"), ("inventory", "inventory_later.csv"), ("purchase_orders", "purchase_orders_later.csv")]


def _import(store, p, d, kind, name):
    with open(os.path.join(d, name), "rb") as fh:
        path = ingest.stage_bytes(store, fh.read())
    pv = ingest.preview(store, p, kind, "synthetic-erp", path, name)
    if not pv["ready"]:
        raise RuntimeError("synthetic import not ready: %s" % pv["report"])
    r = ingest.commit(store, p, pv["import_id"])
    return {"file": name, "rows": pv["report"]["rows_read"], "rejected": pv["report"]["rows_rejected"], **r["counts"]}


def run_demo(db_path, data_dir, sku="M-1001", location="P-BLR", seed=7, say=print):
    truth = synthetic.generate(data_dir, seed)
    store = Store(db_path)
    org, key = tenancy.create_org(store, "Synthetic Demo Co (SYNTHETIC DATA)")
    p = tenancy.authenticate(store, key)
    out = {"org_id": org, "api_key": key, "answer_key": truth, "imports": []}
    say("SYNTHETIC DATA. Results below are not customer results.")
    for kind, f in FILES:
        out["imports"].append(_import(store, p, data_dir, kind, f))
        say("imported %(file)s: %(rows)d rows, %(rejected)d rejected, %(new)d new" % out["imports"][-1])
    pt = patterns.run(store, p)
    out["findings"] = pt["counts"]
    say("findings: %s" % pt["counts"])
    run = forecasting.create_run(store, p)
    out["forecast_run"] = run["id"]
    say("forecast run %s: %d forecasts, data cutoff %s, fingerprint %s" % (run["id"], run["summary"]["forecasts"], run["data_cutoff_day"], run["dataset_fingerprint"][:19]))
    bt = forecasting.run_backtest(store, p)
    out["backtest"] = {"id": bt["id"], "leaderboard_test": forecasting.leaderboard(bt, "test")}
    for r in out["backtest"]["leaderboard_test"]:
        say("  backtest (test half) %-28s WAPE %5.1f%%  bias %+5.1f%%%s" % (r["model"], r["wape"] * 100, r["bias"] * 100,
            "  coverage %.0f%%" % (r["coverage"] * 100) if r["coverage"] is not None else ""))
    fc = forecasting.list_forecasts(store, p, run["id"], sku)["items"]
    fc = next(f for f in fc if f["location"] == location)
    costs = {"holding_rate_per_year": 0.25, "shortage_cost_per_unit": 40, "order_cost": 50}
    sc = scenarios.create(store, p, sku, location, "Next quarter", fc["id"], costs=costs, constraints={"min_fill_rate": 0.95},
                          variants=[{"name": "demand +20%", "assumptions": {"demand_multiplier": 1.2}},
                                    {"name": "vendor 3 weeks late", "assumptions": {"lead_time_delay_weeks": 3}},
                                    {"name": "stock 30% below record", "assumptions": {"stock_adjustment_pct": -30}}])
    opt = scenarios.create(store, p, sku, location, "Cost-optimal level", fc["id"], policy={"type": "optimise"}, costs=costs,
                           constraints={"min_fill_rate": 0.95})
    for v in sc["variants"]:
        say("  scenario %-24s fill rate %.1f%%  avg stock %.0f" % (v["name"], v["results"]["fill_rate"] * 100, v["results"]["avg_on_hand"]))
    lvl = opt["variants"][0]["policy_used"]["level"]
    say("  optimised order-up-to level under stated costs: %.0f" % lvl)
    d = decisions.create(store, p, "Replenishment policy for %s at %s" % (sku, location), "Demo planner", sku=sku, location=location,
                         forecast_ids=[fc["id"]], scenario_ids=[sc["id"], opt["id"]],
                         options=[{"name": "keep current rule"}, {"name": "use optimised level", "description": "order up to %.0f" % lvl}],
                         objective={"metric": "no_stockout_weeks", "target": 0}, risk_tolerance="low",
                         assumptions={"costs": costs}, constraints={"min_fill_rate": 0.95})
    decisions.add_entry(store, p, d["id"], "recommendation", {"option": "use optimised level", "rationale": "lowest expected cost meeting 95% fill rate in the model",
                                                             "source": "scenario", "scenario_id": opt["id"]})
    decisions.add_entry(store, p, d["id"], "decision", {"option": "use optimised level", "decided_by": "Demo planner", "rationale": "accepted the model's level"})
    decisions.add_entry(store, p, d["id"], "action", {"description": "Order-up-to level set to %.0f in the planning sheet" % lvl, "executed_on": "2025-12-29"})
    for kind, f in LATER:
        out["imports"].append(_import(store, p, data_dir, kind, f))
        say("imported later data %(file)s: %(new)d new, %(corrections)d corrections" % out["imports"][-1])
    out["evaluation"] = evaluation.evaluate_due(store, p)
    perf = evaluation.performance(store, p)
    out["performance"] = {"overall": perf["overall"], "drift_flags": [x["check"] for x in perf["drift"] if x["flag"]]}
    o = perf["overall"]
    say("live forecasts evaluated: %d, WAPE %.1f%% vs baseline %.1f%%, coverage %.0f%%" % (o["n"], o["wape"] * 100, o["baseline_wape"] * 100, o["coverage"] * 100))
    decisions.add_entry(store, p, d["id"], "outcome", {"period_start": "2025-12-29", "period_end": "2026-03-22", "values": {}})
    ev = decisions.evaluate(store, p, d["id"])
    out["decision"] = {"id": d["id"], "objective_met": ev["decision_outcome"].get("objective_met"), "integrity": ev["integrity"]}
    say("decision %s: objective met = %s, record intact = %s" % (d["id"], out["decision"]["objective_met"], ev["integrity"]["ok"]))
    out["reconstruct"] = forecasting.reconstruct(store, p, fc["id"])
    say("forecast %s rebuilt from what was known then: %s" % (fc["id"], out["reconstruct"]["matches"]))
    return out
