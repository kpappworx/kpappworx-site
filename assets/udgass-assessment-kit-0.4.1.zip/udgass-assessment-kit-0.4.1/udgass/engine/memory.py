"""Organisational memory: what was known at a given time.

Every observation has an event time (the day it describes) and a knowledge time (recorded_at: when Udgass learned it).
A correction never overwrites: the old row gets superseded_at, the new row is added. So the state of knowledge at any
time T is exactly: rows with recorded_at <= T that were not yet superseded at T.
"""
from __future__ import annotations
import hashlib
from datetime import date, timedelta
from .db import ts, utcnow
from .errors import InsufficientData, NotFound


def known(alias=""):
    a = alias + "." if alias else ""
    return "%srecorded_at <= :kt AND (%ssuperseded_at IS NULL OR %ssuperseded_at > :kt)" % (a, a, a)


def monday(d):
    return d - timedelta(days=d.weekday())


def kt_str(knowledge_time):
    if knowledge_time is None:
        return ts(utcnow())
    return knowledge_time if isinstance(knowledge_time, str) else ts(knowledge_time)


def _filters(org, kt, through, skus, locations):
    q = " WHERE org_id=:org AND " + known()
    args = {"org": org, "kt": kt}
    if through:
        q += " AND day <= :through"; args["through"] = through.isoformat() if isinstance(through, date) else through
    if skus:
        q += " AND sku IN (%s)" % ",".join(":s%d" % i for i in range(len(skus)))
        args.update({"s%d" % i: s for i, s in enumerate(skus)})
    if locations:
        q += " AND location IN (%s)" % ",".join(":l%d" % i for i in range(len(locations)))
        args.update({"l%d" % i: s for i, s in enumerate(locations)})
    return q, args


def data_cutoff(store, org, knowledge_time=None, through=None):
    """Last day of demand data visible at the knowledge time (and not after `through`)."""
    kt = kt_str(knowledge_time)
    q, a = _filters(org, kt, through, None, None)
    r = store.conn().execute("SELECT MAX(day) FROM demand" + q, a).fetchone()[0]
    return date.fromisoformat(r) if r else None


def weekly_demand(store, org, knowledge_time=None, through=None, skus=None, locations=None, by_location=True):
    """Weekly (Monday-start) demand per series, using only complete weeks up to the data cutoff.
    Returns dict: series {(sku, loc): [qty...]}, start {(sku,loc): monday}, last_week, cutoff_day, gaps {(sku,loc): n_weeks_without_rows}."""
    kt = kt_str(knowledge_time)
    cutoff = data_cutoff(store, org, kt, through)
    if cutoff is None:
        raise InsufficientData("no demand data is known at this time")
    last_week = monday(cutoff) if cutoff.weekday() == 6 else monday(cutoff) - timedelta(weeks=1)   # last complete week
    q, a = _filters(org, kt, last_week + timedelta(days=6), skus, locations)
    loc_expr = "location" if by_location else "'ALL'"
    rows = store.conn().execute("SELECT sku, %s AS loc, day, SUM(quantity) AS q FROM demand%s GROUP BY sku, loc, day" % (loc_expr, q), a)
    agg = {}
    for r in rows:
        k = (r["sku"], r["loc"])
        w = monday(date.fromisoformat(r["day"]))
        d = agg.setdefault(k, {})
        d[w] = d.get(w, 0.0) + r["q"]
    series, start, gaps, negative = {}, {}, {}, {}
    for k, d in agg.items():
        w0 = min(d)
        n = (last_week - w0).days // 7 + 1
        if n <= 0:
            continue
        vals = [d.get(w0 + timedelta(weeks=i), None) for i in range(n)]
        gaps[k] = sum(v is None for v in vals)
        neg = sum(1 for v in vals if v is not None and v < 0)
        if neg:
            negative[k] = neg                 # returns exceeded sales in a week: shown as zero demand, and reported
        series[k] = [max(v, 0.0) if v is not None else 0.0 for v in vals]
        start[k] = w0
    return {"series": series, "start": start, "last_week": last_week, "cutoff_day": cutoff, "gaps": gaps, "knowledge_time": kt,
            "negative_weeks": negative}


def fingerprint(store, org, knowledge_time=None, through=None, skus=None, locations=None):
    """SHA-256 over every demand record visible at the knowledge time. Same knowledge, same fingerprint."""
    kt = kt_str(knowledge_time)
    q, a = _filters(org, kt, through, skus, locations)
    h = hashlib.sha256()
    n = 0
    for r in store.conn().execute("SELECT source_id, record_key, row_hash FROM demand%s ORDER BY source_id, record_key" % q, a):
        h.update(("%s|%s|%s\n" % (r[0], r[1], r[2])).encode()); n += 1
    return "sha256:" + h.hexdigest(), n


def inventory_position(store, org, sku, location, on_or_before, knowledge_time=None):
    """Latest on-hand snapshot at or before a day, as known. None if there is none."""
    kt = kt_str(knowledge_time)
    loc_q = "" if location in (None, "ALL") else " AND location=:loc"
    r = store.conn().execute(
        "SELECT day, SUM(on_hand) AS oh FROM inventory WHERE org_id=:org AND sku=:sku%s AND day<=:d AND %s "
        "GROUP BY day ORDER BY day DESC LIMIT 1" % (loc_q, known()),
        {"org": org, "sku": sku, "loc": location, "d": on_or_before.isoformat(), "kt": kt}).fetchone()
    return (date.fromisoformat(r["day"]), r["oh"]) if r else None


def stockout_weeks(store, org, sku, location, knowledge_time=None):
    """Mondays of weeks in which a zero on-hand snapshot was recorded. Sales in those weeks may understate demand."""
    kt = kt_str(knowledge_time)
    loc_q = "" if location in (None, "ALL") else " AND location=:loc"
    rows = store.conn().execute("SELECT DISTINCT day FROM inventory WHERE org_id=:org AND sku=:sku%s AND on_hand<=0 AND %s" % (loc_q, known()),
                                {"org": org, "sku": sku, "loc": location, "kt": kt})
    return sorted({monday(date.fromisoformat(r[0])) for r in rows})


def purchase_orders(store, org, sku=None, location=None, knowledge_time=None):
    kt = kt_str(knowledge_time)
    q = "SELECT po_number, sku, location, supplier, order_day, expected_day, received_day, quantity, unit_cost FROM purchase_orders WHERE org_id=:org AND " + known()
    a = {"org": org, "kt": kt}
    if sku:
        q += " AND sku=:sku"; a["sku"] = sku
    if location and location != "ALL":
        q += " AND location=:loc"; a["loc"] = location
    return [dict(r) for r in store.conn().execute(q + " ORDER BY order_day", a)]


def lead_times_days(pos, as_of=None):
    """Observed supplier lead times (order to receipt) in days, for receipts known by `as_of`."""
    out = []
    for p in pos:
        if p["received_day"] and (as_of is None or p["received_day"] <= as_of.isoformat()):
            out.append({"order_day": p["order_day"], "received_day": p["received_day"], "supplier": p["supplier"],
                        "days": (date.fromisoformat(p["received_day"]) - date.fromisoformat(p["order_day"])).days})
    return out


def events(store, org, sku=None, location=None, knowledge_time=None):
    kt = kt_str(knowledge_time)
    q = "SELECT event_type, sku, location, start_day, end_day, description, recorded_at FROM events WHERE org_id=:org AND " + known()
    a = {"org": org, "kt": kt}
    if sku:
        q += " AND (sku IS NULL OR sku=:sku)"; a["sku"] = sku
    if location and location != "ALL":
        q += " AND (location IS NULL OR location=:loc)"; a["loc"] = location
    return [dict(r) for r in store.conn().execute(q + " ORDER BY start_day", a)]


def history(store, p, sku, location="ALL", knowledge_time=None):
    """Everything known about one series at a time: weekly demand, gaps, stock snapshots, events, orders."""
    by_loc = location not in (None, "ALL")
    w = weekly_demand(store, p.org_id, knowledge_time, skus=[sku], locations=[location] if by_loc else None, by_location=by_loc)
    key = (sku, location if by_loc else "ALL")
    if key not in w["series"]:
        raise NotFound("no demand known for %s at %s" % (sku, location))
    s0 = w["start"][key]
    kt = w["knowledge_time"]
    inv = [dict(r) for r in store.conn().execute(
        "SELECT day, SUM(on_hand) AS on_hand FROM inventory WHERE org_id=:org AND sku=:sku%s AND %s GROUP BY day ORDER BY day"
        % ("" if not by_loc else " AND location=:loc", known()), {"org": p.org_id, "sku": sku, "loc": location, "kt": kt})]
    return {"sku": sku, "location": key[1], "knowledge_time": kt, "data_cutoff_day": w["cutoff_day"].isoformat(),
            "weeks": [{"week": (s0 + timedelta(weeks=i)).isoformat(), "demand": v} for i, v in enumerate(w["series"][key])],
            "weeks_without_rows": w["gaps"][key],
            "assumption": "A complete week with no sales rows is treated as zero demand.",
            "inventory_snapshots": inv, "stockout_weeks": [d.isoformat() for d in stockout_weeks(store, p.org_id, sku, location, kt)],
            "events": events(store, p.org_id, sku, location, kt),
            "purchase_orders": purchase_orders(store, p.org_id, sku, location, kt)}


def record_versions(store, p, table, record_key, source_name):
    """Every version of one record, oldest first, with when each was known."""
    if table not in ("demand", "inventory", "purchase_orders", "events"):
        raise NotFound("unknown table")
    c = store.conn()
    src = c.execute("SELECT id FROM data_sources WHERE org_id=? AND name=?", (p.org_id, source_name)).fetchone()
    if not src:
        raise NotFound("no source %s" % source_name)
    rows = [dict(r) for r in c.execute("SELECT * FROM %s WHERE org_id=? AND source_id=? AND record_key=? ORDER BY recorded_at" % table,
                                       (p.org_id, src[0], record_key))]
    for r in rows:
        r.pop("org_id", None)
    return rows
