"""Load a sales export and turn it into weekly series. Read-only: never writes to the source."""
from __future__ import annotations
import csv, hashlib
from collections import defaultdict
from dataclasses import dataclass, field
from datetime import date, datetime, timedelta

DATE_NAMES = ("date", "order_date", "day", "ds", "week", "invoice_date", "ship_date", "posting_date", "transaction_date", "sales_date", "period")
SKU_NAMES = ("sku", "product", "item", "product_id", "item_id", "product_group", "material", "part_number", "part", "article", "item_number", "material_number")
QTY_NAMES = ("quantity", "qty", "units", "units_sold", "sales", "y", "demand", "order_qty", "quantity_sold", "volume", "shipped_qty")


@dataclass
class Dataset:
    series: dict            # sku -> list[float], one value per week
    week0: date             # Monday of week index 0
    quality: dict = field(default_factory=dict)
    sha256: str = ""
    path: str = ""

    @property
    def n_weeks(self) -> int:
        return len(next(iter(self.series.values()))) if self.series else 0

    def week_start(self, i: int) -> date:
        return self.week0 + timedelta(weeks=i)


def monday(d: date) -> date:
    return d - timedelta(days=d.weekday())


def _pick(header, names, override, what):
    norm = lambda t: "_".join(t.strip().lower().replace("-", " ").split())
    low = {norm(h): h for h in header}
    if override:
        if norm(override) not in low:
            raise ValueError("column %r not found. Columns present: %s" % (override, ", ".join(header)))
        return low[norm(override)]
    for n in names:
        if n in low:
            return low[n]
    return None


def delimiter(path):
    """Real exports use comma, semicolon, tab or pipe. Choose by the header line."""
    with open(path, encoding="utf-8-sig", errors="replace") as f:
        head = f.readline()
    best = max(",;\t|", key=head.count)
    return best if head.count(best) else ","


def file_sha256(path: str) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def load_csv(path, date_col=None, sku_col=None, qty_col=None, date_format="%Y-%m-%d", allow_extra_columns=False) -> Dataset:
    skipped = defaultdict(int)
    rows = 0
    agg = defaultdict(lambda: defaultdict(float))   # sku -> monday -> qty
    with open(path, newline="", encoding="utf-8-sig") as f:
        rd = csv.DictReader(f, delimiter=delimiter(path))
        if not rd.fieldnames:
            raise ValueError("empty file")
        dc = _pick(rd.fieldnames, DATE_NAMES, date_col, "date")
        qc = _pick(rd.fieldnames, QTY_NAMES, qty_col, "quantity")
        sc = _pick(rd.fieldnames, SKU_NAMES, sku_col, "sku")
        if not dc or not qc:
            raise ValueError("could not find date/quantity columns; use --date-col and --qty-col. Columns: %s" % ", ".join(rd.fieldnames))
        if not allow_extra_columns:
            from . import privacy
            found = privacy.scan(path, {c for c in (dc, sc, qc) if c})
            if found:
                raise ValueError("this file may contain personal data, which Udgass does not need: " + "; ".join(found)
                                 + ". Remove those columns and try again. (Override with --allow-extra-columns only if you are sure.)")
        for r in rd:
            rows += 1
            try:
                d = datetime.strptime((r[dc] or "").strip(), date_format).date()
            except ValueError:
                skipped["unreadable date"] += 1
                continue
            try:
                q = float((r[qc] or "").replace(",", "").strip())
            except ValueError:
                skipped["unreadable quantity"] += 1
                continue
            sku = (r[sc].strip() if sc else "ALL") or "UNKNOWN"
            agg[sku][monday(d)] += q
    if not agg:
        raise ValueError("no usable rows (skipped: %s)" % dict(skipped))
    first = min(min(v) for v in agg.values())
    last = max(max(v) for v in agg.values())
    n = (last - first).days // 7 + 1
    series, neg, filled = {}, 0, 0
    for sku, m in agg.items():
        s = []
        for i in range(n):
            w = first + timedelta(weeks=i)
            if w in m:
                v = m[w]
                if v < 0:
                    neg += 1
                    v = 0.0
                s.append(v)
            else:
                filled += 1
                s.append(0.0)
        series[sku] = s
    q = {
        "rows_read": rows, "rows_skipped": dict(skipped), "skus": len(series), "weeks": n,
        "columns_used": {"date": dc, "product": sc, "quantity": qc},
        "first_week": first.isoformat(), "last_week": last.isoformat(),
        "weeks_negative_clamped_to_zero": neg,
        "missing_weeks_filled_with_zero": filled,
        "assumption": "A week with no rows is treated as zero sales. Check this is true for your data (stock-outs and missing exports look the same).",
    }
    return Dataset(series=series, week0=first, quality=q, sha256=file_sha256(path), path=str(path))
