"""Replay the past: for each as-of point use only earlier data, then compare with what happened."""
from __future__ import annotations
from .forecast import forecast_total, naive_weekly


def _job(args):
    sku, y, origins, horizon, level, methods, week_starts = args
    out = []
    for o in origins:
        hist = y[:o]                       # <- only what was known at the as-of date
        est = forecast_total(hist, horizon, level, methods)
        actual = sum(y[o:o + horizon])
        base = sum(naive_weekly(hist, horizon))
        out.append({
            "sku": sku, "as_of": week_starts[o], "origin": o,
            "estimate": est["point"], "low": est["low"], "high": est["high"],
            "actual": actual, "baseline": base, "method": est["method"],
            "evidence_quality": est["evidence_quality"],
            "inside": est["low"] <= actual <= est["high"],
        })
    return out


def run(ds, horizon=4, step=4, min_train=52, level=0.8, methods=None, workers=1):
    n = ds.n_weeks
    origins = list(range(min_train, n - horizon + 1, step))
    if not origins:
        raise ValueError("Not enough history: need at least %d weeks, have %d." % (min_train + horizon, n))
    ws = [ds.week_start(i).isoformat() for i in range(n)]
    jobs = [(sku, y, origins, horizon, level, methods, ws) for sku, y in ds.series.items()]
    if workers and workers > 1 and len(jobs) > 1:
        import multiprocessing as mp
        with mp.Pool(workers) as pool:
            parts = pool.map(_job, jobs, chunksize=max(1, len(jobs) // (workers * 4)))
    else:
        parts = [_job(j) for j in jobs]
    rows = [r for p in parts for r in p]
    return {"rows": rows, "summary": summarize(rows, level), "params": {
        "horizon_weeks": horizon, "step_weeks": step, "min_train_weeks": min_train,
        "interval_level": level, "origins": len(origins)}}


def _wape(rows, key):
    a = sum(r["actual"] for r in rows)
    return sum(abs(r["actual"] - r[key]) for r in rows) / a if a > 0 else float("nan")


def interval_score(rows, level=0.8):
    """Winkler interval score: width of the range plus a penalty for each actual outside it. Lower is better.
    Returned as a share of mean actual so it can be compared across files. It rewards ranges that are narrow AND honest."""
    alpha = 1 - level
    tot = 0.0
    for r in rows:
        lo, hi, a = r["low"], r["high"], r["actual"]
        tot += (hi - lo) + (2 / alpha) * max(lo - a, 0) + (2 / alpha) * max(a - hi, 0)
    m = sum(r["actual"] for r in rows) / len(rows)
    return tot / len(rows) / m if m > 0 else float("nan")


def load_group_map(path):
    import csv
    with open(path, newline="", encoding="utf-8-sig") as f:
        rd = csv.DictReader(f, delimiter=__import__("udgass.data", fromlist=["x"]).delimiter(path))
        cols = {c.strip().lower(): c for c in (rd.fieldnames or [])}
        if "sku" not in cols or "group" not in cols:
            raise ValueError("group map needs columns sku and group")
        return {r[cols["sku"]].strip(): r[cols["group"]].strip() for r in rd if r[cols["sku"]].strip()}


def by_group(rows, gmap):
    """Error when estimates are added up to groups (category, site, region). Ranges are not summed: adding
    ranges is not valid, so only point error is reported at group level. Products missing from the map go to 'UNMAPPED'."""
    agg = {}
    for r in rows:
        g = gmap.get(r["sku"], "UNMAPPED")
        a = agg.setdefault((g, r["as_of"]), {"estimate": 0.0, "actual": 0.0, "baseline": 0.0})
        for k in a:
            a[k] += r[k]
    per = {}
    for (g, _), v in agg.items():
        per.setdefault(g, []).append(v)
    out = []
    for g, rs in sorted(per.items()):
        out.append({"group": g, "n": len(rs), "wape": _wape(rs, "estimate"), "wape_baseline": _wape(rs, "baseline")})
    allrs = [v for v in agg.values()]
    return {"groups": out, "unmapped_products": sorted({r["sku"] for r in rows if r["sku"] not in gmap}),
            "all": {"wape": _wape(allrs, "estimate"), "wape_baseline": _wape(allrs, "baseline")}}


def summarize(rows, level=0.8):
    a = sum(r["actual"] for r in rows)
    e = sum(r["estimate"] for r in rows)
    w, wb = _wape(rows, "estimate"), _wape(rows, "baseline")
    per = {}
    for r in rows:
        per.setdefault(r["sku"], []).append(r)
    by_sku = []
    for sku, rs in sorted(per.items()):
        by_sku.append({"sku": sku, "n": len(rs), "wape": _wape(rs, "estimate"), "wape_baseline": _wape(rs, "baseline"),
                       "coverage": sum(r["inside"] for r in rs) / len(rs)})
    worst = sorted(rows, key=lambda r: abs(r["actual"] - r["estimate"]) / max(r["actual"], r["estimate"], 1.0), reverse=True)[:10]
    return {
        "n_estimates": len(rows),
        "wape": w, "wape_baseline": wb,
        "improvement_vs_baseline": (1 - w / wb) if wb and wb == wb and wb > 0 else None,
        "bias": (a - e) / a if a > 0 else float("nan"),     # positive = estimates ran low
        "coverage": sum(r["inside"] for r in rows) / len(rows),
        "interval_score": interval_score(rows, level),
        "by_sku": by_sku, "worst": worst,
    }


def leaderboard(ds, horizon=4, step=4, min_train=52, level=0.8, workers=1):
    """Score every method on the same as-of dates, plus the automatic selection. Used to decide whether a
    candidate method deserves to replace the current one: it must win here, on out-of-sample windows, not by assertion."""
    from .forecast import METHODS
    table = []
    for name in list(METHODS) + [None]:
        try:
            r = run(ds, horizon, step, min_train, level, [name] if name else None, workers)
        except ValueError:
            continue
        s = r["summary"]
        table.append({"method": name or "auto (selected per product)", "wape": s["wape"], "bias": s["bias"], "coverage": s["coverage"]})
    return sorted(table, key=lambda t: t["wape"])
