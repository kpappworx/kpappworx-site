"""Command line: udgass demo-data | backtest | record ..."""
from __future__ import annotations
import argparse, json, sys
from . import __version__, audit, backtest, compare, data, demo, detect, diagnose, inventory, records, report


def _audit(a, command, params, input_path, outputs):
    if a.no_audit:
        return
    audit.log(command, params, input_path, outputs, a.audit_log)
    print("Run logged to %s (verify with: udgass record verify %s)" % (a.audit_log, a.audit_log))


def main(argv=None):
    ap = argparse.ArgumentParser(prog="udgass", description="Udgass core %s. Reads files you give it and never changes them. Advisory only." % __version__)
    sub = ap.add_subparsers(dest="cmd", required=True)

    def common(p):
        p.add_argument("--allow-extra-columns", action="store_true", help="skip the personal-data check on columns Udgass does not use")
        p.add_argument("--audit-log", default=audit.DEFAULT, help="run log (tamper-evident). Default: %s" % audit.DEFAULT)
        p.add_argument("--no-audit", action="store_true", help="do not write a run log entry")

    d = sub.add_parser("demo-data", help="write an INVENTED sales file for trying the tool")
    d.add_argument("out")
    d.add_argument("--rich", action="store_true", help="invented data with known injected changes, plus an events file next to it")

    b = sub.add_parser("backtest", help="replay your history and compare estimates with what happened")
    b.add_argument("csv")
    b.add_argument("--out", default="udgass-backtest.html")
    b.add_argument("--json", default=None, help="also write the raw results as JSON")
    b.add_argument("--horizon", type=int, default=4, help="weeks ahead to estimate (default 4)")
    b.add_argument("--step", type=int, default=4, help="weeks between as-of dates (default 4)")
    b.add_argument("--min-train", type=int, default=52, help="weeks of history required before the first as-of date (default 52)")
    b.add_argument("--level", type=float, default=0.8, help="intended share of actuals inside the range (default 0.8)")
    b.add_argument("--workers", type=int, default=1, help="processes to use for large files")
    b.add_argument("--leaderboard", action="store_true", help="also score every method on the same as-of dates")
    b.add_argument("--date-col"); b.add_argument("--sku-col"); b.add_argument("--qty-col")
    b.add_argument("--date-format", default="%Y-%m-%d")
    b.add_argument("--group-map", help="CSV with columns sku, group. Adds error for products added up to groups")
    common(b)

    k = sub.add_parser("check", help="look at a file before running anything: what was found, what is missing, anything that looks personal")
    k.add_argument("csv"); k.add_argument("--date-col"); k.add_argument("--sku-col"); k.add_argument("--qty-col")
    k.add_argument("--date-format", default="%Y-%m-%d")

    c = sub.add_parser("compare-forecast", help="score a forecast you already have against Udgass on the same windows")
    c.add_argument("csv"); c.add_argument("incumbent_csv", help="columns: sku, as_of, forecast (total for the horizon, as made at the time)")
    c.add_argument("--horizon", type=int, default=4); c.add_argument("--step", type=int, default=4)
    c.add_argument("--min-train", type=int, default=52); c.add_argument("--level", type=float, default=0.8)
    c.add_argument("--workers", type=int, default=1); c.add_argument("--json", default=None)
    c.add_argument("--date-format", default="%Y-%m-%d")
    common(c)

    x = sub.add_parser("detect", help="flag changes worth reviewing, ranked by size, with any coinciding events you supply")
    x.add_argument("csv")
    x.add_argument("--events", help="CSV with columns sku (blank = all), start, end, type")
    x.add_argument("--sensitivity", choices=sorted(detect.PRESETS), default="balanced")
    x.add_argument("--json", default=None)
    x.add_argument("--date-format", default="%Y-%m-%d")
    x.add_argument("--top", type=int, default=25)
    common(x)

    e = sub.add_parser("evaluate", help="compare stock options for one product under assumptions you state")
    e.add_argument("csv"); e.add_argument("options_json", help='JSON list like [{"name":"A","order_up_to":600},{"name":"B","reorder_point":300,"order_qty":500}]')
    e.add_argument("--sku", required=True)
    e.add_argument("--lead-weeks", type=int, required=True, help="supplier lead time you assume")
    e.add_argument("--lead-jitter", type=int, default=0, help="lead time varies by +/- this many weeks")
    e.add_argument("--horizon", type=int, default=4)
    e.add_argument("--start-stock", type=float, default=0.0)
    e.add_argument("--date-format", default="%Y-%m-%d")
    common(e)

    asx = sub.add_parser("assess", help="demand assessment report from your own exports (runs locally; nothing leaves this machine)")
    asx.add_argument("--sales", required=True, help="sales export: date, product, quantity (location optional)")
    asx.add_argument("--inventory", help="stock-on-hand snapshots: date, product, on-hand (location optional)")
    asx.add_argument("--purchase-orders", help="purchase orders: PO number, product, order date, quantity, receipt date, promised date, vendor")
    asx.add_argument("--events", help="events such as promotions: type, start, end, product")
    asx.add_argument("--incumbent", help="your own past forecasts: sku, as_of, forecast (horizon total, as made at the time)")
    asx.add_argument("--map", action="append", default=[], help="column mapping, e.g. --map sales:sku=Material --map sales:quantity=Qty")
    asx.add_argument("--date-format", help="for example %%d/%%m/%%Y when dates are ambiguous")
    asx.add_argument("--decimal-comma", action="store_true", help="numbers use a comma as the decimal separator")
    asx.add_argument("--returns", choices=["reject", "net"], default="reject", help="negative quantities: reject the rows (default) or subtract them")
    asx.add_argument("--duplicate-rows", choices=["keep", "drop"], default="keep")
    asx.add_argument("--company", default=""); asx.add_argument("--horizon", type=int, default=4)
    asx.add_argument("--anonymise", action="store_true", help="replace product and location codes in the report")
    asx.add_argument("--out", default="udgass-assessment.html"); asx.add_argument("--json")
    asx.add_argument("--banner", help="a line printed at the top of the report, e.g. ILLUSTRATIVE: synthetic data")

    sv = sub.add_parser("serve", help="run the local API and web app")
    sv.add_argument("--db", default="udgass.db"); sv.add_argument("--host", default="127.0.0.1"); sv.add_argument("--port", type=int, default=8765)
    sv.add_argument("--tls-cert"); sv.add_argument("--tls-key"); sv.add_argument("--allow-plain-http-on-network", action="store_true")

    ad = sub.add_parser("admin", help="organisations and keys (run on the server machine)")
    ads = ad.add_subparsers(dest="acmd", required=True)
    co = ads.add_parser("create-org"); co.add_argument("name"); co.add_argument("--db", default="udgass.db")
    ex = ads.add_parser("export-org", help="write all of an organisation's data as JSON lines"); ex.add_argument("out_dir")
    ex.add_argument("--db", default="udgass.db"); ex.add_argument("--key", required=True, help="an admin key of that organisation")

    de = sub.add_parser("demo-enterprise", help="write the SYNTHETIC enterprise dataset (CSV files)")
    de.add_argument("out_dir"); de.add_argument("--seed", type=int, default=7)
    dw = sub.add_parser("demo-workflow", help="run the whole loop on SYNTHETIC data in a new database")
    dw.add_argument("--db", default="udgass-demo.db"); dw.add_argument("--data", default="udgass-demo-data")

    r = sub.add_parser("record", help="decision records (append-only ledger)")
    rs = r.add_subparsers(dest="rcmd", required=True)
    for name in ("decision", "action", "outcome"):
        x = rs.add_parser(name, help="add a %s from a JSON file" % name)
        x.add_argument("ledger"); x.add_argument("json_file")
    v = rs.add_parser("show"); v.add_argument("ledger"); v.add_argument("id")
    vv = rs.add_parser("verify"); vv.add_argument("ledger")

    a = ap.parse_args(argv)
    try:
        if a.cmd == "demo-data":
            if a.rich:
                ev = a.out.rsplit(".", 1)[0] + "-events.csv"
                truth = demo.write_rich(a.out, ev)
                print("Wrote INVENTED data to %s and events to %s. Injected changes (the answer key): %s" % (a.out, ev, truth))
            else:
                demo.write(a.out)
                print("Wrote INVENTED data to %s. Do not draw conclusions about real accuracy from it." % a.out)
        elif a.cmd == "backtest":
            if a.horizon < 1 or a.step < 1 or not 0.5 <= a.level < 1:
                raise ValueError("horizon and step must be at least 1; level must be between 0.5 and 0.99")
            ds = data.load_csv(a.csv, a.date_col, a.sku_col, a.qty_col, a.date_format, a.allow_extra_columns)
            res = backtest.run(ds, a.horizon, a.step, a.min_train, a.level, None, a.workers)
            with open(a.out, "w", encoding="utf-8") as f:
                f.write(report.build(ds, res))
            if a.json:
                with open(a.json, "w", encoding="utf-8") as f:
                    json.dump({"quality": ds.quality, "sha256": ds.sha256, **res}, f, indent=2)
            s = res["summary"]
            print("%d estimates | error %.1f%% vs baseline %.1f%% | %.0f%% of actuals inside the range" % (
                s["n_estimates"], s["wape"] * 100, s["wape_baseline"] * 100, s["coverage"] * 100))
            print("interval score %.2f (share of mean actual; lower is better, rewards ranges that are narrow and honest)" % s["interval_score"])
            print("Report: " + a.out)
            outs = [a.out]
            if a.group_map:
                g = backtest.by_group(res["rows"], backtest.load_group_map(a.group_map))
                print("\nError when added up to groups (point estimates only; ranges are not summed):")
                for r in g["groups"]:
                    print("  %-20s %3d windows  error %5.1f%% vs baseline %5.1f%%" % (r["group"], r["n"], r["wape"] * 100, r["wape_baseline"] * 100))
                if g["unmapped_products"]:
                    print("  note: %d products were not in the group map (shown as UNMAPPED)" % len(g["unmapped_products"]))
            if a.json:
                outs.append(a.json)
            _audit(a, "backtest", {"horizon": a.horizon, "step": a.step, "min_train": a.min_train, "level": a.level,
                                   "group_map": bool(a.group_map)}, a.csv, outs)
            if a.leaderboard:
                print("\nMethod leaderboard (same as-of dates; lower error is better):")
                for t in backtest.leaderboard(ds, a.horizon, a.step, a.min_train, a.level, a.workers):
                    print("  %-30s error %5.1f%%  inside range %3.0f%%" % (t["method"], t["wape"] * 100, t["coverage"] * 100))
        elif a.cmd == "assess":
            from .engine import assess
            maps = {}
            for m in a.map:
                try:
                    kind, rest = m.split(":", 1); fld, col = rest.split("=", 1)
                except ValueError:
                    raise ValueError("--map must look like sales:sku=Material")
                maps.setdefault(kind.strip(), {})[fld.strip()] = col
            files = {k: v for k, v in [("sales", a.sales), ("inventory", a.inventory), ("purchase_orders", a.purchase_orders), ("events", a.events)] if v}
            try:
                res = assess.run(files, a.out, a.json, maps, a.date_format,
                                 {"decimal_comma": a.decimal_comma, "returns": a.returns, "duplicate_rows": a.duplicate_rows},
                                 a.incumbent, a.company, a.horizon, a.anonymise, banner=a.banner)
            except assess.NotReady as nr:
                print("The sales file is not ready. Report with the details: %s" % a.out)
                for i in nr.issues:
                    print("  - " + i)
                return 3
            print("\n" + res["verdict"]["headline"])
            print("Report: %s%s. Advisory only; the decision rests with your company." % (a.out, (" and " + a.json) if a.json else ""))
        elif a.cmd == "serve":
            from .engine.db import Store
            from .engine import api
            st = Store(a.db)
            print("Udgass %s serving %s://%s:%d (database %s). Ctrl+C to stop." % (__version__, "https" if a.tls_cert else "http", a.host, a.port, a.db))
            api.serve(st, a.host, a.port, a.tls_cert, a.tls_key, a.allow_plain_http_on_network)
        elif a.cmd == "admin":
            from .engine.db import Store
            from .engine import tenancy, governance
            st = Store(a.db)
            if a.acmd == "create-org":
                org, key = tenancy.create_org(st, a.name)
                print("organisation %s created.\nadmin key (shown once, store it safely): %s" % (org, key))
            else:
                p = tenancy.authenticate(st, a.key)
                print(json.dumps(governance.export_org(st, p, a.out_dir), indent=2))
        elif a.cmd == "demo-enterprise":
            from .engine import synthetic
            t = synthetic.generate(a.out_dir, a.seed)
            print("Wrote SYNTHETIC files to %s: %s" % (a.out_dir, ", ".join(t["files"])))
        elif a.cmd == "demo-workflow":
            import os as _os
            from .engine import workflow
            if _os.path.exists(a.db):
                raise ValueError("%s exists; choose a new --db so the demo starts clean" % a.db)
            out = workflow.run_demo(a.db, a.data)
            print("\nDatabase: %s. Explore it: udgass serve --db %s, then open http://127.0.0.1:8765 with the key %s" % (a.db, a.db, out["api_key"]))
        elif a.cmd == "check":
            from . import privacy
            ds = data.load_csv(a.csv, a.date_col, a.sku_col, a.qty_col, a.date_format, True)
            q = ds.quality
            used = {v for v in q["columns_used"].values() if v}
            print("Columns used: date=%(date)s, product=%(product)s, quantity=%(quantity)s" % q["columns_used"])
            print("%d rows read, %s skipped | %d products | %d weeks (%s to %s)" % (q["rows_read"], q["rows_skipped"] or "0", q["skus"], q["weeks"], q["first_week"], q["last_week"]))
            print("%d empty weeks treated as zero; %d negative weeks set to zero" % (q["missing_weeks_filled_with_zero"], q["weeks_negative_clamped_to_zero"]))
            need = 56
            print(("OK: enough history for a backtest (%d weeks, need %d)." if q["weeks"] >= need else "NOT ENOUGH HISTORY: %d weeks, need at least %d for a backtest.") % (q["weeks"], need))
            if q["skus"] == 1 and not q["columns_used"]["product"]:
                print("Note: no product column found, so everything is treated as one product. Use --sku-col if there is one.")
            found = privacy.scan(a.csv, used)
            print("Personal-data check: " + ("; ".join(found) if found else "nothing suspicious in the unused columns (best-effort)."))
            print("Nothing was changed or written.")
        elif a.cmd == "compare-forecast":
            ds = data.load_csv(a.csv, None, None, None, a.date_format, a.allow_extra_columns)
            res = backtest.run(ds, a.horizon, a.step, a.min_train, a.level, None, a.workers)
            inc, bad = compare.load_incumbent(a.incumbent_csv, a.date_format)
            c = compare.compare(res["rows"], inc)
            print("%d windows matched (of %d scored by Udgass)%s" % (c["matched_windows"], c["of_backtest_windows"], "; %d incumbent rows unreadable" % bad if bad else ""))
            print("  your forecast   error %5.1f%%   bias %+5.1f%%" % (c["wape_incumbent"] * 100, c["bias_incumbent"] * 100))
            print("  Udgass          error %5.1f%%   bias %+5.1f%%" % (c["wape_udgass"] * 100, c["bias_udgass"] * 100))
            print("  flat baseline   error %5.1f%%" % (c["wape_naive"] * 100))
            print("  closer to actual: Udgass in %d windows, yours in %d" % (c["windows_udgass_closer"], c["windows_incumbent_closer"]))
            print("Read this with care:")
            for l in c["limits"]:
                print("  - " + l)
            if a.json:
                with open(a.json, "w", encoding="utf-8") as f:
                    json.dump(c, f, indent=2)
            _audit(a, "compare-forecast", {"horizon": a.horizon, "step": a.step}, a.csv, [a.json] if a.json else [])
        elif a.cmd == "detect":
            ds = data.load_csv(a.csv, None, None, None, a.date_format, a.allow_extra_columns)
            found = detect.scan_all(ds, **detect.PRESETS[a.sensitivity])
            events = diagnose.load_events(a.events, a.date_format) if a.events else []
            rows = []
            for sku, eps in found.items():
                for ep in eps:
                    ctx = diagnose.context(sku, ds.week_start(ep["index"]), events, ds.series[sku], ep["index"])
                    rows.append({"sku": sku, "week": ep["week"], "kind": ep["kind"], "weeks_affected": ep["weeks_affected"],
                                 "observed": ep["observed"], "expected": ep["expected"], "impact_units": detect.impact(ds.series[sku], ep),
                                 "peak_z": ep["peak_z"], "context": ctx["reading"], "data_notes": ctx["data_notes"],
                                 "events": [dict(e, start=str(e["start"]), end=str(e["end"])) for e in ctx["coinciding_events"]]})
            rows.sort(key=lambda r: -r["impact_units"])
            print("%d products scanned, %d flagged episodes (%s sensitivity). Flags are prompts for review, not diagnoses." % (len(ds.series), len(rows), a.sensitivity))
            for r in rows[:a.top]:
                print("  %-10s %s %-16s x%d wk  observed %.0f vs expected %.0f | %s" % (r["sku"], r["week"], r["kind"], r["weeks_affected"], r["observed"], r["expected"], r["context"]))
                for n in r["data_notes"]:
                    print("             note: " + n)
            if a.json:
                with open(a.json, "w", encoding="utf-8") as f:
                    json.dump(rows, f, indent=2)
            _audit(a, "detect", {"sensitivity": a.sensitivity, "events": bool(a.events), "flagged": len(rows)}, a.csv, [a.json] if a.json else [])
        elif a.cmd == "evaluate":
            ds = data.load_csv(a.csv, None, None, None, a.date_format, a.allow_extra_columns)
            if a.sku not in ds.series:
                raise ValueError("unknown product %r" % a.sku)
            res = backtest.run(ds, a.horizon, a.horizon, 52, 0.8)
            rows = [r for r in res["rows"] if r["sku"] == a.sku]
            errs = [(r["actual"] - r["estimate"]) / max(r["estimate"], 1.0) for r in rows]
            from .forecast import forecast_total
            est = forecast_total(ds.series[a.sku], a.horizon)
            with open(a.options_json, encoding="utf-8") as f:
                opts = json.load(f)
            table = inventory.compare(est["point"] / a.horizon, errs, a.lead_weeks, opts, start_stock=a.start_stock,
                                      lead_jitter=a.lead_jitter, block=a.horizon)
            print("Estimate for the next %d weeks: %.0f (range %.0f to %.0f, evidence %s, %d past windows)" % (a.horizon, est["point"], est["low"], est["high"], est["evidence_quality"], len(errs)))
            print("Assumptions you stated: lead time %d weeks (+/- %d), starting stock %.0f. Demand uncertainty: resampled from this product's own measured errors." % (a.lead_weeks, a.lead_jitter, a.start_stock))
            print("%-22s %10s %18s %10s" % ("option", "fill rate", "weeks short (share)", "avg stock"))
            for r in table:
                print("%-22s %9.1f%% %18.1f%% %10.0f" % (r["option"], r["fill_rate"] * 100, r["weeks_with_stockout"] * 100, r["avg_stock"]))
            print("This compares options under your assumptions. It does not recommend one, and nothing is ordered.")
            _audit(a, "evaluate", {"sku": a.sku, "lead_weeks": a.lead_weeks, "lead_jitter": a.lead_jitter, "options": len(opts)}, a.csv, [])
        elif a.cmd == "record":
            if a.rcmd in ("decision", "action", "outcome"):
                with open(a.json_file, encoding="utf-8") as f:
                    e = records.add(a.ledger, a.rcmd, json.load(f))
                print("recorded #%d %s" % (e["seq"], e["hash"][:12]))
            elif a.rcmd == "show":
                print(json.dumps(records.view(a.ledger, a.id), indent=2))
            else:
                ok, msg = records.verify(a.ledger)
                print(msg)
                return 0 if ok else 1
    except (ValueError, OSError, json.JSONDecodeError) as e:
        print("error: %s" % e, file=sys.stderr)
        return 2
    return 0


if __name__ == "__main__":
    sys.exit(main())
