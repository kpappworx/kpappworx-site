"""Run log: every analysis appends a tamper-evident entry saying what ran, on which input (by checksum), with which settings."""
from __future__ import annotations
import hashlib, os, platform, sys
from . import __version__, records

DEFAULT = "udgass-audit.jsonl"


def sha(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for c in iter(lambda: f.read(65536), b""):
            h.update(c)
    return h.hexdigest()


def log(command, params, input_path=None, outputs=(), path=DEFAULT):
    if not path:
        return None
    entry = {"udgass_version": __version__, "command": command, "params": params,
             "python": platform.python_version(),
             "input": {"file": os.path.basename(input_path), "sha256": sha(input_path)} if input_path else None,
             "outputs": [{"file": os.path.basename(o), "sha256": sha(o)} for o in outputs if o and os.path.exists(o)]}
    return records.append(path, "run", entry)
