"""Evaluate options: simulate stock under stated assumptions and compare policies side by side.

This is decision support. It uses the demand uncertainty MEASURED in the backtest (the spread of past estimate errors),
and lead-time assumptions the user states. It recommends nothing and executes nothing.
"""
from __future__ import annotations
import random


def simulate(weekly_mean, rel_errors, lead_weeks, order_up_to=None, reorder_point=None, order_qty=None,
             start_stock=0.0, weeks=26, runs=2000, seed=1, lead_jitter=0, block=1):
    """Weekly simulation. Policy is either (reorder_point, order_qty) or order_up_to (a base-stock level).
    Weekly demand = weekly_mean * (1 + e), e drawn from the measured relative errors (resampled).
    lead_jitter: lead time varies uniformly by +/- this many weeks (a stated assumption).
    block: a measured error is a whole-window error, so one draw is held for `block` weeks (the backtest horizon)."""
    rnd = random.Random(seed)
    errs = rel_errors or [0.0]
    served = demanded = stockout_weeks = 0.0
    inv_sum = 0.0
    for _ in range(runs):
        stock, pipeline = float(start_stock), []        # pipeline: (arrival_week, qty)
        e = 0.0
        for w in range(weeks):
            if w % block == 0:
                e = rnd.choice(errs)
            arrived = sum(q for a, q in pipeline if a <= w)
            pipeline = [(a, q) for a, q in pipeline if a > w]
            stock += arrived
            d = max(0.0, weekly_mean * (1 + e))
            s = min(stock, d)
            served += s; demanded += d
            if d > stock:
                stockout_weeks += 1
            stock -= s
            inv_sum += stock
            position = stock + sum(q for _, q in pipeline)
            lt = max(0, lead_weeks + (rnd.randint(-lead_jitter, lead_jitter) if lead_jitter else 0))
            if order_up_to is not None and position < order_up_to:
                pipeline.append((w + 1 + lt, order_up_to - position))
            elif reorder_point is not None and position <= reorder_point:
                pipeline.append((w + 1 + lt, order_qty))
    n = runs * weeks
    return {"fill_rate": served / demanded if demanded else 1.0,
            "weeks_with_stockout": stockout_weeks / n,
            "avg_stock": inv_sum / n}


def compare(weekly_mean, rel_errors, lead_weeks, options, **kw):
    """options: list of {name, order_up_to | (reorder_point, order_qty)}. Returns a table, best-served first."""
    rows = []
    for o in options:
        r = simulate(weekly_mean, rel_errors, lead_weeks, o.get("order_up_to"), o.get("reorder_point"), o.get("order_qty"), **kw)
        rows.append({"option": o["name"], **r})
    return sorted(rows, key=lambda r: -r["fill_rate"])
