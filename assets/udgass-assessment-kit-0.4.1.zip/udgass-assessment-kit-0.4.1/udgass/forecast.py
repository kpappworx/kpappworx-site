"""Forecasting. Every function sees only data up to the as-of point it is given."""
from __future__ import annotations
import math

SEASON = 52
SWITCH_MARGIN = 0.9


def quantile(xs, q):
    s = sorted(xs)
    if not s:
        raise ValueError("empty")
    if len(s) == 1:
        return s[0]
    p = q * (len(s) - 1)
    lo, hi = int(math.floor(p)), int(math.ceil(p))
    return s[lo] + (s[hi] - s[lo]) * (p - lo)


def _mean(xs):
    return sum(xs) / len(xs) if xs else 0.0


def naive_weekly(hist, h):
    """Flat forecast at the mean of the last 4 weeks."""
    lvl = _mean(hist[-4:])
    return [lvl] * h


def seasonal_weekly(hist, h):
    """Last year's shape applied to the current level. Needs 56+ weeks of history; otherwise None."""
    t = len(hist)
    if t < SEASON + 8:
        return None
    lvl = _mean(hist[-4:])
    out = []
    for k in range(h):
        i = t - SEASON + k                       # same week last year
        if i >= t:
            return None
        ref = _mean(hist[i - 4:i]) if i >= 4 else 0.0     # level four weeks before it, last year
        cur = _mean(hist[max(0, i - 1):i + 2])           # smoothed last-year value
        ratio = cur / ref if ref > 0 else 1.0
        ratio = min(2.0, max(0.5, ratio))
        out.append(lvl * ratio)
    return out


def holt_weekly(hist, h, alpha, beta, phi=0.9):
    """Damped-trend exponential smoothing with fixed, conservative parameters (no fitting on thin data)."""
    if len(hist) < 8:
        return None
    lvl, tr = _mean(hist[:4]), 0.0
    for y in hist[4:]:
        prev = lvl
        lvl = alpha * y + (1 - alpha) * (lvl + phi * tr)
        tr = beta * (lvl - prev) + (1 - beta) * phi * tr
    out, damp = [], 0.0
    for k in range(1, h + 1):
        damp += phi ** k
        out.append(max(0.0, lvl + damp * tr))
    return out


def holt_fast(hist, h):
    return holt_weekly(hist, h, 0.5, 0.1)


def holt_slow(hist, h):
    return holt_weekly(hist, h, 0.2, 0.05)


def sba_weekly(hist, h, alpha=0.1):
    """Croston with the Syntetos-Boylan correction, for intermittent demand (many zero weeks)."""
    nz = [(i, y) for i, y in enumerate(hist) if y > 0]
    if len(nz) < 3:
        return None
    z = nz[0][1]
    p = float(nz[0][0] + 1)
    last = nz[0][0]
    for i, y in nz[1:]:
        z = alpha * y + (1 - alpha) * z
        p = alpha * (i - last) + (1 - alpha) * p
        last = i
    rate = (1 - alpha / 2) * z / p
    return [rate] * h


def combo_weekly(hist, h):
    """Equal-weight average of the available methods. Averaging is a robust default."""
    parts = [m(hist, h) for m in (naive_weekly, holt_slow, seasonal_weekly)]
    parts = [p for p in parts if p is not None]
    if len(parts) < 2:
        return None
    return [sum(p[k] for p in parts) / len(parts) for k in range(h)]


METHODS = {"naive": naive_weekly, "seasonal": seasonal_weekly, "holt_fast": holt_fast, "holt_slow": holt_slow, "sba": sba_weekly, "combo": combo_weekly}



# ---- fast path: forecasts for many as-of points in one pass (identical results to calling each method per origin) ----
_HOLT = {"holt_fast": (0.5, 0.1), "holt_slow": (0.2, 0.05)}


def _holt_states(hist, alpha, beta, phi=0.9):
    """states[t] = (level, trend) after seeing hist[:t], for t >= 8."""
    states = {}
    lvl, tr = _mean(hist[:4]), 0.0
    for t in range(4, len(hist) + 1):
        if t >= 8:
            states[t] = (lvl, tr)
        if t == len(hist):
            break
        y = hist[t]
        prev = lvl
        lvl = alpha * y + (1 - alpha) * (lvl + phi * tr)
        tr = beta * (lvl - prev) + (1 - beta) * phi * tr
    return states


def _holt_out(state, h, phi=0.9):
    lvl, tr = state
    out, damp = [], 0.0
    for k in range(1, h + 1):
        damp += phi ** k
        out.append(max(0.0, lvl + damp * tr))
    return out


def _sba_states(hist, alpha=0.1):
    """states[t] = (z, p, last, count) after seeing hist[:t]."""
    states, z, p, last, cnt = {}, None, None, None, 0
    for t in range(len(hist) + 1):
        if cnt >= 3:
            states[t] = (z, p)
        if t == len(hist):
            break
        y = hist[t]
        if y > 0:
            if cnt == 0:
                z, p, last = y, float(t + 1), t
            else:
                z = alpha * y + (1 - alpha) * z
                p = alpha * (t - last) + (1 - alpha) * p
                last = t
            cnt += 1
    return states


def forecasts_at(method, hist, h, origins):
    """{origin: weekly forecast or None} using hist[:origin] only, computed efficiently."""
    out = {}
    if method in _HOLT:
        st = _holt_states(hist, *_HOLT[method])
        for o in origins:
            out[o] = _holt_out(st[o], h) if o in st else None
    elif method == "sba":
        st = _sba_states(hist)
        for o in origins:
            out[o] = [(1 - 0.05) * st[o][0] / st[o][1]] * h if o in st else None
    elif method == "combo":
        st = _holt_states(hist, *_HOLT["holt_slow"])
        for o in origins:
            parts = [naive_weekly(hist[:o], h), _holt_out(st[o], h) if o in st else None, seasonal_weekly(hist[:o], h)]
            parts = [p for p in parts if p is not None]
            out[o] = [sum(p[k] for p in parts) / len(parts) for k in range(h)] if len(parts) >= 2 else None
    else:
        for o in origins:
            out[o] = METHODS[method](hist[:o], h)
    return out


def _total(f):
    return sum(f)


def internal_errors(hist, h, method, max_origins=52, min_train=16):
    """Relative errors of the h-week total, made by replaying the past of `hist` only."""
    t = len(hist)
    start = max(min_train, t - h - max_origins)
    origins = list(range(start, t - h + 1))
    fs = forecasts_at(method, hist, h, origins)
    errs, abs_err, act_sum = [], 0.0, 0.0
    for o in origins:
        f = fs[o]
        if f is None:
            continue
        F, A = _total(f), sum(hist[o:o + h])
        errs.append((A - F) / max(F, 1.0))
        abs_err += abs(A - F)
        act_sum += A
    return errs, (abs_err / act_sum if act_sum > 0 else float("inf"))


def evidence_quality(n):
    return "thin" if n < 12 else ("moderate" if n < 26 else "reasonable")


def forecast_total(hist, h, level=0.8, methods=None):
    """Estimate the next-h-weeks total as a range, using only `hist`.
    Returns dict: point, low, high, method, evidence_n, evidence_quality, weekly."""
    cands = {}
    for m in (methods or METHODS):
        f = METHODS[m](hist, h)
        if f is None:
            continue
        errs, wape = internal_errors(hist, h, m)
        cands[m] = (f, errs, wape)
    if "naive" not in cands:      # always keep the flat estimate available as the fallback
        f = naive_weekly(hist, h)
        errs, wape = internal_errors(hist, h, "naive")
        cands["naive"] = (f, errs, wape)
    # choose by past accuracy; fall back to naive if there is no evidence for either
    usable = {m: v for m, v in cands.items() if len(v[1]) >= 4}
    if methods and len(methods) == 1 and methods[0] in cands:
        m = methods[0]                 # a method forced for comparison
    elif usable:
        m = min(usable, key=lambda k: usable[k][2])
        # selection on a short, noisy record over-fits, so stay with the robust average unless another method is clearly better
        if "combo" in usable and m != "combo" and usable[m][2] > SWITCH_MARGIN * usable["combo"][2]:
            m = "combo"
    else:
        m = "naive"
    f, errs, _ = cands[m]
    F = _total(f)
    if len(errs) >= 8:
        # split-conformal style: a symmetric band from the absolute earlier errors, with the
        # finite-sample correction. Earlier errors overlap in time, so the true coverage can still fall short.
        n = len(errs)
        k = min(1.0, math.ceil((n + 1) * level) / n)
        r = quantile([abs(x) for x in errs], k)
        lo_r, hi_r = -r, r
    else:
        lo_r, hi_r = -0.5, 0.5          # explicit wide default; flagged as thin
    low = max(0.0, F * (1 + lo_r))
    high = max(low, F * (1 + hi_r))
    return {"point": F, "low": low, "high": high, "method": m,
            "evidence_n": len(errs), "evidence_quality": evidence_quality(len(errs)),
            "weekly": f, "level": level,
            "candidates": {k: {"internal_wape": (v[2] if math.isfinite(v[2]) else None), "past_errors": len(v[1])} for k, v in sorted(cands.items())}}
