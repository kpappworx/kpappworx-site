"""Data minimisation. Udgass needs a date, a product and a quantity. If the file carries anything that looks personal, stop and say so."""
from __future__ import annotations
import csv, re

HEADER = re.compile(r"(e-?mail|phone|mobile|first.?name|last.?name|full.?name|^name$|customer.?name|address|street|postcode|zip|ssn|passport|dob|birth|card|iban|account.?number|tax.?id|aadhaar|pan)", re.I)
EMAIL = re.compile(r"[^@\s,;]+@[^@\s,;]+\.[A-Za-z]{2,}")
PHONE = re.compile(r"(?<!\d)\+?\d[\d\s().-]{8,}\d(?!\d)")


def _phone_like(v):
    v = v.strip()
    d = len(re.sub(r"\D", "", v))
    if not 10 <= d <= 15 or re.match(r"\d{4}-\d{2}-\d{2}", v) or re.fullmatch(r"[\d.,]+", v):
        return False
    return v.startswith("+") or bool(re.search(r"[\s().-]", v))


def scan(path, used_columns, sample_rows=300):
    """Return a list of findings about columns Udgass does not use. Empty means nothing suspicious was seen."""
    findings = []
    with open(path, newline="", encoding="utf-8-sig") as f:
        from .data import delimiter
        rd = csv.DictReader(f, delimiter=delimiter(path))
        extra = [c for c in (rd.fieldnames or []) if c not in used_columns]
        for c in extra:
            if HEADER.search(c):
                findings.append("column %r looks like it may hold personal data" % c)
        hits = {}
        for i, r in enumerate(rd):
            if i >= sample_rows:
                break
            for c in extra:
                v = r.get(c) or ""
                if EMAIL.search(v):
                    hits[c] = "email addresses"
                elif PHONE.search(v) and _phone_like(v):
                    hits.setdefault(c, "phone-number-like values")
        for c, what in hits.items():
            findings.append("column %r contains %s" % (c, what))
    return findings
