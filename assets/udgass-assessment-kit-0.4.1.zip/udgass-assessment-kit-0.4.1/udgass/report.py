"""Self-contained HTML backtest report. States what it shows and what it does not."""
from __future__ import annotations
import html, json


def pct(x, d=1):
    return "n/a" if x is None or x != x else "%.*f%%" % (d, x * 100)


def build(ds, result, title="Udgass backtest report"):
    s, p, q = result["summary"], result["params"], ds.quality
    e = html.escape
    sku_rows = "".join(
        "<tr><td>%s</td><td>%d</td><td>%s</td><td>%s</td><td>%s</td></tr>" % (
            e(r["sku"]), r["n"], pct(r["wape"]), pct(r["wape_baseline"]), pct(r["coverage"], 0)) for r in s["by_sku"])
    worst = "".join(
        "<tr><td>%s</td><td>%s</td><td>%.0f</td><td>%.0f to %.0f</td><td>%.0f</td><td>%s</td></tr>" % (
            e(r["sku"]), r["as_of"], r["estimate"], r["low"], r["high"], r["actual"], "inside" if r["inside"] else "outside")
        for r in s["worst"])
    imp = s["improvement_vs_baseline"]
    imp_txt = ("%s lower error than the flat baseline" % pct(imp)) if imp is not None and imp > 0 else (
        "no better than the flat baseline" if imp is not None else "baseline not comparable")
    nominal = p["interval_level"]
    cov_note = "close to" if abs(s["coverage"] - nominal) <= 0.1 else ("below" if s["coverage"] < nominal else "above")
    skipped = ", ".join("%s: %d" % kv for kv in q["rows_skipped"].items()) or "none"
    return """<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>%(title)s</title><style>
:root{color-scheme:dark}body{margin:0;background:#090D12;color:#F0F2EF;font:16px/1.6 system-ui,Segoe UI,Roboto,sans-serif}
main{max-width:980px;margin:0 auto;padding:40px 24px 80px}h1{font:400 2.4rem/1.1 Georgia,serif;margin:0 0 8px}h2{font:400 1.5rem Georgia,serif;margin:40px 0 12px}
.m{color:#9BA8B5}.tag{display:inline-block;border:1px solid #E3B96F;color:#E3B96F;font:600 .72rem ui-monospace,Menlo,monospace;letter-spacing:.1em;padding:5px 9px;text-transform:uppercase}
.k{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:1px;background:#243140;border:1px solid #243140;margin-top:20px}
.k div{background:#101720;padding:16px}.k b{display:block;font:400 2rem Georgia,serif;color:#70D6C3}.k span{color:#9BA8B5;font-size:.88rem}
table{border-collapse:collapse;width:100%%;font-size:.92rem}th,td{text-align:left;padding:8px 10px;border-bottom:1px solid #243140}th{color:#9BA8B5;font-weight:500}
.box{border-left:2px solid #E3B96F;padding:4px 16px;background:#101720;color:#cfd6dd}code{font-family:ui-monospace,Menlo,monospace;font-size:.85em;color:#9BA8B5;word-break:break-all}
</style></head><body><main>
<p class="tag">Backtest on the supplied data only</p>
<h1>%(title)s</h1>
<p class="m">%(n)d estimates replayed from %(first)s to %(last)s. Each estimate used only data available at its as-of date.</p>
<div class="k">
<div><b>%(wape)s</b><span>Error (WAPE) of the estimates</span></div>
<div><b>%(wapeb)s</b><span>Error of a flat 4-week baseline</span></div>
<div><b>%(cov)s</b><span>Actuals inside the stated range (range aims for %(nom)s)</span></div>
<div><b>%(bias)s</b><span>Bias. Positive means estimates ran low</span></div></div>
<p>The estimates had %(imp)s. Coverage was %(covnote)s the intended %(nom)s.</p>
<div class="box"><p><b>How to read this.</b> This is a measurement of how this method performed on this file, across %(skus)d products, over %(horizon)d-week windows. It does not show how it will perform on future data, and it says nothing about any other business. Estimates are advice for a person to weigh. They are not instructions.</p></div>
<h2>By product</h2>
<table><tr><th>Product</th><th>Estimates</th><th>Error</th><th>Baseline error</th><th>Inside range</th></tr>%(skurows)s</table>
<h2>Largest misses</h2>
<p class="m">Shown on purpose. The biggest errors are where the method needs the most scrutiny.</p>
<table><tr><th>Product</th><th>As of</th><th>Estimate</th><th>Range</th><th>Actual</th><th></th></tr>%(worst)s</table>
<h2>Method</h2>
<p>For each product and as-of week: a flat estimate (mean of the last 4 weeks) and, with at least 56 weeks of history, a seasonal estimate (last year's shape on the current level). The method that was more accurate on that product's own earlier history is used. The range comes from the spread of the method's earlier errors on the same horizon. Where there are fewer than 8 earlier errors, a wide default range is used and the estimate is marked as thin evidence.</p>
<h2>Data and reproducibility</h2>
<table>
<tr><th>Input file</th><td><code>%(path)s</code></td></tr>
<tr><th>SHA-256</th><td><code>%(sha)s</code></td></tr>
<tr><th>Rows read / skipped</th><td>%(rows)d / %(skipped)s</td></tr>
<tr><th>Weeks</th><td>%(weeks)d (%(first)s to %(last)s)</td></tr>
<tr><th>Weeks filled with zero</th><td>%(filled)d. %(assume)s</td></tr>
<tr><th>Negative weeks set to zero</th><td>%(neg)d</td></tr>
<tr><th>Parameters</th><td><code>%(params)s</code></td></tr></table>
</main></body></html>""" % {
        "title": e(title), "n": s["n_estimates"], "first": q["first_week"], "last": q["last_week"],
        "wape": pct(s["wape"]), "wapeb": pct(s["wape_baseline"]), "cov": pct(s["coverage"], 0), "nom": pct(nominal, 0),
        "bias": pct(s["bias"]), "imp": imp_txt, "covnote": cov_note, "skus": q["skus"], "horizon": p["horizon_weeks"],
        "skurows": sku_rows, "worst": worst, "path": e(ds.path), "sha": ds.sha256, "rows": q["rows_read"], "skipped": e(skipped),
        "weeks": q["weeks"], "filled": q["missing_weeks_filled_with_zero"], "assume": e(q["assumption"]),
        "neg": q["weeks_negative_clamped_to_zero"], "params": e(json.dumps(p, sort_keys=True))}
