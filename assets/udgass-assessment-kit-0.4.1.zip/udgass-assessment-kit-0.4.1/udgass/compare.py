"""Score a forecast you already have (your incumbent system or planners) against Udgass on the SAME windows.
This is the test that matters for a buyer. Hindsight is the main risk, so the limits are printed with the result."""
from __future__ import annotations
import csv
from .data import delimiter
from datetime import datetime, timedelta
from .data import monday

LIMITS = [
    "Your forecasts must be the ones that were actually made at the time (a saved snapshot), not numbers re-run today with data you did not have then.",
    "Each forecast must cover the same horizon as the backtest (default 4 weeks, starting the week of as_of) and be the total for that window.",
    "Only windows present in BOTH files are scored. Fewer than about 50 matched windows is a weak basis for any conclusion.",
    "This compares accuracy on your history. It does not show how either will do next quarter.",
]


def load_incumbent(path, date_format="%Y-%m-%d"):
    with open(path, newline="", encoding="utf-8-sig") as f:
        rd = csv.DictReader(f, delimiter=delimiter(path))
        cols = {c.strip().lower(): c for c in (rd.fieldnames or [])}
        for need in ("sku", "as_of", "forecast"):
            if need not in cols:
                raise ValueError("incumbent file needs columns sku, as_of, forecast (found: %s)" % ", ".join(rd.fieldnames or []))
        out, bad = {}, 0
        for r in rd:
            try:
                d = monday(datetime.strptime(r[cols["as_of"]].strip(), date_format).date())
                out[(r[cols["sku"]].strip(), d.isoformat())] = float(r[cols["forecast"]].replace(",", ""))
            except (ValueError, AttributeError):
                bad += 1
    return out, bad


def compare(rows, incumbent):
    m = [(r, incumbent[(r["sku"], r["as_of"])]) for r in rows if (r["sku"], r["as_of"]) in incumbent]
    if not m:
        raise ValueError("no windows matched. Check sku names and that as_of dates fall on weeks the backtest scored (the first as-of week needs 52 weeks of history; as-of dates are moved to that week's Monday).")
    a = sum(r["actual"] for r, _ in m)
    if a <= 0:
        raise ValueError("matched windows have zero total actual")
    w = lambda f: sum(abs(r["actual"] - f(r, i)) for r, i in m) / a
    res = {"matched_windows": len(m), "of_backtest_windows": len(rows),
           "wape_incumbent": w(lambda r, i: i), "wape_udgass": w(lambda r, i: r["estimate"]), "wape_naive": w(lambda r, i: r["baseline"]),
           "bias_incumbent": (a - sum(i for _, i in m)) / a, "bias_udgass": (a - sum(r["estimate"] for r, _ in m)) / a,
           "windows_udgass_closer": sum(abs(r["actual"] - r["estimate"]) < abs(r["actual"] - i) for r, i in m),
           "windows_incumbent_closer": sum(abs(r["actual"] - r["estimate"]) > abs(r["actual"] - i) for r, i in m),
           "limits": LIMITS}
    return res
