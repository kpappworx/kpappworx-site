"""Udgass core: read-only backtesting and decision records. Advisory only."""
__version__ = "0.4.1"
