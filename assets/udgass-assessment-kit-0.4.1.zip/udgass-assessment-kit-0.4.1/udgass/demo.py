"""Synthetic demo data. Invented. Never use results from this to say anything about Udgass accuracy."""
from __future__ import annotations
import csv, math, random
from datetime import date, timedelta


def write(path, weeks=156, seed=11):
    rnd = random.Random(seed)
    start = date(2022, 1, 3)
    skus = [("SKU-A", 120, 14, 0.2, 0), ("SKU-B", 60, 10, 0.1, 1), ("SKU-C", 200, 20, 0.0, 2), ("SKU-D", 35, 6, 0.3, 3), ("SKU-E", 90, 9, -0.05, 4)]
    with open(path, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["date", "sku", "quantity"])
        for sku, base, amp, trend, ph in skus:
            for i in range(weeks):
                v = base + trend * i + amp * math.sin(2 * math.pi * (i % 52) / 52 + ph) + rnd.gauss(0, base * 0.08)
                if sku == "SKU-C" and 100 <= i < 104:
                    v *= 1.6                      # an invented promotion
                w.writerow([(start + timedelta(weeks=i)).isoformat(), sku, max(0, round(v))])


def write_rich(path, events_path=None, weeks=156, seed=5):
    """Invented data with KNOWN injected changes, so detection can be scored against the truth.
    Returns the truth list [{sku, week_index, kind}]."""
    rnd = random.Random(seed)
    start = date(2022, 1, 3)
    truth = []
    rows, events = [], []
    def poisson(lam):
        L, k, p = math.exp(-lam), 0, 1.0
        while True:
            k += 1; p *= rnd.random()
            if p <= L:
                return k - 1
    smooth = [("RICH-A", 150, 18, 0.15, 0), ("RICH-B", 80, 12, 0.0, 1), ("RICH-C", 220, 25, -0.1, 2), ("RICH-D", 50, 7, 0.2, 3)]
    for sku, base, amp, trend, ph in smooth:
        for i in range(weeks):
            v = base + trend * i + amp * math.sin(2 * math.pi * (i % 52) / 52 + ph) + rnd.gauss(0, base * 0.06)
            if sku == "RICH-A" and i in (95, 96):
                v *= 1.7; truth.append({"sku": sku, "week_index": i, "kind": "spike"})
                events.append((sku, (start + timedelta(weeks=i)).isoformat(), (start + timedelta(weeks=i + 1)).isoformat(), "promotion"))
            if sku == "RICH-B" and i == 120:
                v *= 2.0; truth.append({"sku": sku, "week_index": i, "kind": "spike"})        # unexplained: no event recorded
            if sku == "RICH-C" and i >= 110:
                v *= 0.7
                if i == 110: truth.append({"sku": sku, "week_index": i, "kind": "level_shift"})
            rows.append((sku, i, max(0, round(v))))
    for sku, lam in (("RICH-I1", 0.6), ("RICH-I2", 0.25)):          # intermittent demand
        for i in range(weeks):
            rows.append((sku, i, poisson(lam) * rnd.choice((1, 2, 3))))
    with open(path, "w", newline="") as f:
        w = csv.writer(f); w.writerow(["date", "sku", "quantity"])
        for sku, i, q in rows:
            w.writerow([(start + timedelta(weeks=i)).isoformat(), sku, q])
    if events_path:
        with open(events_path, "w", newline="") as f:
            w = csv.writer(f); w.writerow(["sku", "start", "end", "type"]); w.writerows(events)
    return truth
