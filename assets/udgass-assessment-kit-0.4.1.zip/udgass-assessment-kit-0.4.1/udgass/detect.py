"""Exception detection. Flags changes worth a person's attention, with the evidence. A flag is a prompt for review, not a conclusion.

Method (all causal: each week is judged only against earlier weeks):
- expected value = what the series' own recent history predicts (a seasonal comparison when a year exists, else a trailing median)
- spike/drop: robust z-score of the difference, using the median absolute deviation of earlier differences
- level shift: a two-sided CUSUM on those standardised differences, restarted after it fires
"""
from __future__ import annotations
import math
from .forecast import SEASON


def _median(xs):
    s = sorted(xs)
    n = len(s)
    return s[n // 2] if n % 2 else (s[n // 2 - 1] + s[n // 2]) / 2


def _expected(hist):
    """Expected next value from history only."""
    base = _median(hist[-8:])
    t = len(hist)
    if t >= SEASON + 8:
        i = t - SEASON
        ref = _median(hist[i - 8:i]) if i >= 8 else 0
        cur = _median(hist[i - 1:i + 2])
        if ref > 0:
            return base * min(2.0, max(0.5, cur / ref))
    return base


def scan(series, z_thresh=4.0, cusum_k=1.0, cusum_h=6.0, min_history=26, week_start=None):
    """Return a list of exceptions for one series [{index, kind, observed, expected, z, ...}]."""
    out, diffs = [], []
    pos = neg = 0.0
    if sum(1 for v in series if v == 0) / max(1, len(series)) > 0.3:
        return []                        # intermittent demand: isolated large weeks are normal, so spike detection would only raise false alarms
    clean = list(series[:min_history])   # history with flagged weeks clipped, so one event does not distort later comparisons
    for t in range(len(series)):
        if t < min_history:
            if t >= 8:
                diffs.append(series[t] - _expected(series[:t]))
            continue
        e = _expected(clean)
        d = series[t] - e
        recent = diffs[-52:]
        med = _median(recent)
        mad = _median([abs(x - med) for x in recent]) * 1.4826
        scale = max(mad, 0.05 * max(e, 1.0), 1.0)
        z = (d - med) / scale
        if abs(z) >= z_thresh:
            out.append({"index": t, "kind": "spike" if z > 0 else "drop", "observed": series[t], "expected": e, "z": z})
            # do not let an isolated spike pollute the scale estimate
            diffs.append(max(min(d, med + 3 * scale), med - 3 * scale))
            clean.append(e + max(min(d, 3 * scale), -3 * scale))
        else:
            diffs.append(d)
            clean.append(series[t])
        zc = max(-3.0, min(3.0, z))      # a single extreme week must not look like a sustained shift
        pos = max(0.0, pos + zc - cusum_k)
        neg = max(0.0, neg - zc - cusum_k)
        if pos >= cusum_h or neg >= cusum_h:
            kind = "level_up" if pos >= cusum_h else "level_down"
            out.append({"index": t, "kind": kind, "observed": series[t], "expected": e, "z": z})
            pos = neg = 0.0
    for x in out:
        if week_start:
            x["week"] = week_start(x["index"]).isoformat()
        x["note"] = "A prompt for review. Not a diagnosis."
    return out


def episodes(flags, gap=2):
    """Merge flags that are close in time into one episode each."""
    out = []
    for f in sorted(flags, key=lambda x: x["index"]):
        if out and f["index"] - out[-1]["end_index"] <= gap:
            e = out[-1]
            e["end_index"] = f["index"]
            e["kinds"].add(f["kind"])
            if abs(f["z"]) > abs(e["peak_z"]):
                e["peak_z"] = f["z"]
        else:
            out.append({"index": f["index"], "end_index": f["index"], "kinds": {f["kind"]}, "peak_z": f["z"],
                        "observed": f["observed"], "expected": f["expected"], "week": f.get("week")})
    for e in out:
        k = e.pop("kinds")
        e["kind"] = ("level_shift_up" if "level_up" in k else "level_shift_down") if (k & {"level_up", "level_down"}) else ("spike" if "spike" in k else "drop")
        e["weeks_affected"] = e["end_index"] - e["index"] + 1
        e["note"] = "A prompt for review. Not a diagnosis."
    return out


def scan_all(ds, **kw):
    res = {}
    for sku, y in ds.series.items():
        ex = episodes(scan(y, week_start=ds.week_start, **kw))
        if ex:
            res[sku] = ex
    return res


PRESETS = {"balanced": {"cusum_k": 1.0, "cusum_h": 6.0, "z_thresh": 4.0},
           "sensitive": {"cusum_k": 0.5, "cusum_h": 6.0, "z_thresh": 4.0}}


def impact(series, ep):
    """Units by which the episode's weeks differed from what was expected. Used to rank flags by materiality."""
    return sum(abs(series[i] - ep["expected"]) for i in range(ep["index"], ep["end_index"] + 1))
