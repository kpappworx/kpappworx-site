"""Decision records: an append-only, hash-chained ledger (JSON lines). Tamper-evident, not tamper-proof."""
from __future__ import annotations
import hashlib, json, os
from datetime import datetime, timezone

GENESIS = "0" * 64


def _h(prev, seq, ts, typ, data):
    body = json.dumps({"prev": prev, "seq": seq, "ts": ts, "type": typ, "data": data}, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(body.encode()).hexdigest()


def _load(path):
    if not os.path.exists(path):
        return []
    with open(path, encoding="utf-8") as f:
        return [json.loads(l) for l in f if l.strip()]


def verify(path):
    prev = GENESIS
    for i, e in enumerate(_load(path), 1):
        if e["seq"] != i or e["prev"] != prev or e["hash"] != _h(prev, e["seq"], e["ts"], e["type"], e["data"]):
            return False, "ledger broken at entry %d" % i
        prev = e["hash"]
    return True, "ok"


def append(path, typ, data, now=None):
    ok, msg = verify(path)
    if not ok:
        raise ValueError("refusing to append: " + msg)
    entries = _load(path)
    prev = entries[-1]["hash"] if entries else GENESIS
    seq = len(entries) + 1
    ts = (now or datetime.now(timezone.utc)).isoformat(timespec="seconds")
    e = {"seq": seq, "ts": ts, "type": typ, "data": data, "prev": prev, "hash": _h(prev, seq, ts, typ, data)}
    with open(path, "a", encoding="utf-8") as f:
        f.write(json.dumps(e, sort_keys=True) + "\n")
    return e


REQUIRED = {
    "decision": ("id", "title", "owner", "as_of", "estimate"),
    "action": ("decision_id", "text"),
    "outcome": ("decision_id", "realised"),
}


def add(path, typ, data):
    miss = [k for k in REQUIRED[typ] if k not in data]
    if miss:
        raise ValueError("missing fields for %s: %s" % (typ, ", ".join(miss)))
    entries = _load(path)
    if typ == "decision":
        est = data["estimate"]
        for k in ("point", "low", "high"):
            if k not in est:
                raise ValueError("estimate needs point, low and high")
        if not est["low"] <= est["point"] <= est["high"]:
            raise ValueError("estimate must satisfy low <= point <= high")
        if any(e["type"] == "decision" and e["data"]["id"] == data["id"] for e in entries):
            raise ValueError("decision id already exists")
    else:
        if not any(e["type"] == "decision" and e["data"]["id"] == data["decision_id"] for e in entries):
            raise ValueError("unknown decision id")
        if typ == "outcome" and any(e["type"] == "outcome" and e["data"]["decision_id"] == data["decision_id"] for e in entries):
            raise ValueError("outcome already recorded; the ledger is append-only, so record a correction as a new decision note")
    return append(path, typ, data)


def view(path, decision_id):
    """Assemble one decision's history and compute the variance. Nothing is stored that can be derived."""
    entries = [e for e in _load(path) if e["data"].get("id", e["data"].get("decision_id")) == decision_id]
    dec = next((e for e in entries if e["type"] == "decision"), None)
    if not dec:
        raise ValueError("unknown decision id")
    out = {"decision": dec["data"], "events": [{"seq": e["seq"], "ts": e["ts"], "type": e["type"]} for e in entries],
           "actions": [e["data"] for e in entries if e["type"] == "action"], "outcome": None, "variance": None}
    oc = next((e for e in entries if e["type"] == "outcome"), None)
    if oc:
        est = dec["data"]["estimate"]
        r = oc["data"]["realised"]
        out["outcome"] = oc["data"]
        out["variance"] = {"absolute": r - est["point"],
                           "percent": (r - est["point"]) / est["point"] * 100 if est["point"] else None,
                           "inside_range": est["low"] <= r <= est["high"]}
    return out
