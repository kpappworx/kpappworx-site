# Security and procurement questionnaire: Udgass assessment kit (pre-filled)

Answers for a company's IT, security or procurement team, for **version 0.4 of the assessment kit run on the company's own computer**. Where something does not exist, the answer says so.

## Company and product

| Question | Answer |
|---|---|
| Supplier | KPAppWorx Technologies Private Limited, Bengaluru, India. One founder (Kanthipriya Mahale). |
| Product stage | Early development. Not yet run on many companies' real data. |
| What is supplied | Source code (Python) and documents in a zip file. No hosted service, no account, no installer. |
| Dependencies | Python standard library only. No third-party packages. |
| Software bill of materials | The zip contents are listed with SHA-256 hashes in `SHA256SUMS.txt`. The only runtime is the customer's own Python 3.9+. |
| Certifications (SOC 2, ISO 27001, others) | None. No audit has started. |
| Independent penetration test | None. |
| Cyber insurance | None stated. |
| Licence terms | Not finalised. Free evaluation for the first three companies; terms under legal review. |

## Data

| Question | Answer |
|---|---|
| Does any customer data leave the customer's computer? | No. The assessment makes no network connections (see `PRIVACY-AND-EXECUTION`). |
| Does the supplier receive or store customer data? | No. If the customer chooses to share the report, that is the only thing received, by a channel the customer chooses. |
| Personal data | Not needed. The customer is asked to exclude it. Columns that are not mapped (including any personal-looking ones) are ignored and never stored, and the report flags them. |
| Where is data processed? | On the customer's computer, in a temporary folder that is deleted when the run ends. |
| Data at rest | Only the report file the customer names. Encryption at rest depends on the customer's disk encryption. |
| Retention and deletion | Nothing is retained by Udgass after the run. The customer deletes the report when they choose. |
| Sub-processors and third parties | None for the assessment. |
| AI or language-model services | None. All calculations are deterministic statistics in the supplied code. No data is sent to any model provider. |
| Data residency | Wherever the customer runs it. |

## Software security

| Question | Answer |
|---|---|
| Network access | None during the assessment. Verified by a source scan, a module-load check, a system-call trace of a full run (zero network calls) and a full run inside an empty network namespace. |
| Privileges needed | Normal user. No administrator rights, no installation, no changes to system settings. |
| Changes to customer systems | None. It reads the files named and writes only the report named. It cannot connect to ERP, planning or purchasing systems. |
| Code execution from input files | None. Files are parsed as CSV text with the standard `csv` module. Spreadsheets and binary files are refused. Formula-like text is stored and shown as text. |
| Input robustness | Fuzz-tested with malformed and hostile files (random bytes, wrong column counts, extreme numbers, SQL and spreadsheet-formula text): every case produced a report or a clear refusal. |
| Static analysis | Bandit 1.9.4 run on the whole package: no high-severity findings. 19 medium findings are SQL strings built from fixed internal table and column names with all values passed as bound parameters (reviewed; not injectable, with a regression test). 7 low findings: six are Python's `random` used for simulations, where cryptographic randomness is not needed; one is a deliberately silent failure when writing a log line in the optional local web server. |
| Tests | 97 automated tests on Python 3.9 and 3.13. |
| Integrity of the kit | `SHA256SUMS.txt` lists a hash for every file; the founder can confirm the zip's own hash by email. |
| Vulnerability reporting | Use the contact form at kpappworx.com/udgass with "security" in the message. One person; replies within a few days. No bug bounty. |
| Operating systems tested | Linux (fully). macOS (runs; the network trace was done on Linux). Windows 11: full assessment run by typed command on 24 Oct 2026 (sample data). The `.bat` launcher can be blocked by Smart App Control; the typed command is the supported method. Code signing is planned. |

## Contract and support

| Question | Answer |
|---|---|
| Support and uptime commitment | None. No service to keep up. Questions answered by email. |
| Liability | Not drafted. The report is advisory; every decision rests with the customer. |
| Publication of results | Only with separate, optional written permission for the exact wording. Never the customer's data. |
