# Security

**Status: not security-reviewed.** No third-party penetration test, no SOC 2, no ISO 27001, no certification of any kind exists for Udgass. Nothing here should be read as a claim otherwise.

## v0.4 engine controls (implemented and tested)

- Organisation isolation: every query filters on the organisation of the authenticated key; cross-organisation reads and writes are tested to fail.
- API keys: 256-bit random, stored as SHA-256 hashes, shown once, revocable. Roles viewer, analyst, admin, enforced inside the engine; no privilege escalation (tested).
- Append-only records enforced by database triggers; decision records hash-chained; audit log of every write without data values.
- Input validation on every field; uploads size-limited; spreadsheets and binary files refused; no code or macros executed.
- Rate limits per key and per client address for failed authentication. Errors carry a request id, never a stack trace.
- Structured logs without bodies or keys (tested). Security headers and a strict Content-Security-Policy on the web app; all server text is inserted as text, never HTML.
- Server binds to 127.0.0.1; any other address requires TLS (TLS 1.2+) or an explicit unsafe flag.
- Controlled purge of one organisation (admin, confirm by name) and export.

Not built: single sign-on, MFA, encryption of the database file (use disk encryption), key rotation reminders, distributed rate limiting, backups (see DATA_HANDLING.md).

## What the software does and does not do

- Runs on a machine you control. There is no hosted service. The engine has organisations and API keys for people using that machine's server.
- Standard library only. No third-party dependencies, so no dependency supply chain to review.
- Makes no outbound network calls. A test checks that network and subprocess modules are not imported by any module except the local API server, which only listens.
- Reads the files you point it at and does not modify them. A test checks the file's hash and modification time are unchanged.
- The CLI writes only the output files you name and a run log. The engine writes its database and short-lived staged uploads next to it.
- Never executes actions in any other system. It has no write path to ERP, planning or purchasing tools.

## What it does not have

Single sign-on, encryption of the database file, a hardened hosted deployment, secure-development evidence, an incident process, or a vulnerability disclosure history. The run log is tamper-evident, not tamper-proof: someone with write access to the folder can delete the whole file or rebuild a consistent chain.

## Reporting a problem

Use the contact form at kpappworx.com/udgass and put "security" in the message. This is one person; expect a reply within a few days, not a service-level commitment.
