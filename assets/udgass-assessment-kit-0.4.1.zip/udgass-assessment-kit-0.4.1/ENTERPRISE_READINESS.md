# Enterprise readiness: an honest checklist

Udgass is **not enterprise-ready**. This list says what is true today, so a buyer's security and procurement teams do not have to guess.

| Area | Today |
|---|---|
| Accuracy on real data | **None measured.** All published numbers use invented data. First step: backtests on a partner's own history, shared only with that partner's consent. |
| Security certification (SOC 2, ISO 27001) | **None.** No audit has started. |
| Penetration test | **None.** |
| Customer references | **None.** |
| Integrations (SAP, Oracle, Snowflake, etc.) | **None.** CSV only. |
| Hosted service, SSO | **None.** Customer-run server; no single sign-on. |
| Organisations, roles, audit trail | Built in v0.4: per-organisation isolation (tested), viewer/analyst/admin keys, audit log of every write, append-only records. |
| End-to-end workflow | Built in v0.4 and tested on synthetic data: import, patterns, forecasts, backtests, scenarios, decision records, outcomes. |
| Data protection | Local processing, no network code, personal-data guard, documented in DATA_HANDLING.md. No DPA, no sub-processors because there is no service. |
| Scale | 500 series with 3 years of daily rows: import 28 s, backtest 18 s on one core (synthetic). No job queue; not tested on a real catalogue. |
| Support and uptime commitments | **None.** One person. |
| Liability position | Advisory, read-only. A human decides and is accountable. No contractual terms drafted. |
| Open source licence / IP terms | Not decided. |

## What would change this, in order

1. Free backtests on 3 to 5 planners' real history, with their sign-off on the result and what it showed, good or bad.
2. Paid pilots with the head-to-head `compare-forecast` test against their current forecast.
3. Security basics for a hosted version: independent pen test, then a SOC 2 Type I readiness exercise.
4. Integrations that read from one named system, read-only.
5. Reference customers who agree to be named.

Steps 1 and 2 need customers, not code.
