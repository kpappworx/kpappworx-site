# Udgass demand assessment: start here

Thank you for trying Udgass. This kit runs entirely on your own computer. Nothing is uploaded, and you keep the report.

Udgass is early-stage software from one developer. It has not yet been run on many companies' real data, which is exactly why your assessment is useful. The result may be good or disappointing; both are worth knowing.

## What you get

A single report file (open it in any web browser, or print it to PDF) covering:

1. Data quality: what was read, what was rejected and why, gaps, and possible stock-outs.
2. What your data can and cannot answer about inventory.
3. How accurate estimates would have been, replaying your own history using only what was known at each date, compared with three simple methods.
4. Optional: a head-to-head against your own past forecasts.
5. Every product ranked by how hard it is to forecast, and patterns worth a look.
6. An advisory reading of whether a pilot looks justified, using rules fixed in advance. The decision is always yours.

## Checklist

**Before you start**

- [ ] A computer with Python 3.9 or newer. Check with `python3 --version` (on Windows: `py --version`). Python is free from python.org; nothing else needs installing.
- [ ] About 30 minutes to prepare the export. The run itself takes a few minutes.

**Prepare the files** (CSV, UTF-8; comma, semicolon, tab or pipe separated)

- [ ] **Sales (required).** One row per sale or per product per day or week: date, product code, quantity. Add location if you have several warehouses or plants. At least 56 weeks of history (just over a year), ideally two years or more for a reliable verdict. Monthly totals are not enough.
- [ ] **Stock snapshots (optional).** Date, product code, quantity on hand. Shows where stock-outs hid demand.
- [ ] **Purchase orders (optional).** PO number, product code, order date, quantity, promised date, receipt date, vendor. Shows real supplier lead times.
- [ ] **Your past forecasts (optional).** Product code, the first date of each forecast window, and the forecast total for that window, exactly as it was made at the time (saved copies, not re-created).
- [ ] **Leave out personal data:** customer names, emails, phone numbers, addresses. Extra columns are ignored and never stored, but it is better not to export them at all.

A sample sales file is in `sample/` so you can see the expected shape.

**Run it on macOS or Linux.** Double-click `run-assessment.command` and drag your sales file into the window. (On macOS the first time, right-click the file and choose Open, because it is not from the App Store.) Or, in a terminal inside this folder:

    python3 -m udgass check sales.csv
    python3 -m udgass assess --sales sales.csv --out assessment.html

**Run it on Windows.** Many Windows 11 PCs (Smart App Control, or company policy) block double-clicked script files such as `run-assessment.bat`. Typing the command always works and is what we recommend:

1. Open this folder in File Explorer. (If "Extract All" created a folder inside a folder, open the inner one, the one that contains `START-HERE.md`.)
2. Click the address bar, type `cmd` and press Enter. A Command Prompt opens in this folder.
3. Type `py --version`. If it is not found, install Python from python.org and tick "Add python.exe to PATH", then reopen the Command Prompt.
4. Run, replacing the path with your own file (you can drag the file into the window to paste its path):

        py -m udgass assess --sales "C:\path\to\sales.csv" --out assessment.html
        start assessment.html

You may also try double-clicking `run-assessment.bat`; if Windows blocks it, use the steps above. Do not turn off Smart App Control for this.

**With the optional files** (use `py` instead of `python3` on Windows):

    python3 -m udgass assess --sales sales.csv --inventory stock.csv --purchase-orders po.csv --incumbent our_forecasts.csv --out assessment.html

**If it stops and asks something**, it is protecting you from a wrong guess. The message says what to add, for example:

- an ambiguous column: `--map sales:sku=Material`
- ambiguous dates such as 03/04/2024: `--date-format %d/%m/%Y`
- numbers like 1.234,5: `--decimal-comma`
- returns as negative quantities: `--returns net`
- an Excel file: save it as CSV first

**After the run**

- [ ] Open `assessment.html` in a browser. Print to PDF if you want a file to circulate.
- [ ] If you would like a written review from us, send the report, or an anonymised copy made with `--anonymise` (product and location codes replaced). Sharing is up to you.

## Your data

- The assessment runs on your machine and makes no network connections. It reads your files, works in a temporary folder that it deletes when it finishes, and writes only the report you name.
- The code is plain Python with no third-party dependencies, so your IT or security team can read all of it.
- See `PRIVACY-AND-EXECUTION.md` for how this was checked, and `SECURITY-QUESTIONNAIRE.md` for answers your IT or procurement team may ask for.
- `SHA256SUMS.txt` lists a fingerprint for every file, so you can confirm nothing was altered.

## Terms of the free assessment

- Free for the first three companies. In return, we learn how Udgass performs on real data, from whatever you choose to share with us.
- Publishing any result or testimonial is a **separate, optional** permission. You can decline, and the free assessment does not depend on it. Nothing is published without your separate written approval of the exact wording, and never your data, product codes, volumes or other confidential details.
- The report is advisory. Udgass does not place orders or change any system, and every decision rests with your company.

Questions: hello@kpappworx.com
