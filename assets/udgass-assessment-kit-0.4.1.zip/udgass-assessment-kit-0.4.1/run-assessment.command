#!/bin/bash
# Udgass demand assessment launcher for macOS and Linux. Runs locally; makes no network connections.
cd "$(dirname "$0")" || exit 1
if ! command -v python3 >/dev/null 2>&1; then echo "Python 3.9 or newer is needed: https://www.python.org/downloads/"; read -r -p "Press Return to close." _; exit 1; fi
python3 -c 'import sys; sys.exit(0 if sys.version_info >= (3, 9) else 1)' || { echo "Python 3.9 or newer is needed. You have: $(python3 --version)"; read -r -p "Press Return to close." _; exit 1; }
echo "Udgass demand assessment (runs on this computer only)"
read -r -p "Drag your sales CSV file here, then press Return: " SALES
SALES="${SALES%\"}"; SALES="${SALES#\"}"; SALES="${SALES%\'}"; SALES="${SALES#\'}"; SALES="$(echo "$SALES" | sed 's/\\ / /g;s/ *$//')"
[ -f "$SALES" ] || { echo "File not found: $SALES"; read -r -p "Press Return to close." _; exit 1; }
rm -f assessment.html
python3 -m udgass assess --sales "$SALES" --out assessment.html
STATUS=$?
if [ $STATUS -ne 0 ] && [ $STATUS -ne 3 ]; then echo "The assessment did not finish. No report was produced."; read -r -p "Press Return to close." _; exit $STATUS; fi
if [ -f assessment.html ]; then (open assessment.html || xdg-open assessment.html) >/dev/null 2>&1 || true; fi
echo; echo "The report is assessment.html in this folder. For the optional files (stock, purchase orders, your forecasts) see START-HERE."
read -r -p "Press Return to close." _
exit $STATUS
