# How the assessment runs on your machine, and how that was checked

## What happens when you run `udgass assess`

1. Python loads the `udgass` package from this folder. It uses only the Python standard library.
2. A temporary folder is created in your system's temp location (named `udgass-assess-...`).
3. Each file you name is read, checked and mapped. Only the mapped columns (date, product, quantity and the like) are kept, in a small database file inside that temporary folder. Columns that are not mapped are never stored.
4. The analysis runs on that database.
5. The report (and the JSON file, if you ask for one) is written where you said.
6. The temporary folder, including the database, is deleted, also if the run fails.

## Checks made on version 0.4 before release (Linux, Python 3.9 and 3.13)

| Check | Result |
|---|---|
| Source scan for network and process modules (socket, http, urllib, ssl, requests, subprocess and similar) in everything `assess` uses | None. The only module that imports any of them is `udgass/engine/api.py`, the optional local web server, which `assess` does not load. |
| Modules actually loaded during a full `assess` run | No network or process modules loaded. |
| System calls traced during a full run (`strace -e socket,connect,sendto,bind`) | Zero network system calls. |
| Full run inside an empty network namespace (no network at all) | Completes normally, identical report. |
| External references in the report (scripts, stylesheets, images, fonts, links) | None. The report is one self-contained file. |
| Temporary files left after the run | None. |
| Automated tests | 97 passing on Python 3.9 and 3.13, including checks that input files are never modified and fuzz tests with malformed and hostile files. |

Your IT team can repeat the network check on Linux or macOS, for example:

    strace -f -e trace=socket,connect python3 -m udgass assess --sales sales.csv --out r.html    # Linux

or simply run it with the network disconnected.

## Not checked yet

- Windows and macOS were not traced in this way (macOS uses the same code paths; Windows is untested).
- Your Python installation itself is outside Udgass's control.

## The optional web app

`python3 -m udgass serve` starts a local web app for exploring results. It listens on your own machine only (127.0.0.1) and stores data in a database file you choose. It is not needed for the assessment.
